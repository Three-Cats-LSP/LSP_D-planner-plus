package com.hhssoftware.multideco;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Looper;
import android.os.MessageQueue;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import androidx.core.view.ViewCompat;

/* loaded from: classes.dex */
public class multideco_config extends Activity implements AdapterView.OnItemSelectedListener, View.OnClickListener, MessageQueue.IdleHandler {
    AlertDialog alertLoading;
    private boolean isIniting;
    private Settings settings;
    private boolean isReset = false;
    private final int MENU_WEB_FAQ = 446221;

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public void onNothingSelected(AdapterView<?> adapterView) {
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        setTheme(new Theme_setting(this).theme_id);
        super.onCreate(bundle);
        setContentView(C0347R.layout.multideco_config);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(getString(C0347R.string.waitLoadingsetting));
        builder.setCancelable(true);
        AlertDialog create = builder.create();
        this.alertLoading = create;
        create.show();
        Looper.myQueue().addIdleHandler(this);
    }

    @Override // android.os.MessageQueue.IdleHandler
    public boolean queueIdle() {
        this.isIniting = true;
        this.settings = new Settings(this);
        initForm();
        setForMLabels();
        this.isIniting = false;
        this.alertLoading.dismiss();
        return false;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r17v0 */
    /* JADX WARN: Type inference failed for: r17v1 */
    /* JADX WARN: Type inference failed for: r17v2 */
    private void initForm() {
        ?? r17;
        char c;
        if (this.settings.OC_CCR == 0) {
            ((CompoundButton) findViewById(C0347R.id.ConfigCircuitOC)).setChecked(true);
        } else {
            ((CompoundButton) findViewById(C0347R.id.ConfigCircuitCCR)).setChecked(true);
        }
        Spinner spinner = (Spinner) findViewById(C0347R.id.configModel);
        boolean z = this.isReset;
        char c2 = 6;
        int i = android.R.layout.simple_spinner_item;
        if (!z) {
            ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_config.1
                @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
                public View getDropDownView(int i2, View view, ViewGroup viewGroup) {
                    View dropDownView = super.getDropDownView(i2, view, viewGroup);
                    ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                    return dropDownView;
                }
            };
            arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            for (int i2 = 1; i2 <= 6; i2++) {
                arrayAdapter.add(this.settings.modelString(i2));
            }
            spinner.setAdapter((SpinnerAdapter) arrayAdapter);
            spinner.setOnItemSelectedListener(this);
        }
        spinner.setSelection(this.settings.VPMModel - 1);
        Spinner spinner2 = (Spinner) findViewById(C0347R.id.configConserve);
        if (!this.isReset) {
            ArrayAdapter<String> arrayAdapter2 = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_config.2
                @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
                public View getDropDownView(int i3, View view, ViewGroup viewGroup) {
                    View dropDownView = super.getDropDownView(i3, view, viewGroup);
                    ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                    return dropDownView;
                }
            };
            arrayAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            arrayAdapter2.add("0");
            for (int i3 = 1; i3 <= 5; i3++) {
                arrayAdapter2.add("+" + i3);
            }
            spinner2.setAdapter((SpinnerAdapter) arrayAdapter2);
        }
        spinner2.setSelection(this.settings.Margin);
        Spinner spinner3 = (Spinner) findViewById(C0347R.id.configConserveGFLo);
        if (!this.isReset) {
            ArrayAdapter<String> arrayAdapter3 = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_config.3
                @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
                public View getDropDownView(int i4, View view, ViewGroup viewGroup) {
                    View dropDownView = super.getDropDownView(i4, view, viewGroup);
                    ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                    return dropDownView;
                }
            };
            arrayAdapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            for (int i4 = 100; i4 >= 10; i4 -= 5) {
                arrayAdapter3.add("" + i4);
            }
            spinner3.setAdapter((SpinnerAdapter) arrayAdapter3);
        }
        spinner3.setSelection((100 - this.settings.GFLo) / 5);
        Spinner spinner4 = (Spinner) findViewById(C0347R.id.configConserveGFHi);
        if (!this.isReset) {
            ArrayAdapter<String> arrayAdapter4 = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_config.4
                @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
                public View getDropDownView(int i5, View view, ViewGroup viewGroup) {
                    View dropDownView = super.getDropDownView(i5, view, viewGroup);
                    ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                    return dropDownView;
                }
            };
            arrayAdapter4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            for (int i5 = 100; i5 >= 50; i5 -= 5) {
                arrayAdapter4.add("" + i5);
            }
            spinner4.setAdapter((SpinnerAdapter) arrayAdapter4);
        }
        spinner4.setSelection((100 - this.settings.GFHi) / 5);
        Spinner spinner5 = (Spinner) findViewById(C0347R.id.configConserveGFS);
        if (!this.isReset) {
            ArrayAdapter<String> arrayAdapter5 = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_config.5
                @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
                public View getDropDownView(int i6, View view, ViewGroup viewGroup) {
                    View dropDownView = super.getDropDownView(i6, view, viewGroup);
                    ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                    return dropDownView;
                }
            };
            arrayAdapter5.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            for (int i6 = 100; i6 >= 70; i6 -= 5) {
                arrayAdapter5.add("" + i6);
            }
            spinner5.setAdapter((SpinnerAdapter) arrayAdapter5);
        }
        spinner5.setSelection((100 - this.settings.GFS) / 5);
        conserveViews(this.settings.VPMModel);
        boolean z2 = false;
        if (this.settings.OxyNarc) {
            ((ToggleButton) findViewById(C0347R.id.ConfigO2Narcotic)).setChecked(true);
        } else {
            ((ToggleButton) findViewById(C0347R.id.ConfigO2Narcotic)).setChecked(false);
        }
        if (this.settings.Metric) {
            ((CompoundButton) findViewById(C0347R.id.ConfigMeter)).setChecked(true);
        } else {
            ((CompoundButton) findViewById(C0347R.id.ConfigFeet)).setChecked(true);
        }
        findViewById(C0347R.id.ConfigMeter).setOnClickListener(this);
        findViewById(C0347R.id.ConfigFeet).setOnClickListener(this);
        if (this.settings.WaterType == 0) {
            ((CompoundButton) findViewById(C0347R.id.ConfigSalt)).setChecked(true);
        } else {
            ((CompoundButton) findViewById(C0347R.id.ConfigFresh)).setChecked(true);
        }
        if (this.settings.RMVs == 0) {
            ((CompoundButton) findViewById(C0347R.id.ConfigCuFt)).setChecked(true);
        } else {
            ((CompoundButton) findViewById(C0347R.id.ConfigLtr)).setChecked(true);
        }
        findViewById(C0347R.id.ConfigCuFt).setOnClickListener(this);
        findViewById(C0347R.id.ConfigLtr).setOnClickListener(this);
        populateRMVSpinners(true);
        if (this.settings.SetpointUnits == 0) {
            ((CompoundButton) findViewById(C0347R.id.ConfigCircuitBAR)).setChecked(true);
        } else {
            ((CompoundButton) findViewById(C0347R.id.ConfigCircuitATA)).setChecked(true);
        }
        Spinner spinner6 = (Spinner) findViewById(C0347R.id.configStopTime);
        if (!this.isReset) {
            ArrayAdapter<String> arrayAdapter6 = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_config.6
                @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
                public View getDropDownView(int i7, View view, ViewGroup viewGroup) {
                    View dropDownView = super.getDropDownView(i7, view, viewGroup);
                    ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                    return dropDownView;
                }
            };
            arrayAdapter6.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            arrayAdapter6.add("1:00");
            arrayAdapter6.add("0:30");
            arrayAdapter6.add("0:10");
            arrayAdapter6.add("0:01");
            spinner6.setAdapter((SpinnerAdapter) arrayAdapter6);
        }
        spinner6.setSelection(this.settings.StopTime);
        Spinner spinner7 = (Spinner) findViewById(C0347R.id.configppO2Swap16);
        if (this.isReset) {
            r17 = 0;
        } else {
            ArrayAdapter<String> arrayAdapter7 = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_config.7
                @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
                public View getDropDownView(int i7, View view, ViewGroup viewGroup) {
                    View dropDownView = super.getDropDownView(i7, view, viewGroup);
                    ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                    return dropDownView;
                }
            };
            arrayAdapter7.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            int i7 = 0;
            while (i7 <= 4) {
                arrayAdapter7.add(String.format("%.1f", Float.valueOf(Settings.ppO2Swaps[i7])));
                i7++;
                z2 = z2;
            }
            r17 = z2;
            spinner7.setAdapter((SpinnerAdapter) arrayAdapter7);
        }
        spinner7.setSelection(this.settings.ppO2);
        Spinner spinner8 = (Spinner) findViewById(C0347R.id.configppO2Swap15);
        if (!this.isReset) {
            ArrayAdapter<String> arrayAdapter8 = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_config.8
                @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
                public View getDropDownView(int i8, View view, ViewGroup viewGroup) {
                    View dropDownView = super.getDropDownView(i8, view, viewGroup);
                    ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                    return dropDownView;
                }
            };
            arrayAdapter8.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            for (int i8 = r17; i8 <= 4; i8++) {
                arrayAdapter8.add(String.format("%.1f", Float.valueOf(Settings.ppO2Swaps[i8])));
            }
            spinner8.setAdapter((SpinnerAdapter) arrayAdapter8);
        }
        spinner8.setSelection(this.settings.ppO2Deep);
        Spinner spinner9 = (Spinner) findViewById(C0347R.id.configppO2Swap14);
        if (!this.isReset) {
            ArrayAdapter<String> arrayAdapter9 = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_config.9
                @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
                public View getDropDownView(int i9, View view, ViewGroup viewGroup) {
                    View dropDownView = super.getDropDownView(i9, view, viewGroup);
                    ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                    return dropDownView;
                }
            };
            arrayAdapter9.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            for (int i9 = r17; i9 <= 4; i9++) {
                arrayAdapter9.add(String.format("%.1f", Float.valueOf(Settings.ppO2Swaps[i9])));
            }
            spinner9.setAdapter((SpinnerAdapter) arrayAdapter9);
        }
        spinner9.setSelection(this.settings.ppO2ReallyDeep);
        ((CompoundButton) findViewById(C0347R.id.ConfigO2FirstStop30sec)).setChecked(this.settings.HalfTimeDeep);
        ((CompoundButton) findViewById(C0347R.id.ConfigO2FirstStop2x)).setChecked(this.settings.DoubleSizeDeep);
        ((CompoundButton) findViewById(C0347R.id.ConfigExtendOnOff)).setChecked(this.settings.Extend);
        findViewById(C0347R.id.ConfigExtendShallow).setEnabled(this.settings.Extend);
        findViewById(C0347R.id.configExtendDeep).setEnabled(this.settings.Extend);
        findViewById(C0347R.id.ConfigAddToStop).setEnabled(this.settings.Extend);
        findViewById(C0347R.id.ConfigAddAllMix).setEnabled(this.settings.Extend);
        findViewById(C0347R.id.ConfigAddO2Window).setEnabled(this.settings.Extend);
        findViewById(C0347R.id.ConfigExtendShallowText).setEnabled(this.settings.Extend);
        findViewById(C0347R.id.ConfigExtendDeepText).setEnabled(this.settings.Extend);
        findViewById(C0347R.id.ConfigAddToStopText).setEnabled(this.settings.Extend);
        findViewById(C0347R.id.ConfigAddAllMixText).setEnabled(this.settings.Extend);
        findViewById(C0347R.id.ConfigAddO2WindowText).setEnabled(this.settings.Extend);
        findViewById(C0347R.id.ConfigRowAddToStopHelp).setEnabled(this.settings.Extend);
        findViewById(C0347R.id.ConfigRowExtendAnyHelp).setEnabled(this.settings.Extend);
        findViewById(C0347R.id.ConfigExtendOnOff).setOnClickListener(this);
        Spinner spinner10 = (Spinner) findViewById(C0347R.id.ConfigExtendShallow);
        if (this.isReset) {
            c = 6;
        } else {
            ArrayAdapter<String> arrayAdapter10 = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_config.10
                @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
                public View getDropDownView(int i10, View view, ViewGroup viewGroup) {
                    View dropDownView = super.getDropDownView(i10, view, viewGroup);
                    ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                    return dropDownView;
                }
            };
            arrayAdapter10.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            int i10 = r17;
            while (i10 <= 14) {
                arrayAdapter10.add(i10 + " min");
                i10++;
                c2 = c2;
            }
            c = c2;
            spinner10.setAdapter((SpinnerAdapter) arrayAdapter10);
        }
        spinner10.setSelection(this.settings.ExtStop);
        Spinner spinner11 = (Spinner) findViewById(C0347R.id.configExtendDeep);
        if (!this.isReset) {
            ArrayAdapter<String> arrayAdapter11 = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_config.11
                @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
                public View getDropDownView(int i11, View view, ViewGroup viewGroup) {
                    View dropDownView = super.getDropDownView(i11, view, viewGroup);
                    ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                    return dropDownView;
                }
            };
            arrayAdapter11.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            for (int i11 = r17; i11 <= 14; i11++) {
                arrayAdapter11.add(i11 + " min");
            }
            spinner11.setAdapter((SpinnerAdapter) arrayAdapter11);
        }
        spinner11.setSelection(this.settings.ExtStopDeep);
        ((CompoundButton) findViewById(C0347R.id.ConfigAddToStop)).setChecked(this.settings.ExtendAdd);
        ((CompoundButton) findViewById(C0347R.id.ConfigAddAllMix)).setChecked(this.settings.ExtendAlways);
        ((CompoundButton) findViewById(C0347R.id.ConfigAddO2Window)).setChecked(this.settings.O2Affect);
        if (this.settings.GuageType) {
            ((CompoundButton) findViewById(C0347R.id.ConfigGuagetypeDigital)).setChecked(true);
        } else {
            ((CompoundButton) findViewById(C0347R.id.ConfigGuagetypeSimple)).setChecked(true);
        }
        ((CompoundButton) findViewById(C0347R.id.ConfigToggleppO2Above)).setChecked((this.settings.Alerts & 1) > 0 ? true : r17);
        ((CompoundButton) findViewById(C0347R.id.ConfigToggleppO2Below)).setChecked((this.settings.Alerts & 2) > 0 ? true : r17);
        ((CompoundButton) findViewById(C0347R.id.ConfigToggleOTUAbove)).setChecked((this.settings.Alerts & 4) > 0 ? true : r17);
        ((CompoundButton) findViewById(C0347R.id.ConfigToggleCNSAbove)).setChecked((this.settings.Alerts & 8) > 0 ? true : r17);
        ((CompoundButton) findViewById(C0347R.id.ConfigToggleIBCDN2Warn)).setChecked((this.settings.Alerts & 16) > 0 ? true : r17);
        ((CompoundButton) findViewById(C0347R.id.ConfigToggleIBCDHeWarn)).setChecked((this.settings.Alerts & 32) > 0 ? true : r17);
        ((CompoundButton) findViewById(C0347R.id.ConfigToggleCCRDilCheck)).setChecked((this.settings.Alerts & 64) > 0 ? true : r17);
        findViewById(C0347R.id.ConfigppO2AboveColor).setBackgroundColor(this.settings.warn_colors[r17] | ViewCompat.MEASURED_STATE_MASK);
        findViewById(C0347R.id.ConfigppO2BelowColor).setBackgroundColor(this.settings.warn_colors[1] | ViewCompat.MEASURED_STATE_MASK);
        findViewById(C0347R.id.ConfigOTUAboveColor).setBackgroundColor(this.settings.warn_colors[2] | ViewCompat.MEASURED_STATE_MASK);
        findViewById(C0347R.id.ConfigCNSAboveColor).setBackgroundColor(this.settings.warn_colors[3] | ViewCompat.MEASURED_STATE_MASK);
        findViewById(C0347R.id.ConfigIBCDN2WarnColor).setBackgroundColor(this.settings.warn_colors[4] | ViewCompat.MEASURED_STATE_MASK);
        findViewById(C0347R.id.ConfigIBCDHeWarnColor).setBackgroundColor(this.settings.warn_colors[5] | ViewCompat.MEASURED_STATE_MASK);
        findViewById(C0347R.id.ConfigCCRdilCheckColor).setBackgroundColor(this.settings.warn_colors[c] | ViewCompat.MEASURED_STATE_MASK);
        Spinner spinner12 = (Spinner) findViewById(C0347R.id.ConfigppO2Above);
        if (!this.isReset) {
            ArrayAdapter<String> arrayAdapter12 = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_config.12
                @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
                public View getDropDownView(int i12, View view, ViewGroup viewGroup) {
                    View dropDownView = super.getDropDownView(i12, view, viewGroup);
                    ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                    return dropDownView;
                }
            };
            arrayAdapter12.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            for (int i12 = r17; i12 <= 20; i12++) {
                arrayAdapter12.add(String.format("%.2f", Double.valueOf((i12 * 0.05d) + 1.0d)));
            }
            spinner12.setAdapter((SpinnerAdapter) arrayAdapter12);
        }
        spinner12.setSelection((this.settings.ppO2Above - 100) / 5);
        Spinner spinner13 = (Spinner) findViewById(C0347R.id.ConfigppO2Below);
        if (!this.isReset) {
            ArrayAdapter<String> arrayAdapter13 = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_config.13
                @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
                public View getDropDownView(int i13, View view, ViewGroup viewGroup) {
                    View dropDownView = super.getDropDownView(i13, view, viewGroup);
                    ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                    return dropDownView;
                }
            };
            arrayAdapter13.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            for (int i13 = 10; i13 <= 20; i13++) {
                arrayAdapter13.add(String.format("%.2f", Double.valueOf(i13 * 0.01d)));
            }
            spinner13.setAdapter((SpinnerAdapter) arrayAdapter13);
        }
        spinner13.setSelection(this.settings.ppO2Below - 10);
        Spinner spinner14 = (Spinner) findViewById(C0347R.id.ConfigOTUAbove);
        if (!this.isReset) {
            ArrayAdapter<String> arrayAdapter14 = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_config.14
                @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
                public View getDropDownView(int i14, View view, ViewGroup viewGroup) {
                    View dropDownView = super.getDropDownView(i14, view, viewGroup);
                    ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                    return dropDownView;
                }
            };
            arrayAdapter14.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            for (int i14 = 100; i14 <= 500; i14 += 25) {
                arrayAdapter14.add("" + i14);
            }
            spinner14.setAdapter((SpinnerAdapter) arrayAdapter14);
        }
        spinner14.setSelection((this.settings.OTUHigh - 100) / 25);
        Spinner spinner15 = (Spinner) findViewById(C0347R.id.ConfigCNSAbove);
        if (!this.isReset) {
            ArrayAdapter<String> arrayAdapter15 = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_config.15
                @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
                public View getDropDownView(int i15, View view, ViewGroup viewGroup) {
                    View dropDownView = super.getDropDownView(i15, view, viewGroup);
                    ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                    return dropDownView;
                }
            };
            arrayAdapter15.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            for (int i15 = 50; i15 <= 150; i15 += 5) {
                arrayAdapter15.add("" + i15);
            }
            spinner15.setAdapter((SpinnerAdapter) arrayAdapter15);
        }
        spinner15.setSelection((this.settings.CNSHigh - 50) / 5);
        Spinner spinner16 = (Spinner) findViewById(C0347R.id.ConfigIBCDN2Warn);
        if (!this.isReset) {
            ArrayAdapter<String> arrayAdapter16 = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_config.16
                @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
                public View getDropDownView(int i16, View view, ViewGroup viewGroup) {
                    View dropDownView = super.getDropDownView(i16, view, viewGroup);
                    ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                    return dropDownView;
                }
            };
            arrayAdapter16.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            for (int i16 = r17; i16 <= 10; i16++) {
                arrayAdapter16.add(String.format("%.2f", Double.valueOf(i16 * 0.1d)));
            }
            spinner16.setAdapter((SpinnerAdapter) arrayAdapter16);
        }
        spinner16.setSelection(this.settings.ppN2High / 10);
        Spinner spinner17 = (Spinner) findViewById(C0347R.id.ConfigIBCDHeWarn);
        if (!this.isReset) {
            ArrayAdapter<String> arrayAdapter17 = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_config.17
                @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
                public View getDropDownView(int i17, View view, ViewGroup viewGroup) {
                    View dropDownView = super.getDropDownView(i17, view, viewGroup);
                    ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                    return dropDownView;
                }
            };
            arrayAdapter17.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            for (int i17 = r17; i17 <= 10; i17++) {
                arrayAdapter17.add(String.format("%.2f", Double.valueOf(i17 * 0.1d)));
            }
            spinner17.setAdapter((SpinnerAdapter) arrayAdapter17);
        }
        spinner17.setSelection(this.settings.ppHeHigh / 10);
        findViewById(C0347R.id.ConfigReset).setOnClickListener(this);
        populateForMSpinners(true);
    }

    private void populateRMVSpinners(boolean z) {
        ArrayAdapter<String> arrayAdapter;
        ArrayAdapter<String> arrayAdapter2;
        String format;
        String format2;
        Spinner spinner = (Spinner) findViewById(C0347R.id.configBottomRMV);
        int i = android.R.layout.simple_spinner_item;
        if (z) {
            arrayAdapter = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_config.18
                @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
                public View getDropDownView(int i2, View view, ViewGroup viewGroup) {
                    View dropDownView = super.getDropDownView(i2, view, viewGroup);
                    ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                    return dropDownView;
                }
            };
            arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        } else {
            arrayAdapter = (ArrayAdapter) spinner.getAdapter();
            arrayAdapter.clear();
        }
        for (int i2 = 0; i2 <= 55; i2++) {
            float rmvValue = Settings.rmvValue(i2, this.settings.RMVs == 1);
            if (this.settings.RMVs == 1) {
                format2 = "" + ((int) rmvValue) + "ltr";
            } else {
                format2 = String.format("%.2f", Float.valueOf(rmvValue));
            }
            arrayAdapter.add(format2);
        }
        if (z) {
            spinner.setAdapter((SpinnerAdapter) arrayAdapter);
        }
        spinner.setSelection(this.settings.Brmv);
        Spinner spinner2 = (Spinner) findViewById(C0347R.id.configDecoRMV);
        if (z) {
            arrayAdapter2 = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_config.19
                @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
                public View getDropDownView(int i3, View view, ViewGroup viewGroup) {
                    View dropDownView = super.getDropDownView(i3, view, viewGroup);
                    ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                    return dropDownView;
                }
            };
            arrayAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        } else {
            arrayAdapter2 = (ArrayAdapter) spinner2.getAdapter();
            arrayAdapter2.clear();
        }
        for (int i3 = 0; i3 <= 55; i3++) {
            float rmvValue2 = Settings.rmvValue(i3, this.settings.RMVs == 1);
            if (this.settings.RMVs == 1) {
                format = "" + ((int) rmvValue2) + "ltr";
            } else {
                format = String.format("%.2f", Float.valueOf(rmvValue2));
            }
            arrayAdapter2.add(format);
        }
        if (z) {
            spinner2.setAdapter((SpinnerAdapter) arrayAdapter2);
        }
        spinner2.setSelection(this.settings.Drmv);
    }

    private void populateForMSpinners(boolean z) {
        ArrayAdapter<String> arrayAdapter;
        ArrayAdapter<String> arrayAdapter2;
        ArrayAdapter<String> arrayAdapter3;
        ArrayAdapter<String> arrayAdapter4;
        ArrayAdapter<String> arrayAdapter5;
        ArrayAdapter<String> arrayAdapter6;
        ArrayAdapter<String> arrayAdapter7;
        Spinner spinner;
        ArrayAdapter<String> arrayAdapter8;
        Spinner spinner2 = (Spinner) findViewById(C0347R.id.configStepSize);
        int i = android.R.layout.simple_spinner_item;
        if (z) {
            arrayAdapter = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_config.20
                @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
                public View getDropDownView(int i2, View view, ViewGroup viewGroup) {
                    View dropDownView = super.getDropDownView(i2, view, viewGroup);
                    ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                    return dropDownView;
                }
            };
            arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        } else {
            arrayAdapter = (ArrayAdapter) spinner2.getAdapter();
            arrayAdapter.clear();
        }
        int i2 = 0;
        if (this.settings.Metric) {
            for (int i3 = 0; i3 <= 4; i3++) {
                arrayAdapter.add(String.format("%.1fm", Float.valueOf(Settings.lastStopValue(i3, true))));
            }
        } else {
            for (int i4 = 0; i4 <= 4; i4++) {
                arrayAdapter.add(String.valueOf((int) Settings.lastStopValue(i4, false)) + "ft");
            }
        }
        if (z) {
            spinner2.setAdapter((SpinnerAdapter) arrayAdapter);
        }
        spinner2.setSelection(this.settings.Step);
        Spinner spinner3 = (Spinner) findViewById(C0347R.id.configLastOC);
        if (z) {
            arrayAdapter2 = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_config.21
                @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
                public View getDropDownView(int i5, View view, ViewGroup viewGroup) {
                    View dropDownView = super.getDropDownView(i5, view, viewGroup);
                    ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                    return dropDownView;
                }
            };
            arrayAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        } else {
            arrayAdapter2 = (ArrayAdapter) spinner3.getAdapter();
            arrayAdapter2.clear();
        }
        if (this.settings.Metric) {
            for (int i5 = 0; i5 <= 4; i5++) {
                arrayAdapter2.add(String.format("%.1fm", Float.valueOf(Settings.lastStopValue(i5, true))));
            }
        } else {
            for (int i6 = 0; i6 <= 4; i6++) {
                arrayAdapter2.add(String.valueOf((int) Settings.lastStopValue(i6, false)) + "ft");
            }
        }
        if (z) {
            spinner3.setAdapter((SpinnerAdapter) arrayAdapter2);
        }
        spinner3.setSelection(this.settings.Last);
        Spinner spinner4 = (Spinner) findViewById(C0347R.id.configLastCCR);
        if (z) {
            arrayAdapter3 = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_config.22
                @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
                public View getDropDownView(int i7, View view, ViewGroup viewGroup) {
                    View dropDownView = super.getDropDownView(i7, view, viewGroup);
                    ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                    return dropDownView;
                }
            };
            arrayAdapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        } else {
            arrayAdapter3 = (ArrayAdapter) spinner4.getAdapter();
            arrayAdapter3.clear();
        }
        if (this.settings.Metric) {
            for (int i7 = 0; i7 <= 4; i7++) {
                arrayAdapter3.add(String.format("%.1fm", Float.valueOf(Settings.lastStopValue(i7, true))));
            }
        } else {
            for (int i8 = 0; i8 <= 4; i8++) {
                arrayAdapter3.add(String.valueOf((int) Settings.lastStopValue(i8, false)) + "ft");
            }
        }
        if (z) {
            spinner4.setAdapter((SpinnerAdapter) arrayAdapter3);
        }
        spinner4.setSelection(this.settings.LastCC);
        Spinner spinner5 = (Spinner) findViewById(C0347R.id.configO2Depth);
        if (z) {
            arrayAdapter4 = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_config.23
                @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
                public View getDropDownView(int i9, View view, ViewGroup viewGroup) {
                    View dropDownView = super.getDropDownView(i9, view, viewGroup);
                    ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                    return dropDownView;
                }
            };
            arrayAdapter4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        } else {
            arrayAdapter4 = (ArrayAdapter) spinner5.getAdapter();
            arrayAdapter4.clear();
        }
        if (this.settings.Metric) {
            for (int i9 = 0; i9 <= 4; i9++) {
                arrayAdapter4.add(String.format("%.1fm", Float.valueOf(Settings.lastStopValue(i9, true))));
            }
        } else {
            for (int i10 = 0; i10 <= 4; i10++) {
                arrayAdapter4.add(String.valueOf((int) Settings.lastStopValue(i10, false)) + "ft");
            }
        }
        if (z) {
            spinner5.setAdapter((SpinnerAdapter) arrayAdapter4);
        }
        spinner5.setSelection(this.settings.MaxO2);
        Spinner spinner6 = (Spinner) findViewById(C0347R.id.ConfigDescent);
        if (z) {
            arrayAdapter5 = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_config.24
                @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
                public View getDropDownView(int i11, View view, ViewGroup viewGroup) {
                    View dropDownView = super.getDropDownView(i11, view, viewGroup);
                    ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                    return dropDownView;
                }
            };
            arrayAdapter5.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        } else {
            arrayAdapter5 = (ArrayAdapter) spinner6.getAdapter();
            arrayAdapter5.clear();
        }
        if (this.settings.Metric) {
            for (int i11 = 0; i11 <= 25; i11++) {
                arrayAdapter5.add(Settings.rateValue(i11, this.settings.Metric) + " mpm");
            }
        } else {
            for (int i12 = 0; i12 <= 25; i12++) {
                arrayAdapter5.add(Settings.rateValue(i12, this.settings.Metric) + " fpm");
            }
        }
        if (z) {
            spinner6.setAdapter((SpinnerAdapter) arrayAdapter5);
        }
        spinner6.setSelection(this.settings.descent);
        if (this.settings.ascent < 255) {
            Settings settings = this.settings;
            settings.ascent = (settings.ascent << 24) + (this.settings.ascent << 16) + (this.settings.ascent << 8) + this.settings.ascent;
        }
        for (int i13 = 1; i13 < 4; i13++) {
            if (i13 == 3) {
                spinner = (Spinner) findViewById(C0347R.id.ConfigAscentSurf);
            } else if (i13 == 2) {
                spinner = (Spinner) findViewById(C0347R.id.ConfigAscentDeco);
            } else {
                spinner = (Spinner) findViewById(C0347R.id.ConfigAscentAsc);
            }
            if (z) {
                arrayAdapter8 = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_config.25
                    @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
                    public View getDropDownView(int i14, View view, ViewGroup viewGroup) {
                        View dropDownView = super.getDropDownView(i14, view, viewGroup);
                        ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                        return dropDownView;
                    }
                };
                arrayAdapter8.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            } else {
                arrayAdapter8 = (ArrayAdapter) spinner.getAdapter();
                arrayAdapter8.clear();
            }
            if (this.settings.Metric) {
                for (int i14 = 0; i14 <= 25; i14++) {
                    arrayAdapter8.add(Settings.rateValue(i14, this.settings.Metric) + " mpm");
                }
            } else {
                for (int i15 = 0; i15 <= 25; i15++) {
                    arrayAdapter8.add(Settings.rateValue(i15, this.settings.Metric) + " fpm");
                }
            }
            if (z) {
                spinner.setAdapter((SpinnerAdapter) arrayAdapter8);
            }
            spinner.setSelection((this.settings.ascent >> (i13 * 8)) & 255);
        }
        Spinner spinner7 = (Spinner) findViewById(C0347R.id.ConfigElevation);
        if (z) {
            arrayAdapter6 = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_config.26
                @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
                public View getDropDownView(int i16, View view, ViewGroup viewGroup) {
                    View dropDownView = super.getDropDownView(i16, view, viewGroup);
                    ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                    return dropDownView;
                }
            };
            arrayAdapter6.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        } else {
            arrayAdapter6 = (ArrayAdapter) spinner7.getAdapter();
            arrayAdapter6.clear();
        }
        if (this.settings.Metric) {
            for (int i16 = 0; i16 <= 2400; i16 += 75) {
                arrayAdapter6.add(i16 + "m");
            }
        } else {
            for (int i17 = 0; i17 <= 8000; i17 += 250) {
                arrayAdapter6.add(i17 + "ft");
            }
        }
        if (z) {
            spinner7.setAdapter((SpinnerAdapter) arrayAdapter6);
        }
        spinner7.setSelection(this.settings.Alt);
        Spinner spinner8 = (Spinner) findViewById(C0347R.id.ConfigAcclim);
        if (z) {
            arrayAdapter7 = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_config.27
                @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
                public View getDropDownView(int i18, View view, ViewGroup viewGroup) {
                    View dropDownView = super.getDropDownView(i18, view, viewGroup);
                    ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                    return dropDownView;
                }
            };
            arrayAdapter7.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        } else {
            arrayAdapter7 = (ArrayAdapter) spinner8.getAdapter();
            arrayAdapter7.clear();
        }
        if (this.settings.Metric) {
            while (i2 <= 2400) {
                arrayAdapter7.add(i2 + "m");
                i2 += 75;
            }
        } else {
            while (i2 <= 8000) {
                arrayAdapter7.add(i2 + "ft");
                i2 += 250;
            }
        }
        if (z) {
            spinner8.setAdapter((SpinnerAdapter) arrayAdapter7);
        }
        spinner8.setSelection(this.settings.FromAlt);
    }

    private void conserveViews(int i) {
        switch (i) {
            case 1:
            case 2:
            case 3:
                ((LinearLayout) findViewById(C0347R.id.ConfigRowConserve)).setVisibility(0);
                ((TextView) findViewById(C0347R.id.ConfigRowConserveHelp)).setVisibility(0);
                findViewById(C0347R.id.ConfigRowConserveDivider).setVisibility(0);
                ((LinearLayout) findViewById(C0347R.id.ConfigRowConserveGF)).setVisibility(8);
                ((TextView) findViewById(C0347R.id.ConfigRowConserveGFHelp)).setVisibility(8);
                findViewById(C0347R.id.ConfigRowConserveGFDivider).setVisibility(8);
                ((LinearLayout) findViewById(C0347R.id.ConfigRowConserveGFS)).setVisibility(8);
                ((TextView) findViewById(C0347R.id.ConfigRowConserveGFSHelp)).setVisibility(8);
                findViewById(C0347R.id.ConfigRowConserveGFSDivider).setVisibility(8);
                break;
            case 4:
                ((LinearLayout) findViewById(C0347R.id.ConfigRowConserve)).setVisibility(0);
                ((TextView) findViewById(C0347R.id.ConfigRowConserveHelp)).setVisibility(0);
                findViewById(C0347R.id.ConfigRowConserveDivider).setVisibility(0);
                ((LinearLayout) findViewById(C0347R.id.ConfigRowConserveGF)).setVisibility(8);
                ((TextView) findViewById(C0347R.id.ConfigRowConserveGFHelp)).setVisibility(8);
                findViewById(C0347R.id.ConfigRowConserveGFDivider).setVisibility(8);
                ((LinearLayout) findViewById(C0347R.id.ConfigRowConserveGFS)).setVisibility(0);
                ((TextView) findViewById(C0347R.id.ConfigRowConserveGFSHelp)).setVisibility(0);
                findViewById(C0347R.id.ConfigRowConserveGFSDivider).setVisibility(0);
                break;
            case 5:
            case 6:
                ((LinearLayout) findViewById(C0347R.id.ConfigRowConserve)).setVisibility(8);
                ((TextView) findViewById(C0347R.id.ConfigRowConserveHelp)).setVisibility(8);
                findViewById(C0347R.id.ConfigRowConserveDivider).setVisibility(8);
                ((LinearLayout) findViewById(C0347R.id.ConfigRowConserveGF)).setVisibility(0);
                ((TextView) findViewById(C0347R.id.ConfigRowConserveGFHelp)).setVisibility(0);
                findViewById(C0347R.id.ConfigRowConserveGFDivider).setVisibility(0);
                ((LinearLayout) findViewById(C0347R.id.ConfigRowConserveGFS)).setVisibility(8);
                ((TextView) findViewById(C0347R.id.ConfigRowConserveGFSHelp)).setVisibility(8);
                findViewById(C0347R.id.ConfigRowConserveGFSDivider).setVisibility(8);
                break;
        }
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
        if (!this.isIniting && adapterView.getId() == C0347R.id.configModel) {
            conserveViews(i + 1);
        }
    }

    @Override // android.app.Activity
    protected void onPause() {
        super.onPause();
        saveSettings();
    }

    private void saveSettings() {
        if (((CompoundButton) findViewById(C0347R.id.ConfigCircuitOC)).isChecked()) {
            this.settings.OC_CCR = 0;
        } else {
            this.settings.OC_CCR = 1;
        }
        this.settings.VPMModel = ((Spinner) findViewById(C0347R.id.configModel)).getSelectedItemPosition() + 1;
        this.settings.Margin = ((Spinner) findViewById(C0347R.id.configConserve)).getSelectedItemPosition();
        this.settings.GFLo = 100 - (((Spinner) findViewById(C0347R.id.configConserveGFLo)).getSelectedItemPosition() * 5);
        this.settings.GFHi = 100 - (((Spinner) findViewById(C0347R.id.configConserveGFHi)).getSelectedItemPosition() * 5);
        this.settings.GFS = 100 - (((Spinner) findViewById(C0347R.id.configConserveGFS)).getSelectedItemPosition() * 5);
        if (this.settings.GFHi < this.settings.GFLo) {
            Settings settings = this.settings;
            settings.GFHi = settings.GFLo;
        }
        this.settings.OxyNarc = ((ToggleButton) findViewById(C0347R.id.ConfigO2Narcotic)).isChecked();
        this.settings.Metric = ((CompoundButton) findViewById(C0347R.id.ConfigMeter)).isChecked();
        if (((CompoundButton) findViewById(C0347R.id.ConfigSalt)).isChecked()) {
            this.settings.WaterType = 0;
        } else {
            this.settings.WaterType = 1;
        }
        if (((CompoundButton) findViewById(C0347R.id.ConfigCuFt)).isChecked()) {
            this.settings.RMVs = 0;
        } else {
            this.settings.RMVs = 1;
        }
        this.settings.Brmv = ((Spinner) findViewById(C0347R.id.configBottomRMV)).getSelectedItemPosition();
        this.settings.Drmv = ((Spinner) findViewById(C0347R.id.configDecoRMV)).getSelectedItemPosition();
        if (((CompoundButton) findViewById(C0347R.id.ConfigCircuitBAR)).isChecked()) {
            this.settings.SetpointUnits = 0;
        } else {
            this.settings.SetpointUnits = 1;
        }
        this.settings.Step = ((Spinner) findViewById(C0347R.id.configStepSize)).getSelectedItemPosition();
        this.settings.Last = ((Spinner) findViewById(C0347R.id.configLastOC)).getSelectedItemPosition();
        this.settings.LastCC = ((Spinner) findViewById(C0347R.id.configLastCCR)).getSelectedItemPosition();
        this.settings.MaxO2 = ((Spinner) findViewById(C0347R.id.configO2Depth)).getSelectedItemPosition();
        this.settings.descent = ((Spinner) findViewById(C0347R.id.ConfigDescent)).getSelectedItemPosition();
        this.settings.ascent = (((Spinner) findViewById(C0347R.id.ConfigAscentAsc)).getSelectedItemPosition() << 8) + (((Spinner) findViewById(C0347R.id.ConfigAscentDeco)).getSelectedItemPosition() << 16) + (((Spinner) findViewById(C0347R.id.ConfigAscentSurf)).getSelectedItemPosition() << 24) + (this.settings.ascent & 255);
        this.settings.Alt = ((Spinner) findViewById(C0347R.id.ConfigElevation)).getSelectedItemPosition();
        this.settings.FromAlt = ((Spinner) findViewById(C0347R.id.ConfigAcclim)).getSelectedItemPosition();
        this.settings.StopTime = ((Spinner) findViewById(C0347R.id.configStopTime)).getSelectedItemPosition();
        this.settings.ppO2 = ((Spinner) findViewById(C0347R.id.configppO2Swap16)).getSelectedItemPosition();
        this.settings.ppO2Deep = ((Spinner) findViewById(C0347R.id.configppO2Swap15)).getSelectedItemPosition();
        this.settings.ppO2ReallyDeep = ((Spinner) findViewById(C0347R.id.configppO2Swap14)).getSelectedItemPosition();
        this.settings.HalfTimeDeep = ((CompoundButton) findViewById(C0347R.id.ConfigO2FirstStop30sec)).isChecked();
        this.settings.DoubleSizeDeep = ((CompoundButton) findViewById(C0347R.id.ConfigO2FirstStop2x)).isChecked();
        this.settings.Extend = ((CompoundButton) findViewById(C0347R.id.ConfigExtendOnOff)).isChecked();
        this.settings.ExtStop = ((Spinner) findViewById(C0347R.id.ConfigExtendShallow)).getSelectedItemPosition();
        this.settings.ExtStopDeep = ((Spinner) findViewById(C0347R.id.configExtendDeep)).getSelectedItemPosition();
        this.settings.ExtendAdd = ((CompoundButton) findViewById(C0347R.id.ConfigAddToStop)).isChecked();
        this.settings.ExtendAlways = ((CompoundButton) findViewById(C0347R.id.ConfigAddAllMix)).isChecked();
        this.settings.O2Affect = ((CompoundButton) findViewById(C0347R.id.ConfigAddO2Window)).isChecked();
        this.settings.GuageType = ((CompoundButton) findViewById(C0347R.id.ConfigGuagetypeDigital)).isChecked();
        this.settings.Alerts = 0;
        if (((CompoundButton) findViewById(C0347R.id.ConfigToggleppO2Above)).isChecked()) {
            this.settings.Alerts |= 1;
        }
        if (((CompoundButton) findViewById(C0347R.id.ConfigToggleppO2Below)).isChecked()) {
            this.settings.Alerts |= 2;
        }
        if (((CompoundButton) findViewById(C0347R.id.ConfigToggleOTUAbove)).isChecked()) {
            this.settings.Alerts |= 4;
        }
        if (((CompoundButton) findViewById(C0347R.id.ConfigToggleCNSAbove)).isChecked()) {
            this.settings.Alerts |= 8;
        }
        if (((CompoundButton) findViewById(C0347R.id.ConfigToggleIBCDN2Warn)).isChecked()) {
            this.settings.Alerts |= 16;
        }
        if (((CompoundButton) findViewById(C0347R.id.ConfigToggleIBCDHeWarn)).isChecked()) {
            this.settings.Alerts |= 32;
        }
        if (((CompoundButton) findViewById(C0347R.id.ConfigToggleCCRDilCheck)).isChecked()) {
            this.settings.Alerts |= 64;
        }
        this.settings.ppO2Above = (((Spinner) findViewById(C0347R.id.ConfigppO2Above)).getSelectedItemPosition() * 5) + 100;
        this.settings.ppO2Below = ((Spinner) findViewById(C0347R.id.ConfigppO2Below)).getSelectedItemPosition() + 10;
        this.settings.OTUHigh = (((Spinner) findViewById(C0347R.id.ConfigOTUAbove)).getSelectedItemPosition() * 25) + 100;
        this.settings.CNSHigh = (((Spinner) findViewById(C0347R.id.ConfigCNSAbove)).getSelectedItemPosition() * 5) + 50;
        this.settings.ppN2High = ((Spinner) findViewById(C0347R.id.ConfigIBCDN2Warn)).getSelectedItemPosition() * 10;
        this.settings.ppHeHigh = ((Spinner) findViewById(C0347R.id.ConfigIBCDHeWarn)).getSelectedItemPosition() * 10;
        this.settings.saveConfig();
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        if (this.isIniting) {
            return;
        }
        int id = view.getId();
        if (id == C0347R.id.ConfigCuFt || id == C0347R.id.ConfigLtr) {
            if (((CompoundButton) findViewById(C0347R.id.ConfigCuFt)).isChecked()) {
                this.settings.RMVs = 0;
            } else {
                this.settings.RMVs = 1;
            }
            this.settings.Brmv = ((Spinner) findViewById(C0347R.id.configBottomRMV)).getSelectedItemPosition();
            this.settings.Drmv = ((Spinner) findViewById(C0347R.id.configDecoRMV)).getSelectedItemPosition();
            this.isIniting = true;
            populateRMVSpinners(false);
            this.isIniting = false;
            return;
        }
        if (id == C0347R.id.ConfigExtendOnOff) {
            this.settings.Extend = !r5.Extend;
            findViewById(C0347R.id.ConfigExtendShallow).setEnabled(this.settings.Extend);
            findViewById(C0347R.id.configExtendDeep).setEnabled(this.settings.Extend);
            findViewById(C0347R.id.ConfigAddToStop).setEnabled(this.settings.Extend);
            findViewById(C0347R.id.ConfigAddAllMix).setEnabled(this.settings.Extend);
            findViewById(C0347R.id.ConfigAddO2Window).setEnabled(this.settings.Extend);
            findViewById(C0347R.id.ConfigExtendShallowText).setEnabled(this.settings.Extend);
            findViewById(C0347R.id.ConfigExtendDeepText).setEnabled(this.settings.Extend);
            findViewById(C0347R.id.ConfigAddToStopText).setEnabled(this.settings.Extend);
            findViewById(C0347R.id.ConfigAddAllMixText).setEnabled(this.settings.Extend);
            findViewById(C0347R.id.ConfigAddO2WindowText).setEnabled(this.settings.Extend);
            findViewById(C0347R.id.ConfigRowAddToStopHelp).setEnabled(this.settings.Extend);
            findViewById(C0347R.id.ConfigRowExtendAnyHelp).setEnabled(this.settings.Extend);
            return;
        }
        if (id == C0347R.id.ConfigFeet || id == C0347R.id.ConfigMeter) {
            this.settings.Metric = ((CompoundButton) findViewById(C0347R.id.ConfigMeter)).isChecked();
            this.isIniting = true;
            populateForMSpinners(false);
            this.isIniting = false;
            setForMLabels();
            return;
        }
        if (id == C0347R.id.ConfigReset) {
            this.settings.resetConfig();
            this.isIniting = true;
            this.isReset = true;
            initForm();
            setForMLabels();
            view.invalidate();
            this.isReset = false;
            this.isIniting = false;
            Toast.makeText(this, getString(C0347R.string.configResetStr), 0).show();
        }
    }

    private void setForMLabels() {
        if (this.settings.Metric) {
            ((TextView) findViewById(C0347R.id.ConfigTextFirstStop2x)).setText(getString(C0347R.string.configFirstStop2xm));
            ((TextView) findViewById(C0347R.id.ConfigExtendShallowText)).setText(getString(C0347R.string.configExtendShallowm));
            ((TextView) findViewById(C0347R.id.ConfigExtendDeepText)).setText(getString(C0347R.string.configExtendDeepm));
        } else {
            ((TextView) findViewById(C0347R.id.ConfigTextFirstStop2x)).setText(getString(C0347R.string.configFirstStop2xft));
            ((TextView) findViewById(C0347R.id.ConfigExtendShallowText)).setText(getString(C0347R.string.configExtendShallowft));
            ((TextView) findViewById(C0347R.id.ConfigExtendDeepText)).setText(getString(C0347R.string.configExtendDeepft));
        }
    }

    @Override // android.app.Activity
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, 446221, 0, "Web FAQ").setIcon(android.R.drawable.ic_menu_help);
        return true;
    }

    @Override // android.app.Activity
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 446221) {
            return false;
        }
        Intent intent = new Intent();
        intent.setAction("android.intent.action.VIEW");
        intent.addCategory("android.intent.category.BROWSABLE");
        intent.setData(Uri.parse(getString(C0347R.string.mobile_faq)));
        startActivity(intent);
        return true;
    }
}
