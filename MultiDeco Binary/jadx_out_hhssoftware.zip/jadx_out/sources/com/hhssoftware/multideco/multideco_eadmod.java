package com.hhssoftware.multideco;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.os.MessageQueue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import androidx.core.view.ViewCompat;

/* loaded from: classes.dex */
public class multideco_eadmod extends Activity implements AdapterView.OnItemSelectedListener, MessageQueue.IdleHandler {
    private Boolean isIniting;
    private Settings settings;

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public void onNothingSelected(AdapterView<?> adapterView) {
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        setTheme(new Theme_setting(this).theme_id);
        super.onCreate(bundle);
        setContentView(C0347R.layout.multideco_eadmod);
        this.settings = new Settings(this);
        this.isIniting = true;
        initForm();
        this.isIniting = false;
        performCalc();
    }

    private void initForm() {
        String str;
        int i;
        if (Build.VERSION.SDK_INT < 35) {
            findViewById(C0347R.id.multideco_eadmod_xml).setPadding(0, 0, 0, 0);
        }
        if (this.settings.Metric) {
            str = " m";
        } else {
            str = " ft";
        }
        if (this.settings.OC_CCR != 1) {
            findViewById(C0347R.id.EADMODRowSP).setVisibility(8);
        }
        Spinner spinner = (Spinner) findViewById(C0347R.id.eadmodO2);
        int i2 = android.R.layout.simple_spinner_item;
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, i2) { // from class: com.hhssoftware.multideco.multideco_eadmod.1
            @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
            public View getDropDownView(int i3, View view, ViewGroup viewGroup) {
                View dropDownView = super.getDropDownView(i3, view, viewGroup);
                ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                return dropDownView;
            }
        };
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        int i3 = 1;
        while (true) {
            if (i3 > 100) {
                break;
            }
            arrayAdapter.add(i3 + "%");
            i3++;
        }
        spinner.setAdapter((SpinnerAdapter) arrayAdapter);
        spinner.setSelection(20);
        spinner.setOnItemSelectedListener(this);
        Spinner spinner2 = (Spinner) findViewById(C0347R.id.eadmodHe);
        ArrayAdapter<String> arrayAdapter2 = new ArrayAdapter<String>(this, i2) { // from class: com.hhssoftware.multideco.multideco_eadmod.2
            @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
            public View getDropDownView(int i4, View view, ViewGroup viewGroup) {
                View dropDownView = super.getDropDownView(i4, view, viewGroup);
                ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                return dropDownView;
            }
        };
        arrayAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        for (int i4 = 0; i4 <= 99; i4++) {
            arrayAdapter2.add(i4 + "%");
        }
        spinner2.setAdapter((SpinnerAdapter) arrayAdapter2);
        spinner2.setSelection(0);
        spinner2.setOnItemSelectedListener(this);
        Spinner spinner3 = (Spinner) findViewById(C0347R.id.eadmodDepth);
        ArrayAdapter<String> arrayAdapter3 = new ArrayAdapter<String>(this, i2) { // from class: com.hhssoftware.multideco.multideco_eadmod.3
            @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
            public View getDropDownView(int i5, View view, ViewGroup viewGroup) {
                View dropDownView = super.getDropDownView(i5, view, viewGroup);
                ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                return dropDownView;
            }
        };
        arrayAdapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        int i5 = this.settings.Metric ? 2 : 5;
        for (int i6 = 10; i6 <= 80; i6++) {
            arrayAdapter3.add((i6 * i5) + str);
        }
        spinner3.setAdapter((SpinnerAdapter) arrayAdapter3);
        spinner3.setSelection(10);
        spinner3.setOnItemSelectedListener(this);
        Spinner spinner4 = (Spinner) findViewById(C0347R.id.eadmodppO2);
        ArrayAdapter<String> arrayAdapter4 = new ArrayAdapter<String>(this, i2) { // from class: com.hhssoftware.multideco.multideco_eadmod.4
            @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
            public View getDropDownView(int i7, View view, ViewGroup viewGroup) {
                View dropDownView = super.getDropDownView(i7, view, viewGroup);
                ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                return dropDownView;
            }
        };
        arrayAdapter4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        for (int i7 = 100; i7 <= 180; i7 += 5) {
            arrayAdapter4.add(String.format("%.2f", Double.valueOf(i7 * 0.01d)));
        }
        spinner4.setAdapter((SpinnerAdapter) arrayAdapter4);
        spinner4.setSelection(8);
        spinner4.setOnItemSelectedListener(this);
        if (this.settings.OC_CCR == 1) {
            Spinner spinner5 = (Spinner) findViewById(C0347R.id.eadmodSP);
            ArrayAdapter<String> arrayAdapter5 = new ArrayAdapter<String>(this, i2) { // from class: com.hhssoftware.multideco.multideco_eadmod.5
                @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
                public View getDropDownView(int i8, View view, ViewGroup viewGroup) {
                    View dropDownView = super.getDropDownView(i8, view, viewGroup);
                    ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                    return dropDownView;
                }
            };
            arrayAdapter5.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            for (i = 100; i <= 180; i += 5) {
                arrayAdapter5.add(String.format("%.2f", Double.valueOf(i * 0.01d)));
            }
            spinner5.setAdapter((SpinnerAdapter) arrayAdapter5);
            spinner5.setSelection(5);
            spinner5.setOnItemSelectedListener(this);
        }
    }

    private void performCalc() {
        if (this.isIniting.booleanValue()) {
            return;
        }
        this.isIniting = true;
        String[] strArr = new String[14];
        int selectedItemPosition = ((Spinner) findViewById(C0347R.id.eadmodO2)).getSelectedItemPosition() + 1;
        int selectedItemPosition2 = ((Spinner) findViewById(C0347R.id.eadmodHe)).getSelectedItemPosition();
        if (selectedItemPosition + selectedItemPosition2 > 100) {
            if (findViewById(C0347R.id.eadmodO2).isFocused()) {
                ((Spinner) findViewById(C0347R.id.eadmodHe)).setSelection(100 - selectedItemPosition);
            } else {
                ((Spinner) findViewById(C0347R.id.eadmodO2)).setSelection(99 - selectedItemPosition2);
            }
        }
        strArr[0] = "241";
        strArr[1] = Boolean.toString(this.settings.Metric);
        strArr[2] = ((Spinner) findViewById(C0347R.id.eadmodDepth)).getSelectedItemPosition() + "";
        strArr[3] = ((Spinner) findViewById(C0347R.id.eadmodO2)).getSelectedItemPosition() + "";
        strArr[4] = ((Spinner) findViewById(C0347R.id.eadmodHe)).getSelectedItemPosition() + "";
        strArr[5] = ((Spinner) findViewById(C0347R.id.eadmodSP)).getSelectedItemPosition() + "";
        strArr[6] = "";
        strArr[7] = "";
        strArr[8] = "";
        strArr[9] = "";
        strArr[10] = "";
        strArr[11] = Boolean.toString(this.settings.OC_CCR == 1);
        strArr[12] = ((Spinner) findViewById(C0347R.id.eadmodppO2)).getSelectedItemPosition() + "";
        strArr[13] = Boolean.toString(this.settings.WaterType > 0);
        String[] performCalc = new tools_calc().performCalc(strArr);
        if (Boolean.parseBoolean(performCalc[6])) {
            findViewById(C0347R.id.TextEadModSP).setBackgroundColor(this.settings.warn_colors[6] | ViewCompat.MEASURED_STATE_MASK);
        } else {
            findViewById(C0347R.id.TextEadModSP).setBackgroundColor(0);
        }
        ((EditText) findViewById(C0347R.id.eadmodmod)).setText(performCalc[7]);
        ((EditText) findViewById(C0347R.id.eadmodend)).setText(performCalc[8]);
        ((EditText) findViewById(C0347R.id.eadmodead)).setText(performCalc[9]);
        ((EditText) findViewById(C0347R.id.eadmodeadd)).setText(performCalc[10]);
        Looper.myQueue().addIdleHandler(this);
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
        performCalc();
    }

    @Override // android.os.MessageQueue.IdleHandler
    public boolean queueIdle() {
        this.isIniting = false;
        return false;
    }
}
