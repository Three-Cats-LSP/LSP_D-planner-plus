package com.hhssoftware.multideco;

/* loaded from: classes.dex */
public class tools_calc {
    private final int BESTMIX = Settings.ERR_STOPTOOBIG;
    private final int EADMOD = 241;
    private final int NITROX = 36;
    private final int TRIMIX = 752;
    private final int TOPUP = 725;
    private final int CAPACITY = 9999;
    private final int DENSITY = 787;
    private final int tgAir = 0;
    private final int tgO2 = 1;
    private final int tgN2 = 2;
    private final int tgHe = 3;
    private final int tgEAN32 = 4;
    private final double SLP_SW_f = 33.066d;
    private final double SLP_SW_m = 10.078d;
    private final double SLP_FW_f = 33.914d;
    private final double SLP_FW_m = 10.337d;
    private final double[] O2ZFactor = {1.0d, 0.995d, 0.99d, 0.986d, 0.981d, 0.977d, 0.973d, 0.969d, 0.966d, 0.962d, 0.959d, 0.956d, 0.954d, 0.951d, 0.949d, 0.947d, 0.945d, 0.944d, 0.943d, 0.942d, 0.941d, 0.94d, 0.94d, 0.94d, 0.941d, 0.941d, 0.942d, 0.943d, 0.944d, 0.945d, 0.947d, 0.948d, 0.95d, 0.953d, 0.955d, 0.957d, 0.96d, 0.963d, 0.966d, 0.969d, 0.972d};
    private final double[] HeZFactor = {1.0d, 1.004d, 1.007d, 1.011d, 1.015d, 1.018d, 1.022d, 1.026d, 1.029d, 1.033d, 1.036d, 1.04d, 1.043d, 1.047d, 1.05d, 1.054d, 1.057d, 1.061d, 1.064d, 1.067d, 1.071d, 1.074d, 1.078d, 1.081d, 1.084d, 1.088d, 1.091d, 1.094d, 1.097d, 1.101d, 1.104d, 1.107d, 1.11d, 1.114d, 1.117d, 1.12d, 1.123d, 1.127d, 1.13d, 1.133d, 1.136d};
    private final double[] N2ZFactor = {1.0d, 0.998d, 0.997d, 0.995d, 0.994d, 0.993d, 0.993d, 0.993d, 0.993d, 0.993d, 0.994d, 0.995d, 0.996d, 0.997d, 0.999d, 1.001d, 1.003d, 1.005d, 1.008d, 1.011d, 1.014d, 1.017d, 1.021d, 1.024d, 1.028d, 1.032d, 1.036d, 1.041d, 1.045d, 1.05d, 1.054d, 1.059d, 1.064d, 1.069d, 1.074d, 1.08d, 1.085d, 1.091d, 1.096d, 1.102d, 1.107d};
    private final double[] AirZFactor = {1.0d, 0.997d, 0.995d, 0.993d, 0.991d, 0.99d, 0.989d, 0.988d, 0.987d, 0.987d, 0.986d, 0.987d, 0.987d, 0.988d, 0.988d, 0.99d, 0.991d, 0.992d, 0.994d, 0.996d, 0.999d, 1.001d, 1.004d, 1.007d, 1.01d, 1.013d, 1.016d, 1.02d, 1.024d, 1.028d, 1.032d, 1.036d, 1.04d, 1.045d, 1.049d, 1.054d, 1.059d, 1.064d, 1.069d, 1.074d, 1.079d};
    public Boolean banked32 = false;

    /* JADX WARN: Removed duplicated region for block: B:14:0x0079  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private double gasZ(int i, double d, int i2, int i3) {
        double d2;
        double[] dArr = {9.0E-4d, 0.0015d, 0.0d, 4.0E-4d, 9.0E-4d};
        double d3 = 0.0d;
        double min = Math.min(4000.0d, Math.max(0.0d, i2 == 0 ? 14.7d * d : d));
        double d4 = ((i3 * 5) - 20) * dArr[i];
        int round = (int) Math.round(0.01d * min);
        if (i == 0) {
            d2 = this.AirZFactor[round];
        } else if (i == 1) {
            d2 = this.O2ZFactor[round];
        } else if (i == 2) {
            d2 = this.N2ZFactor[round];
        } else if (i == 3) {
            d2 = this.HeZFactor[round];
        } else {
            if (i == 4) {
                double d5 = this.N2ZFactor[round];
                double d6 = this.O2ZFactor[round];
                d3 = ((d5 - d6) * 0.68d) + d6;
            }
            if (i != 0) {
                if (i == 1) {
                    return d3 * (((Math.max(min, 2500.0d) / 2500.0d) * d4) + 1.0d);
                }
                if (i == 3) {
                    return d3 * (1.0d - ((min / 4000.0d) * d4));
                }
                if (i != 4) {
                    return d3;
                }
            }
            return d3 * (((Math.max(min, 2500.0d) / 2500.0d) * d4) + 1.0d);
        }
        d3 = d2;
        if (i != 0) {
        }
        return d3 * (((Math.max(min, 2500.0d) / 2500.0d) * d4) + 1.0d);
    }

    /* JADX WARN: Code restructure failed: missing block: B:144:0x0664, code lost:
    
        if (r23 > 0.999d) goto L157;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public String[] performCalc(String[] strArr) {
        double d;
        double d2;
        int i;
        double gasZ;
        double gasZ2;
        double d3;
        int i2;
        double d4;
        int i3;
        String str;
        double d5;
        double d6;
        double d7;
        double d8;
        double d9;
        double d10;
        double d11;
        int parseInt = Integer.parseInt(strArr[0]);
        double d12 = 1.0d;
        if (parseInt == 36) {
            int parseInt2 = Integer.parseInt(strArr[1]);
            int parseInt3 = Integer.parseInt(strArr[8]);
            double d13 = parseInt2 == 1 ? 14.7d : 1.0d;
            double parseDouble = Double.parseDouble(strArr[2].replace(',', '.')) + d13;
            double parseDouble2 = Double.parseDouble(strArr[3].replace(',', '.')) + d13;
            double parseDouble3 = Double.parseDouble(strArr[4].replace(',', '.'));
            double parseDouble4 = Double.parseDouble(strArr[5].replace(',', '.'));
            if (this.banked32.booleanValue()) {
                d = (((parseDouble4 - 32.0d) / 68.0d) * parseDouble2) - (((parseDouble3 - 32.0d) / 68.0d) * parseDouble);
                d2 = 1.0d - (parseDouble4 * 0.01d);
                double d14 = parseDouble + d;
                i = parseInt2;
                gasZ = gasZ(4, d14, i, parseInt3);
                gasZ2 = gasZ(1, d14, i, parseInt3);
            } else {
                d = (((parseDouble4 - 21.0d) / 79.0d) * parseDouble2) - (((parseDouble3 - 21.0d) / 79.0d) * parseDouble);
                d2 = 1.0d - (parseDouble4 * 0.01d);
                double d15 = parseDouble + d;
                i = parseInt2;
                gasZ = gasZ(0, d15, i, parseInt3);
                gasZ2 = gasZ(1, d15, i, parseInt3);
            }
            double d16 = d * (1.0d - (d2 * (gasZ - gasZ2)));
            double d17 = parseDouble + d16;
            if (i == 0) {
                strArr[6] = String.format("%.1f%s%.1f%s", Double.valueOf(d16), "  (", Double.valueOf(d17 - d13), ")");
            } else {
                strArr[6] = String.format("%.0f%s%.0f%s", Double.valueOf(d16), "  (", Double.valueOf(d17 - d13), ")");
            }
            if (i == 0) {
                strArr[7] = String.format("%.1f%s%.1f%s", Double.valueOf(parseDouble2 - d17), "  (", Double.valueOf(parseDouble2 - d13), ")");
                return strArr;
            }
            strArr[7] = String.format("%.0f%s%.0f%s", Double.valueOf(parseDouble2 - d17), "  (", Double.valueOf(parseDouble2 - d13), ")");
            return strArr;
        }
        if (parseInt == 132) {
            if (Boolean.parseBoolean(strArr[1])) {
                d3 = Boolean.parseBoolean(strArr[7]) ? 10.337d : 10.078d;
                i2 = 2;
            } else {
                d3 = Boolean.parseBoolean(strArr[7]) ? 33.914d : 33.066d;
                i2 = 5;
            }
            double parseInt4 = (Integer.parseInt(strArr[2]) + 10) * i2;
            if (parseInt4 >= 1.0d) {
                double min = Math.min(1.0d, ((Integer.parseInt(strArr[3]) * 0.05d) + 0.5d) / ((parseInt4 / d3) + 1.0d));
                if (Boolean.parseBoolean(strArr[4])) {
                    double parseInt5 = (1.0d - min) - (((((Integer.parseInt(strArr[5]) + 10) * i2) + d3) / ((i2 * (Integer.parseInt(strArr[2]) + 10)) + d3)) * 0.79d);
                    r23 = parseInt5 >= 0.001d ? parseInt5 : 0.0d;
                }
                d12 = r23;
                if (d12 >= 0.01d) {
                    strArr[6] = String.format("%d/%d", Integer.valueOf((int) Math.round(min * 100.0d)), Integer.valueOf((int) Math.round(d12 * 100.0d)));
                    return strArr;
                }
                strArr[6] = String.format("%d%c", Integer.valueOf((int) Math.round(min * 100.0d)), '%');
                return strArr;
            }
        } else {
            if (parseInt == 241) {
                if (Boolean.parseBoolean(strArr[1])) {
                    d4 = Boolean.parseBoolean(strArr[13]) ? 10.337d : 10.078d;
                    i3 = 2;
                } else {
                    d4 = Boolean.parseBoolean(strArr[13]) ? 33.914d : 33.066d;
                    i3 = 5;
                }
                if (Boolean.parseBoolean(strArr[1])) {
                    str = " m";
                } else {
                    str = " ft";
                }
                double parseInt6 = (Integer.parseInt(strArr[3]) + 1) * 0.01d;
                double parseInt7 = Integer.parseInt(strArr[4]) * 0.01d;
                double d18 = (1.0d - parseInt6) - parseInt7;
                double parseInt8 = (i3 * (Integer.parseInt(strArr[2]) + 10)) + d4;
                double d19 = parseInt8 / d4;
                if (Boolean.parseBoolean(strArr[11])) {
                    double min2 = Math.min(1.0d, ((Integer.parseInt(strArr[5]) * 0.05d) + 1.0d) / d19);
                    strArr[6] = Boolean.toString(min2 < parseInt6);
                    d18 -= ((min2 - parseInt6) * d18) / (parseInt7 + d18);
                    parseInt7 = (1.0d - min2) - d18;
                    parseInt6 = min2;
                }
                double round = Math.round(((parseInt6 + d18) * parseInt8) - d4);
                if (round < 0.0d) {
                    round = 0.0d;
                }
                strArr[8] = String.format("%d%s", Integer.valueOf((int) round), str);
                double round2 = Math.round((parseInt8 * (d18 / 0.79d)) - d4);
                if (round2 < 0.0d) {
                    round2 = 0.0d;
                }
                strArr[9] = String.format("%d%s", Integer.valueOf((int) round2), str);
                double round3 = Math.round(((((((d18 * 1.2498d) * d19) + ((parseInt6 * 1.4276d) * d19)) + ((parseInt7 * 0.1785d) * d19)) / 1.2924d) - 1.0d) * d4);
                if (round3 < 0.0d) {
                    round3 = 0.0d;
                }
                strArr[10] = String.format("%d%s", Integer.valueOf((int) round3), str);
                strArr[7] = String.format("%d%s", Integer.valueOf((int) Math.round(((((Integer.parseInt(strArr[12]) * 0.05d) + 1.0d) / ((Integer.parseInt(strArr[3]) + 1) * 0.01d)) * d4) - d4)), str);
                return strArr;
            }
            if (parseInt == 725) {
                int parseInt9 = Integer.parseInt(strArr[1]);
                Integer.parseInt(strArr[8]);
                double d20 = parseInt9 == 1 ? 14.7d : 1.0d;
                double parseDouble5 = Double.parseDouble(strArr[5].replace(',', '.')) * 0.01d;
                double parseDouble6 = Double.parseDouble(strArr[4].replace(',', '.')) * 0.01d;
                double parseDouble7 = Double.parseDouble(strArr[2].replace(',', '.'));
                double parseDouble8 = Double.parseDouble(strArr[3].replace(',', '.'));
                if (parseDouble8 >= parseDouble7 && parseDouble5 + parseDouble6 <= 1.0d) {
                    double d21 = d20 + parseDouble7;
                    double d22 = parseDouble8 - parseDouble7;
                    double d23 = d20 + parseDouble8;
                    double parseDouble9 = ((parseDouble6 * d21) + ((Double.parseDouble(strArr[6].replace(',', '.')) * 0.01d) * d22)) / d23;
                    double parseDouble10 = ((d21 * parseDouble5) + ((Double.parseDouble(strArr[9].replace(',', '.')) * 0.01d) * d22)) / d23;
                    if (parseDouble10 >= 0.01d) {
                        strArr[7] = String.format("%.1f / %.1f", Double.valueOf(parseDouble9 * 100.0d), Double.valueOf(parseDouble10 * 100.0d));
                        return strArr;
                    }
                    strArr[7] = String.format("%.1f", Double.valueOf(parseDouble9 * 100.0d));
                    return strArr;
                }
            } else {
                if (parseInt == 752) {
                    int parseInt10 = Integer.parseInt(strArr[1]);
                    int parseInt11 = Integer.parseInt(strArr[12]);
                    double d24 = parseInt10 == 1 ? 14.7d : 1.0d;
                    double parseDouble11 = Double.parseDouble(strArr[6].replace(',', '.')) * 0.01d;
                    double parseDouble12 = Double.parseDouble(strArr[7].replace(',', '.')) * 0.01d;
                    double parseDouble13 = Double.parseDouble(strArr[3].replace(',', '.')) + d24;
                    double d25 = parseDouble13 * parseDouble11;
                    double d26 = parseDouble13 * parseDouble12;
                    double d27 = (parseDouble13 - d25) - d26;
                    double parseDouble14 = Double.parseDouble(strArr[4].replace(',', '.')) * 0.01d;
                    double parseDouble15 = Double.parseDouble(strArr[5].replace(',', '.')) * 0.01d;
                    double d28 = (1.0d - parseDouble14) - parseDouble15;
                    double parseDouble16 = Double.parseDouble(strArr[2].replace(',', '.')) + d24;
                    double d29 = parseDouble15 * parseDouble16;
                    double d30 = parseDouble14 * parseDouble16;
                    double d31 = d28 * parseDouble16;
                    double d32 = d26 - d29;
                    double d33 = 1.0d - (parseDouble11 + parseDouble12);
                    double d34 = parseDouble16 + d32;
                    double gasZ3 = (((gasZ(3, d34, parseInt10, parseInt11) - gasZ(0, d34, parseInt10, parseInt11)) * d33) + 1.0d) * d32;
                    if (this.banked32.booleanValue()) {
                        d5 = ((d27 - d31) - (gasZ3 - d32)) / 0.68d;
                        d6 = d25 - d30;
                        d7 = 0.32d;
                    } else {
                        d5 = ((d27 - d31) - (gasZ3 - d32)) / 0.79d;
                        d6 = d25 - d30;
                        d7 = 0.21d;
                    }
                    double d35 = d6 - (d5 * d7);
                    double d36 = parseDouble16 + gasZ3;
                    double d37 = d36 + d35;
                    double gasZ4 = d35 * (1.0d - (d33 * (gasZ(0, d37, parseInt10, parseInt11) - gasZ(1, d37, parseInt10, parseInt11))));
                    if (Boolean.parseBoolean(strArr[13])) {
                        if (parseInt10 == 0) {
                            strArr[9] = String.format("%.1f%s%.1f%s", Double.valueOf(gasZ3), "  (", Double.valueOf(d36 - d24), ")");
                        } else {
                            strArr[9] = String.format("%.0f%s%.0f%s", Double.valueOf(gasZ3), "  (", Double.valueOf(d36 - d24), ")");
                        }
                        d8 = d36 + gasZ4;
                        if (parseInt10 == 0) {
                            strArr[8] = String.format("%.1f%s%.1f%s", Double.valueOf(gasZ4), "  (", Double.valueOf(d8 - d24), ")");
                        } else {
                            strArr[8] = String.format("%.0f%s%.0f%s", Double.valueOf(gasZ4), "  (", Double.valueOf(d8 - d24), ")");
                        }
                    } else {
                        double d38 = parseDouble16 + gasZ4;
                        if (parseInt10 == 0) {
                            strArr[9] = String.format("%.1f%s%.1f%s", Double.valueOf(gasZ4), "  (", Double.valueOf(d38 - d24), ")");
                        } else {
                            strArr[9] = String.format("%.0f%s%.0f%s", Double.valueOf(gasZ4), "  (", Double.valueOf(d38 - d24), ")");
                        }
                        d8 = d38 + gasZ3;
                        if (parseInt10 == 0) {
                            strArr[8] = String.format("%.1f%s%.1f%s", Double.valueOf(gasZ3), "  (", Double.valueOf(d8 - d24), ")");
                        } else {
                            strArr[8] = String.format("%.0f%s%.0f%s", Double.valueOf(gasZ3), "  (", Double.valueOf(d8 - d24), ")");
                        }
                    }
                    double d39 = d8;
                    double gasZ5 = (gasZ4 / gasZ(1, d39, parseInt10, parseInt11)) + d30;
                    strArr[11] = String.format("%.1f", Double.valueOf((gasZ5 / (((gasZ5 + d29) + (gasZ3 / gasZ(3, d39, parseInt10, parseInt11))) + d31)) * 100.0d));
                    if (parseInt10 == 0) {
                        strArr[10] = String.format("%.1f%s%.1f%s", Double.valueOf(parseDouble13 - d39), "  (", Double.valueOf(parseDouble13 - d24), ")");
                        return strArr;
                    }
                    strArr[10] = String.format("%.0f%s%.0f%s", Double.valueOf(parseDouble13 - d39), "  (", Double.valueOf(parseDouble13 - d24), ")");
                    return strArr;
                }
                if (parseInt == 787) {
                    double parseDouble17 = Double.parseDouble(strArr[2].replace(',', '.'));
                    if (Boolean.parseBoolean(strArr[1])) {
                        d9 = Boolean.parseBoolean(strArr[8]) ? 10.337d : 10.078d;
                    } else {
                        d9 = Boolean.parseBoolean(strArr[8]) ? 33.914d : 33.066d;
                    }
                    double d40 = (parseDouble17 / d9) + 1.0d;
                    double parseDouble18 = Double.parseDouble(strArr[3].replace(',', '.')) * 0.01d;
                    double parseDouble19 = Double.parseDouble(strArr[4].replace(',', '.')) * 0.01d;
                    double d41 = (1.0d - parseDouble18) - parseDouble19;
                    if (Boolean.parseBoolean(strArr[7])) {
                        double min3 = Math.min(1.0d, Double.parseDouble(strArr[5].replace(',', '.')) / d40);
                        d41 -= ((min3 - parseDouble18) * d41) / (parseDouble19 + d41);
                        parseDouble19 = (1.0d - min3) - d41;
                        parseDouble18 = min3;
                    }
                    if (Boolean.parseBoolean(strArr[6])) {
                        d10 = ((d41 * 1.165d) + (parseDouble18 * 1.331d) + (parseDouble19 * 0.1664d)) * d40;
                        d11 = 1.205d;
                    } else {
                        d10 = ((d41 * 1.2506d) + (parseDouble18 * 1.429d) + (parseDouble19 * 0.1785d)) * d40;
                        d11 = 1.293d;
                    }
                    strArr[11] = String.format("%.2f", Double.valueOf(d10));
                    strArr[12] = String.format("%.2f", Double.valueOf(d10 / d11));
                    return strArr;
                }
                if (parseInt == 9999) {
                    int parseInt12 = Integer.parseInt(strArr[1]);
                    double parseDouble20 = (Double.parseDouble(strArr[1].replace(',', '.')) * Double.parseDouble(strArr[7].replace(',', '.'))) - (Double.parseDouble(strArr[3].replace(',', '.')) * Double.parseDouble(strArr[6].replace(',', '.')));
                    double parseDouble21 = Double.parseDouble(strArr[3].replace(',', '.')) + Double.parseDouble(strArr[4].replace(',', '.'));
                    if (parseInt12 == 1) {
                        strArr[5] = String.format("%.1f", Double.valueOf(parseDouble21));
                    } else {
                        strArr[5] = String.format("%.0f", Double.valueOf(parseDouble21));
                    }
                    double parseDouble22 = parseDouble20 / Double.parseDouble(strArr[7].replace(',', '.'));
                    if (parseInt12 == 1) {
                        strArr[2] = String.format("%.1f", Double.valueOf(parseDouble22));
                    } else {
                        strArr[2] = String.format("%.0f", Double.valueOf(parseDouble22));
                    }
                    strArr[8] = Boolean.toString(parseDouble22 < parseDouble21);
                    return strArr;
                }
            }
        }
        return strArr;
    }
}
