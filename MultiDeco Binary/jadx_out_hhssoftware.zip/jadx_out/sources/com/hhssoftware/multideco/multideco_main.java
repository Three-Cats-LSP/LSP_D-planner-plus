package com.hhssoftware.multideco;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Looper;
import android.os.MessageQueue;
import android.util.DisplayMetrics;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import com.hhssoftware.multideco.Gastank_setting;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import javax.net.ssl.HttpsURLConnection;

/* loaded from: classes.dex */
public class multideco_main extends Activity implements View.OnClickListener, MessageQueue.IdleHandler {
    public static final int MAX_DECOS = 20;
    public static final int MAX_LEVELS = 50;
    private int calc_counter;
    private String calcdecos;
    private String calclevels;
    private String calcmaxtime;
    private String reg_code;
    private String reg_key;
    private Settings settings;
    private final String PREFS_LEVELS_OC = "levels_OC";
    private final String PREFS_LEVELS_CCR = "levels_CCR";
    private final String PREFS_DECOS = "decos";
    private final String PREFS_INSTALL = "install";
    private final int DLG_WAIT_CALC = 111111;
    private final int DLG_NAG_WAIT = 121234;
    private final int DLG_NEW_VERSION = 4543135;
    private final int DLG_NEW_LANG = 3434255;
    private final int MENU_TOOLS = 5433293;
    private final int MENU_WEB_FAQ = 446221;
    private final int MENU_THEME = 446222;
    private final long a_day = 86400;
    private final int TEXT_SIZE = 22;
    private Integer dive_N = 1;
    private Boolean registered = false;
    private long agreed = 0;
    private long installed = 0;
    private Boolean NarrowScreen = false;
    private Boolean landscape = false;
    private ProgressDialog progressDialogWait = null;
    private ProgressDialog progressDialogNag = null;
    private AsyncTask<?, ?, ?> asyncTaskNag = null;

    @Override // android.app.Activity
    public void onCreate(Bundle bundle) {
        setTheme(new Theme_setting(this).theme_id);
        super.onCreate(bundle);
        Settings settings = new Settings(this);
        this.settings = settings;
        settings.nextDive(true);
        setupViews();
        Identity identity = new Identity(this);
        this.reg_code = identity.getInstallcode();
        String keyString = identity.getKeyString();
        this.reg_key = keyString;
        if (keyString != null && keyString.length() > 0) {
            this.registered = identity.getRegState();
        }
        Looper.myQueue().addIdleHandler(this);
    }

    private void setupViews() {
        setContentView(C0347R.layout.multideco_main);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        this.NarrowScreen = Boolean.valueOf(displayMetrics.widthPixels <= 240);
        this.landscape = Boolean.valueOf(displayMetrics.widthPixels > displayMetrics.heightPixels);
        initForm();
        findViewById(C0347R.id.ButtonAddDeco).setOnClickListener(this);
        findViewById(C0347R.id.ButtonAddLevel).setOnClickListener(this);
        findViewById(C0347R.id.ButtonDeleteDeco).setOnClickListener(this);
        findViewById(C0347R.id.ButtonDeleteLevel).setOnClickListener(this);
        findViewById(C0347R.id.ButtonCalc).setOnClickListener(this);
        findViewById(C0347R.id.ButtonMaxtime).setOnClickListener(this);
        findViewById(C0347R.id.ButtonBailout).setOnClickListener(this);
        findViewById(C0347R.id.imageBtnConfig).setOnClickListener(this);
        findViewById(C0347R.id.imageBtnTools).setOnClickListener(this);
    }

    @Override // android.os.MessageQueue.IdleHandler
    public boolean queueIdle() {
        SharedPreferences sharedPreferences = getSharedPreferences("install", 0);
        this.agreed = sharedPreferences.getLong("agreed", 0L);
        boolean contains = sharedPreferences.contains("update_rates");
        if (this.agreed == 0) {
            startActivityForResult(new Intent(this, (Class<?>) multideco_agree.class), C0347R.id.multideco_agree_xml);
        } else if (!contains) {
            updatedProgramInfo();
        }
        if (!contains) {
            SharedPreferences.Editor edit = sharedPreferences.edit();
            edit.putBoolean("update_rates", true);
            edit.commit();
        }
        if (sharedPreferences.contains("installed")) {
            readinstalled();
        }
        if (this.agreed > 0) {
            new VersionTask().execute(this, this.registered);
        }
        if (this.installed == 0) {
            new InstalledTask().execute(this);
        }
        return false;
    }

    private void updatedProgramInfo() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(android.R.string.dialog_alert_title));
        builder.setIcon(android.R.drawable.ic_dialog_info);
        builder.setMessage(getString(C0347R.string.Config_rates_changed));
        builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() { // from class: com.hhssoftware.multideco.multideco_main.1
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        });
        builder.create().show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void readinstalled() {
        int indexOf;
        SharedPreferences sharedPreferences = getSharedPreferences("install", 0);
        Android_RSA android_RSA = new Android_RSA(getApplicationContext());
        try {
            String str = new String(android_RSA.rsaDecrypt(android_RSA.base64_decode(sharedPreferences.getString("installed", ""))));
            if (!str.startsWith(this.reg_code) || (indexOf = str.indexOf(61)) <= -1) {
                return;
            }
            this.installed = Integer.parseInt(str.substring(indexOf + 1));
        } catch (Exception unused) {
            this.installed = 0L;
        }
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration configuration) {
        if (this.progressDialogNag != null) {
            AsyncTask<?, ?, ?> asyncTask = this.asyncTaskNag;
            if (asyncTask != null) {
                asyncTask.cancel(true);
            }
            this.progressDialogNag.cancel();
            this.progressDialogNag = null;
        }
        super.onConfigurationChanged(configuration);
    }

    @Override // android.app.Activity
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, C0347R.id.multideco_config_xml, 0, C0347R.string.Settings).setIcon(android.R.drawable.ic_menu_preferences);
        MenuItem add = menu.add(0, 5433293, 0, C0347R.string.Tools);
        add.setIcon(android.R.drawable.ic_menu_help);
        add.setIcon(android.R.drawable.ic_menu_help);
        menu.add(0, C0347R.id.multideco_about_xml, 0, C0347R.string.About).setIcon(android.R.drawable.ic_menu_info_details);
        if (!this.registered.booleanValue()) {
            menu.add(0, C0347R.id.multideco_registration_xml, 0, C0347R.string.Registration).setIcon(android.R.drawable.ic_menu_info_details);
        }
        MenuItem add2 = menu.add(0, C0347R.id.multideco_maxtime_xml, 0, C0347R.string.MaxTime);
        add2.setIcon(android.R.drawable.ic_menu_close_clear_cancel);
        add2.setVisible(this.settings.OC_CCR == 0);
        MenuItem add3 = menu.add(0, C0347R.id.multideco_bail_xml, 0, C0347R.string.Bailout);
        add3.setIcon(android.R.drawable.ic_menu_close_clear_cancel);
        add3.setVisible(this.settings.OC_CCR == 1);
        menu.add(0, 446221, 0, C0347R.string.WebFAQ).setIcon(android.R.drawable.ic_menu_help);
        menu.add(0, 446222, 0, C0347R.string.Theme).setIcon(android.R.drawable.ic_menu_rotate);
        return true;
    }

    @Override // android.app.Activity
    public boolean onPrepareOptionsMenu(Menu menu) {
        menu.findItem(C0347R.id.multideco_bail_xml).setVisible(this.settings.OC_CCR == 1);
        menu.findItem(C0347R.id.multideco_maxtime_xml).setVisible(this.settings.OC_CCR == 0);
        return true;
    }

    @Override // android.app.Activity
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == C0347R.id.multideco_config_xml) {
            startActivityForResult(new Intent(this, (Class<?>) multideco_config.class), C0347R.id.multideco_config_xml);
            return true;
        }
        if (itemId == C0347R.id.multideco_about_xml) {
            startActivity(new Intent(this, (Class<?>) multideco_about.class));
            return true;
        }
        if (itemId == 5433293) {
            startActivity(new Intent(this, (Class<?>) multideco_toolslist.class));
            return true;
        }
        if (itemId == C0347R.id.multideco_registration_xml) {
            doRegistrationScreen();
            return true;
        }
        if (itemId == C0347R.id.multideco_bail_xml) {
            Intent intent = new Intent(this, (Class<?>) multideco_bail.class);
            if (setBailIntent(intent).booleanValue()) {
                startActivityForResult(intent, C0347R.id.multideco_bail_xml);
            } else {
                doCalcErrDlg(1);
            }
            return true;
        }
        if (itemId == C0347R.id.multideco_maxtime_xml) {
            Intent intent2 = new Intent(this, (Class<?>) multideco_maxtime.class);
            if (setMaxtimeIntent(intent2).booleanValue()) {
                startActivityForResult(intent2, C0347R.id.multideco_maxtime_xml);
            } else {
                doCalcErrDlg(1);
            }
            return true;
        }
        if (itemId == 446221) {
            Intent intent3 = new Intent();
            intent3.setAction("android.intent.action.VIEW");
            intent3.addCategory("android.intent.category.BROWSABLE");
            intent3.setData(Uri.parse(getString(C0347R.string.mobile_faq)));
            startActivity(intent3);
            return true;
        }
        if (itemId != 446222) {
            return false;
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(C0347R.string.SelectTheme));
        builder.setIcon(android.R.drawable.ic_dialog_info);
        CharSequence[] charSequenceArr = {getString(C0347R.string.Darktheme), getString(C0347R.string.Lighttheme)};
        final Theme_setting theme_setting = new Theme_setting(this);
        final int i = theme_setting.theme_id;
        builder.setItems(charSequenceArr, new DialogInterface.OnClickListener() { // from class: com.hhssoftware.multideco.multideco_main.2
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i2) {
                if (i2 == 0 && i == 16974120) {
                    return;
                }
                if (i2 == 1 && i == 16974123) {
                    return;
                }
                if (i2 == 0) {
                    theme_setting.set_theme(android.R.style.Theme.DeviceDefault);
                } else {
                    theme_setting.set_theme(android.R.style.Theme.DeviceDefault.Light);
                }
                multideco_main.this.finish();
            }
        });
        builder.create().show();
        return true;
    }

    private Boolean setBailIntent(Intent intent) {
        int i;
        String str;
        TableLayout tableLayout = (TableLayout) findViewById(C0347R.id.TableLevels);
        int i2 = 0;
        for (int childCount = tableLayout.getChildCount() - 1; childCount >= 0; childCount--) {
            if (((CheckBox) ((TableRow) tableLayout.getChildAt(childCount)).getChildAt(0)).isChecked()) {
                i2++;
            }
        }
        if (i2 == 0) {
            return false;
        }
        String[] strArr = new String[((TableLayout) findViewById(C0347R.id.TableDecos)).getChildCount() + 1];
        TableLayout tableLayout2 = (TableLayout) findViewById(C0347R.id.TableLevels);
        int childCount2 = tableLayout2.getChildCount() - 1;
        while (true) {
            if (childCount2 < 0) {
                childCount2 = 0;
                i = 0;
                str = "";
                break;
            }
            TableRow tableRow = (TableRow) tableLayout2.getChildAt(childCount2);
            if (((CheckBox) tableRow.getChildAt(0)).isChecked()) {
                String obj = ((TextView) tableRow.getChildAt(1)).getText().toString();
                String substring = obj.substring(obj.indexOf(", ") + 2);
                if (substring.charAt(0) != '-') {
                    String substring2 = substring.substring(substring.indexOf(", ") + 2);
                    str = substring2.substring(0, substring2.indexOf(", "));
                    strArr[0] = str;
                    i = 1;
                    break;
                }
            }
            childCount2--;
        }
        TableLayout tableLayout3 = (TableLayout) findViewById(C0347R.id.TableDecos);
        int i3 = 0;
        for (int i4 = 0; i4 < tableLayout3.getChildCount(); i4++) {
            TableRow tableRow2 = (TableRow) tableLayout3.getChildAt(i4);
            CheckBox checkBox = (CheckBox) tableRow2.getChildAt(0);
            CharSequence text = ((TextView) tableRow2.getChildAt(1)).getText();
            if (!str.contentEquals(text)) {
                strArr[i] = ((Object) text) + "";
                i++;
                if (checkBox.isChecked()) {
                    i3 |= 1 << (i4 + 1);
                }
            }
        }
        intent.putExtra("OCMixes", strArr);
        intent.putExtra("OCMixCheck", i3);
        intent.putExtra("BottomSegIndex", childCount2);
        return true;
    }

    private void initForm() {
        SharedPreferences sharedPreferences;
        ((TextView) findViewById(C0347R.id.TextViewConfig)).setText(ConfigStr());
        if (this.settings.OC_CCR == 1) {
            ((TextView) findViewById(C0347R.id.TextViewLevels)).setText(getString(C0347R.string.levelsCCRList));
        } else {
            ((TextView) findViewById(C0347R.id.TextViewLevels)).setText(getString(C0347R.string.levelsOCList));
        }
        ((TableLayout) findViewById(C0347R.id.TableDecos)).removeAllViews();
        ((TableLayout) findViewById(C0347R.id.TableLevels)).removeAllViews();
        ScrollView scrollView = (ScrollView) findViewById(C0347R.id.ScrollViewDecos);
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) scrollView.getLayoutParams();
        if (this.landscape.booleanValue()) {
            layoutParams.weight = 10.0f;
        } else if (this.settings.OC_CCR == 0) {
            layoutParams.weight = 9.0f;
        } else {
            layoutParams.weight = 11.0f;
        }
        scrollView.requestLayout();
        if (this.settings.OC_CCR == 0) {
            sharedPreferences = getSharedPreferences("levels_OC", 0);
        } else {
            sharedPreferences = getSharedPreferences("levels_CCR", 0);
        }
        if (sharedPreferences != null) {
            int i = sharedPreferences.getInt("level_checked", 0);
            TableLayout tableLayout = (TableLayout) findViewById(C0347R.id.TableLevels);
            for (int i2 = 0; i2 < 50; i2++) {
                String string = sharedPreferences.getString("level_" + i2, "");
                if (string.length() == 0) {
                    break;
                }
                TableRow tableRow = new TableRow(this);
                CheckBox checkBox = new CheckBox(this);
                checkBox.setChecked(((1 << i2) & i) > 0);
                tableRow.addView(checkBox);
                TextView textView = new TextView(this);
                textView.setText(string);
                textView.setTextSize(2, 22.0f);
                tableRow.addView(textView);
                tableLayout.addView(tableRow);
                padRowMargins(tableRow, checkBox, textView);
            }
            SharedPreferences sharedPreferences2 = getSharedPreferences("decos", 0);
            if (sharedPreferences2 != null) {
                int i3 = sharedPreferences2.getInt("deco_checked", 0);
                TableLayout tableLayout2 = (TableLayout) findViewById(C0347R.id.TableDecos);
                for (int i4 = 0; i4 < 20; i4++) {
                    String string2 = sharedPreferences2.getString("deco_" + i4, "");
                    if (string2.length() == 0) {
                        break;
                    }
                    TableRow tableRow2 = new TableRow(this);
                    CheckBox checkBox2 = new CheckBox(this);
                    checkBox2.setChecked(((1 << i4) & i3) > 0);
                    tableRow2.addView(checkBox2);
                    TextView textView2 = new TextView(this);
                    textView2.setText(string2);
                    textView2.setTextSize(2, 22.0f);
                    tableRow2.addView(textView2);
                    tableLayout2.addView(tableRow2);
                    padRowMargins(tableRow2, checkBox2, textView2);
                }
            }
            findViewById(C0347R.id.ButtonMaxtime).setVisibility(this.settings.OC_CCR != 0 ? 8 : 0);
            findViewById(C0347R.id.ButtonBailout).setVisibility(this.settings.OC_CCR != 1 ? 8 : 0);
        }
    }

    private void padRowMargins(TableRow tableRow, CheckBox checkBox, TextView textView) {
        TableRow.LayoutParams layoutParams = new TableRow.LayoutParams();
        layoutParams.topMargin = 15;
        layoutParams.leftMargin = 10;
        tableRow.setLayoutParams(layoutParams);
    }

    @Override // android.app.Activity
    protected void onStop() {
        SharedPreferences sharedPreferences;
        super.onStop();
        if (this.settings.OC_CCR == 0) {
            sharedPreferences = getSharedPreferences("levels_OC", 0);
        } else {
            sharedPreferences = getSharedPreferences("levels_CCR", 0);
        }
        SharedPreferences.Editor edit = sharedPreferences.edit();
        TableLayout tableLayout = (TableLayout) findViewById(C0347R.id.TableLevels);
        if (edit != null) {
            edit.clear();
            int i = 0;
            for (int i2 = 0; i2 < tableLayout.getChildCount(); i2++) {
                TableRow tableRow = (TableRow) tableLayout.getChildAt(i2);
                TextView textView = (TextView) tableRow.getChildAt(1);
                if (textView != null) {
                    edit.putString("level_" + i2, textView.getText().toString());
                }
                if (((CheckBox) tableRow.getChildAt(0)).isChecked()) {
                    i |= 1 << i2;
                }
            }
            edit.putInt("level_checked", i);
            edit.commit();
        }
        SharedPreferences.Editor edit2 = getSharedPreferences("decos", 0).edit();
        TableLayout tableLayout2 = (TableLayout) findViewById(C0347R.id.TableDecos);
        if (edit2 != null) {
            edit2.clear();
            int i3 = 0;
            for (int i4 = 0; i4 < tableLayout2.getChildCount(); i4++) {
                TableRow tableRow2 = (TableRow) tableLayout2.getChildAt(i4);
                TextView textView2 = (TextView) tableRow2.getChildAt(1);
                if (textView2 != null) {
                    edit2.putString("deco_" + i4, textView2.getText().toString());
                }
                if (((CheckBox) tableRow2.getChildAt(0)).isChecked()) {
                    i3 |= 1 << i4;
                }
            }
            edit2.putInt("deco_checked", i3);
            edit2.commit();
        }
    }

    void startLevelDecoActivity(int i, int i2) {
        if (i == C0347R.id.ButtonAddDeco) {
            Intent intent = new Intent(this, (Class<?>) multideco_deco.class);
            intent.putExtra("Metric", this.settings.Metric);
            if (i2 > -1) {
                intent.putExtra("Edit", ((TextView) ((TableRow) ((TableLayout) findViewById(C0347R.id.TableDecos)).getChildAt(i2)).getChildAt(1)).getText().toString());
                intent.putExtra("Row", i2);
            }
            startActivityForResult(intent, C0347R.id.multideco_deco_xml);
            return;
        }
        if (i == C0347R.id.ButtonAddLevel) {
            Intent intent2 = new Intent(this, (Class<?>) multideco_level.class);
            intent2.putExtra("Metric", this.settings.Metric);
            intent2.putExtra("Circuit", this.settings.OC_CCR);
            if (i2 > -1) {
                intent2.putExtra("Edit", ((TextView) ((TableRow) ((TableLayout) findViewById(C0347R.id.TableLevels)).getChildAt(i2)).getChildAt(1)).getText().toString());
                intent2.putExtra("Row", i2);
            }
            startActivityForResult(intent2, C0347R.id.multideco_level_xml);
        }
    }

    private Boolean setMaxtimeIntent(Intent intent) {
        ArrayList arrayList = new ArrayList();
        TableLayout tableLayout = (TableLayout) findViewById(C0347R.id.TableLevels);
        TableLayout tableLayout2 = (TableLayout) findViewById(C0347R.id.TableDecos);
        for (int childCount = tableLayout.getChildCount() - 1; childCount >= 0; childCount--) {
            TableRow tableRow = (TableRow) tableLayout.getChildAt(childCount);
            if (((CheckBox) tableRow.getChildAt(0)).isChecked()) {
                String LegStrSeg = Settings.LegStrSeg(((TextView) tableRow.getChildAt(1)).getText().toString(), 3);
                arrayList.remove(LegStrSeg);
                arrayList.add(LegStrSeg);
            }
        }
        if (arrayList.size() == 0) {
            return false;
        }
        for (int childCount2 = tableLayout2.getChildCount() - 1; childCount2 >= 0; childCount2--) {
            TableRow tableRow2 = (TableRow) tableLayout2.getChildAt(childCount2);
            if (((CheckBox) tableRow2.getChildAt(0)).isChecked()) {
                String LegStrSeg2 = Settings.LegStrSeg(((TextView) tableRow2.getChildAt(1)).getText().toString(), 3);
                arrayList.remove(LegStrSeg2);
                arrayList.add(LegStrSeg2);
            }
        }
        intent.putExtra("OCMixes", (String[]) arrayList.toArray(new String[arrayList.size()]));
        return true;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        int id = view.getId();
        if (id == C0347R.id.ButtonAddDeco || id == C0347R.id.ButtonAddLevel) {
            startLevelDecoActivity(view.getId(), -1);
            return;
        }
        if (id == C0347R.id.ButtonDeleteDeco) {
            TableLayout tableLayout = (TableLayout) findViewById(C0347R.id.TableDecos);
            int childCount = tableLayout.getChildCount() - 1;
            if (childCount >= 0) {
                SelectDeleteEditTableRow(tableLayout, childCount);
                return;
            }
            return;
        }
        if (id == C0347R.id.ButtonDeleteLevel) {
            TableLayout tableLayout2 = (TableLayout) findViewById(C0347R.id.TableLevels);
            int childCount2 = tableLayout2.getChildCount() - 1;
            if (childCount2 >= 0) {
                SelectDeleteEditTableRow(tableLayout2, childCount2);
                return;
            }
            return;
        }
        if (id == C0347R.id.ButtonCalc) {
            this.settings.bailactive = false;
            this.calcmaxtime = "";
            doCalcClick();
            return;
        }
        if (id == C0347R.id.ButtonMaxtime) {
            Intent intent = new Intent(this, (Class<?>) multideco_maxtime.class);
            if (setMaxtimeIntent(intent).booleanValue()) {
                startActivityForResult(intent, C0347R.id.multideco_maxtime_xml);
                return;
            } else {
                doCalcErrDlg(1);
                return;
            }
        }
        if (id == C0347R.id.ButtonBailout) {
            Intent intent2 = new Intent(this, (Class<?>) multideco_bail.class);
            if (setBailIntent(intent2).booleanValue()) {
                startActivityForResult(intent2, C0347R.id.multideco_bail_xml);
                return;
            } else {
                doCalcErrDlg(1);
                return;
            }
        }
        if (id == C0347R.id.imageBtnConfig) {
            startActivityForResult(new Intent(this, (Class<?>) multideco_config.class), C0347R.id.multideco_config_xml);
        } else if (id == C0347R.id.imageBtnTools) {
            startActivity(new Intent(this, (Class<?>) multideco_toolslist.class));
        }
    }

    private void doRegistrationScreen() {
        Intent intent = new Intent(this, (Class<?>) multideco_registration.class);
        String str = this.reg_code;
        if (str != null && str.length() == 23) {
            intent.putExtra("ic", this.reg_code);
        }
        startActivityForResult(intent, C0347R.id.multideco_registration_xml);
    }

    /* JADX WARN: Removed duplicated region for block: B:77:0x01be  */
    /* JADX WARN: Removed duplicated region for block: B:80:0x01f1  */
    /* JADX WARN: Removed duplicated region for block: B:82:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:83:0x01d2  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private void doCalcClick() {
        int i;
        Boolean bool = false;
        if (!this.settings.bailactive) {
            this.calclevels = "";
            TableLayout tableLayout = (TableLayout) findViewById(C0347R.id.TableLevels);
            for (int i2 = 0; i2 < tableLayout.getChildCount(); i2++) {
                TableRow tableRow = (TableRow) tableLayout.getChildAt(i2);
                if (((CheckBox) tableRow.getChildAt(0)).isChecked()) {
                    String obj = ((TextView) tableRow.getChildAt(1)).getText().toString();
                    if (this.settings.OC_CCR == 1) {
                        obj = Settings.LegStrFltFmt(obj);
                    }
                    this.calclevels += obj + "#";
                }
            }
        }
        if (!this.settings.bailactive) {
            this.calcdecos = "";
            TableLayout tableLayout2 = (TableLayout) findViewById(C0347R.id.TableDecos);
            for (int i3 = 0; i3 < tableLayout2.getChildCount(); i3++) {
                TableRow tableRow2 = (TableRow) tableLayout2.getChildAt(i3);
                if (((CheckBox) tableRow2.getChildAt(0)).isChecked()) {
                    this.calcdecos += ((Object) ((TextView) tableRow2.getChildAt(1)).getText()) + "#";
                }
            }
        }
        for (String str = this.calcdecos; str.indexOf(35) > 0; str = str.substring(str.indexOf(35) + 1)) {
            bool = Boolean.valueOf(bool.booleanValue() | (str.startsWith("100") || (str.length() >= 2 && str.charAt(0) >= '6') || (str.length() >= 2 && str.charAt(0) == '5' && str.charAt(1) > '5')));
        }
        int i4 = this.calclevels.length() == 0 ? 1 : 0;
        if (i4 != 0) {
            doCalcErrDlg(i4);
            return;
        }
        if (!this.registered.booleanValue() && (bool.booleanValue() || this.calclevels.indexOf("/") > 0 || this.calcdecos.indexOf("/") > 0)) {
            doRegistrationScreen();
            return;
        }
        if (!this.registered.booleanValue()) {
            long time = new Date().getTime() / 1000;
            if (time <= 1439251200 || time >= 1439942400) {
                long j = this.installed;
                if (j - 86400 > time) {
                    i = 1800;
                } else if (time - 25920000 > j) {
                    i = 600;
                } else if (time - 21600000 > j) {
                    i = 300;
                } else if (time - 12960000 > j) {
                    i = 120;
                } else if (time - 10368000 > j) {
                    i = 60;
                } else if (time - 7776000 > j) {
                    i = 30;
                } else if (time - 5184000 > j) {
                    i = 10;
                } else if (time - 2592000 > j) {
                    i = 5;
                }
                if (i <= 0) {
                    this.asyncTaskNag = new NagTask().execute(Integer.valueOf(i));
                } else {
                    new CalcTask().execute(this.calclevels, this.calcdecos, this.calcmaxtime);
                }
                if (this.installed != 0) {
                    new InstalledTask().execute(this);
                    return;
                }
                return;
            }
        }
        i = 0;
        if (i <= 0) {
        }
        if (this.installed != 0) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void doCalcErrDlg(int i) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(C0347R.string.Error));
        builder.setIcon(android.R.drawable.ic_dialog_alert);
        builder.setMessage(this.settings.err_str(i));
        builder.setNegativeButton(android.R.string.ok, new DialogInterface.OnClickListener() { // from class: com.hhssoftware.multideco.multideco_main.3
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i2) {
            }
        });
        builder.create().show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void launchResultActvity() {
        Intent intent = new Intent(this, (Class<?>) multideco_result.class);
        int resultRows = this.settings.getResultRows();
        int[] iArr = new int[resultRows];
        int[] iArr2 = new int[resultRows];
        boolean z = false;
        for (int i = 0; i < resultRows; i++) {
            intent.putExtra("result_row_" + i, this.settings.resultRow(i));
            int warning = this.settings.getWarning(i);
            if (warning != 0) {
                int i2 = -1;
                int i3 = warning;
                while (i3 > 0) {
                    i3 >>= 1;
                    i2++;
                }
                iArr[i] = this.settings.warn_colors[i2];
                iArr2[i] = warning;
                z = true;
            }
        }
        if (z) {
            intent.putExtra("alert_rows_color", iArr);
            intent.putExtra("alert_rows_warn", iArr2);
        }
        intent.putExtra("result_rows", resultRows);
        intent.putExtra("dive_report", this.settings.diveReport());
        startActivityForResult(intent, C0347R.id.multideco_result_xml);
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        this.settings.cleanup();
        super.onDestroy();
    }

    @Override // android.app.Activity
    protected void onPause() {
        if (this.progressDialogNag != null) {
            AsyncTask<?, ?, ?> asyncTask = this.asyncTaskNag;
            if (asyncTask != null) {
                asyncTask.cancel(true);
            }
            this.progressDialogNag.cancel();
            this.progressDialogNag = null;
        }
        super.onPause();
    }

    private void SelectDeleteEditTableRow(final TableLayout tableLayout, int i) {
        int childCount = tableLayout.getChildCount();
        if (childCount == 1) {
            ConfirmDeleteEditTableRow(tableLayout, i);
            return;
        }
        CharSequence[] charSequenceArr = new CharSequence[tableLayout.getChildCount() + 1];
        for (int i2 = 0; i2 < childCount; i2++) {
            charSequenceArr[i2] = ((TextView) ((TableRow) tableLayout.getChildAt(i2)).getChildAt(1)).getText();
        }
        charSequenceArr[childCount] = getString(android.R.string.cancel);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setIcon(android.R.drawable.ic_dialog_info);
        builder.setTitle(C0347R.string.SelectItem);
        builder.setItems(charSequenceArr, new DialogInterface.OnClickListener() { // from class: com.hhssoftware.multideco.multideco_main.4
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i3) {
                dialogInterface.cancel();
                if (i3 < tableLayout.getChildCount()) {
                    multideco_main.this.ConfirmDeleteEditTableRow(tableLayout, i3);
                }
            }
        });
        builder.create().show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void ConfirmDeleteEditTableRow(final TableLayout tableLayout, final int i) {
        String str = getString(C0347R.string.DeleteEdit) + "\n\n\t" + ((TextView) ((TableRow) tableLayout.getChildAt(i)).getChildAt(1)).getText().toString();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(C0347R.string.Confirm));
        builder.setIcon(android.R.drawable.ic_dialog_info);
        builder.setMessage(str);
        builder.setPositiveButton(C0347R.string.Delete, new DialogInterface.OnClickListener() { // from class: com.hhssoftware.multideco.multideco_main.5
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i2) {
                tableLayout.removeViewAt(i);
                dialogInterface.cancel();
            }
        });
        builder.setNeutralButton(C0347R.string.Edit, new DialogInterface.OnClickListener() { // from class: com.hhssoftware.multideco.multideco_main.6
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i2) {
                dialogInterface.cancel();
                int i3 = C0347R.id.ButtonAddDeco;
                if (tableLayout.getId() == C0347R.id.TableLevels) {
                    i3 = C0347R.id.ButtonAddLevel;
                }
                multideco_main.this.startLevelDecoActivity(i3, i);
            }
        });
        builder.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() { // from class: com.hhssoftware.multideco.multideco_main.7
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i2) {
                dialogInterface.cancel();
            }
        });
        builder.create().show();
    }

    @Override // android.app.Activity
    protected void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == C0347R.id.multideco_level_xml) {
            if (-1 == i2) {
                TableLayout tableLayout = (TableLayout) findViewById(C0347R.id.TableLevels);
                Bundle extras = intent.getExtras();
                String string = extras.getString("level");
                if (string == null || string.length() == 0) {
                    return;
                }
                int i3 = extras.get("row") != null ? extras.getInt("row") : -1;
                if (i3 > -1) {
                    ((TextView) ((TableRow) tableLayout.getChildAt(i3)).getChildAt(1)).setText(string);
                    return;
                }
                TableRow tableRow = new TableRow(this);
                CheckBox checkBox = new CheckBox(this);
                checkBox.setChecked(true);
                tableRow.addView(checkBox);
                TextView textView = new TextView(this);
                textView.setText(string);
                if (this.NarrowScreen.booleanValue() && this.settings.OC_CCR == 1) {
                    textView.setTextSize(2, 18.0f);
                } else {
                    textView.setTextSize(2, 22.0f);
                }
                tableRow.addView(textView);
                tableLayout.addView(tableRow);
                padRowMargins(tableRow, checkBox, textView);
                return;
            }
            return;
        }
        if (i == C0347R.id.multideco_deco_xml) {
            if (-1 == i2) {
                TableLayout tableLayout2 = (TableLayout) findViewById(C0347R.id.TableDecos);
                Bundle extras2 = intent.getExtras();
                String string2 = extras2.getString("deco");
                if (string2 == null || string2.length() == 0) {
                    return;
                }
                int i4 = extras2.get("row") != null ? extras2.getInt("row") : -1;
                if (i4 > -1) {
                    ((TextView) ((TableRow) tableLayout2.getChildAt(i4)).getChildAt(1)).setText(string2);
                    return;
                }
                TableRow tableRow2 = new TableRow(this);
                CheckBox checkBox2 = new CheckBox(this);
                checkBox2.setChecked(true);
                tableRow2.addView(checkBox2);
                TextView textView2 = new TextView(this);
                textView2.setText(string2);
                if (this.NarrowScreen.booleanValue() && this.settings.OC_CCR == 1) {
                    textView2.setTextSize(2, 18.0f);
                } else {
                    textView2.setTextSize(2, 22.0f);
                }
                tableRow2.addView(textView2);
                tableLayout2.addView(tableRow2);
                padRowMargins(tableRow2, checkBox2, textView2);
                return;
            }
            return;
        }
        if (i == C0347R.id.multideco_config_xml) {
            this.settings.reloadConfig();
            initForm();
            return;
        }
        if (i == C0347R.id.multideco_result_xml) {
            if (-1 == i2) {
                this.dive_N = Integer.valueOf(this.settings.nextDive(false));
                this.settings.surfInt = intent.getIntExtra("SI_Day", 0) * 1440;
                this.settings.surfInt += intent.getIntExtra("SI_Hour", 0) * 60;
                this.settings.surfInt += intent.getIntExtra("SI_Min", -1);
                ((TextView) findViewById(C0347R.id.TextViewConfig)).setText(ConfigStr());
            }
            int i5 = this.calc_counter + 1;
            this.calc_counter = i5;
            if (i5 % 4 == 0) {
                doLanguageCheck();
                return;
            }
            return;
        }
        if (i == C0347R.id.multideco_registration_xml) {
            if (-1 == i2) {
                finish();
                return;
            }
            return;
        }
        if (i == C0347R.id.multideco_bail_xml) {
            this.settings.reloadConfig();
            if (-1 == i2) {
                this.settings.bailactive = true;
                buildBailLegs(intent);
                doCalcClick();
                return;
            }
            return;
        }
        if (i == C0347R.id.multideco_maxtime_xml) {
            if (-1 == i2) {
                buildMaxTimedata(intent);
                doCalcClick();
                return;
            }
            return;
        }
        if (i == C0347R.id.multideco_agree_xml) {
            if (-1 == i2) {
                SharedPreferences.Editor edit = getSharedPreferences("install", 0).edit();
                long time = new Date().getTime();
                this.agreed = time;
                edit.putLong("agreed", time);
                edit.commit();
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle(getString(android.R.string.dialog_alert_title));
                builder.setIcon(android.R.drawable.ic_dialog_info);
                builder.setMessage(getString(C0347R.string.Config_menu_button));
                builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() { // from class: com.hhssoftware.multideco.multideco_main.8
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialogInterface, int i6) {
                    }
                });
                builder.create().show();
                return;
            }
            finish();
        }
    }

    private void doLanguageCheck() {
        String localeCode = getLocaleCode();
        String string = getString(C0347R.string.base_lang);
        if (localeCode.length() != 2 || localeCode.compareToIgnoreCase(string) == 0) {
            return;
        }
        showDialog(3434255);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public String getLocaleCode() {
        return Locale.getDefault().getLanguage();
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void buildBailLegs(Intent intent) {
        Boolean bool = false;
        this.calclevels = "";
        this.calcdecos = "";
        this.calcmaxtime = "";
        if (intent.hasExtra("OCMixes") && intent.hasExtra("MixSelect")) {
            int length = intent.getStringArrayExtra("OCMixes").length;
            int i = 1;
            int intExtra = intent.getIntExtra("MixSelect", 1);
            int intExtra2 = intent.getIntExtra("BottomSegIndex", 0);
            int i2 = 100;
            int i3 = 0;
            for (int i4 = 1; i4 < length; i4++) {
                if (((1 << i4) & intExtra) != 0) {
                    String str = intent.getStringArrayExtra("OCMixes")[i4];
                    if (str.indexOf(32) > 0) {
                        str = str.substring(0, str.indexOf(32));
                    }
                    if (str.indexOf(47) > 0) {
                        str = str.substring(0, str.indexOf(47));
                    }
                    int parseInt = Integer.parseInt(str);
                    if (parseInt < i2) {
                        bool = Boolean.valueOf(str.indexOf(32) > 0);
                        i3 = i4;
                        i2 = parseInt;
                    }
                }
            }
            String str2 = intent.getStringArrayExtra("OCMixes")[i3];
            if (str2.indexOf(32) > 0) {
                str2.substring(0, str2.indexOf(32));
            }
            TableLayout tableLayout = (TableLayout) findViewById(C0347R.id.TableLevels);
            String LegStrFltFmt = Settings.LegStrFltFmt(((TextView) ((TableRow) tableLayout.getChildAt(intExtra2)).getChildAt(1)).getText().toString());
            String[] strArr = {Settings.LegStrSeg(LegStrFltFmt, 1), Settings.LegStrSeg(LegStrFltFmt, 2), Settings.LegStrSeg(LegStrFltFmt, 3), Settings.LegStrSeg(LegStrFltFmt, 8)};
            int i5 = 0;
            if (intent.hasExtra("MixTankSelected")) {
                ArrayList<String> stringArrayListExtra = intent.getStringArrayListExtra("MixTankSelected");
                Gastank_setting gastank_setting = new Gastank_setting(this, 2);
                int i6 = 0;
                while (i6 < stringArrayListExtra.size()) {
                    int i7 = i;
                    String[] split = stringArrayListExtra.get(i6).split(":");
                    Boolean bool2 = bool;
                    Gastank_setting.TankPress tankPress = gastank_setting.getpress(Integer.parseInt(split[i7]));
                    int i8 = intExtra;
                    ArrayList<String> arrayList = stringArrayListExtra;
                    double calculateMixAvailable = Gastank_setting.calculateMixAvailable(gastank_setting.gettank(tankPress.TankIdx), tankPress, this.settings.RMVs == i7 ? 1 : i5);
                    String str3 = intent.getStringArrayExtra("OCMixes")[Integer.parseInt(split[i5])];
                    if (str3.indexOf(32) > 0) {
                        str3 = str3.substring(i5, str3.indexOf(32));
                    }
                    String str4 = str3 + ":";
                    if (this.calcmaxtime.indexOf(str4) <= 0) {
                        this.calcmaxtime += (str4 + String.valueOf(calculateMixAvailable) + "#");
                    }
                    i6++;
                    intExtra = i8;
                    bool = bool2;
                    stringArrayListExtra = arrayList;
                    i = 1;
                    i5 = 0;
                }
            }
            Boolean bool3 = bool;
            int i9 = intExtra;
            for (int i10 = 0; i10 < tableLayout.getChildCount(); i10++) {
                TableRow tableRow = (TableRow) tableLayout.getChildAt(i10);
                if (((CheckBox) tableRow.getChildAt(0)).isChecked()) {
                    String obj = ((TextView) tableRow.getChildAt(1)).getText().toString();
                    if (Settings.LegFloatSeg(obj, 2) != 0.0d) {
                        String str5 = intent.getStringArrayExtra("OCMixes")[i3];
                        if (str5.indexOf(32) > 0) {
                            str5 = str5.substring(0, str5.indexOf(32));
                        }
                        if (i10 == intExtra2 && this.settings.bailCaveBail) {
                            float parseInt2 = Integer.parseInt(strArr[1]) * this.settings.bailCavePortion * 0.1f;
                            this.calclevels += (strArr[0] + ", " + String.valueOf(Math.round(Integer.parseInt(strArr[1]) - parseInt2)) + ", " + strArr[2] + ", " + strArr[3]) + "#";
                            this.calclevels += (((i9 & 1) == 1 || bool3.booleanValue()) ? strArr[0] + ", " + String.valueOf(Math.round(parseInt2)) + ", " + strArr[2] + ", OC" : strArr[0] + ", " + String.valueOf(Math.round(parseInt2)) + ", " + str5 + ", OC") + "#";
                        } else {
                            if (i10 == intExtra2 && this.settings.bailExtraMin) {
                                this.calclevels += obj + "#";
                                this.calclevels += strArr[0] + ", " + this.settings.bailExtraMinTime + ", ";
                                if ((i9 & 1) == 1 || bool3.booleanValue()) {
                                    this.calclevels += strArr[2];
                                } else {
                                    this.calclevels += str5;
                                }
                                this.calclevels += ", OCla1#";
                            } else {
                                this.calclevels += obj + "#";
                            }
                        }
                    }
                }
            }
            for (int i11 = 0; i11 < length; i11++) {
                if ((i9 & (1 << i11)) != 0) {
                    String str6 = intent.getStringArrayExtra("OCMixes")[i11];
                    if (i11 == i3 && !bool3.booleanValue() && (i9 & 1) == 0) {
                        str6 = str6 + " " + strArr[0];
                    }
                    this.calcdecos += str6 + "#";
                }
            }
        }
    }

    private void buildMaxTimedata(Intent intent) {
        this.calcmaxtime = "";
        if (intent.hasExtra("MixTankSelected")) {
            ArrayList<String> stringArrayListExtra = intent.getStringArrayListExtra("MixTankSelected");
            Gastank_setting gastank_setting = new Gastank_setting(this, 1);
            for (int i = 0; i < stringArrayListExtra.size(); i++) {
                String[] split = stringArrayListExtra.get(i).split(":");
                Gastank_setting.TankPress tankPress = gastank_setting.getpress(Integer.parseInt(split[1]));
                double calculateMixAvailable = Gastank_setting.calculateMixAvailable(gastank_setting.gettank(tankPress.TankIdx), tankPress, this.settings.RMVs == 1);
                String str = intent.getStringArrayExtra("OCMixes")[Integer.parseInt(split[0])];
                if (str.indexOf(32) > 0) {
                    str = str.substring(0, str.indexOf(32));
                }
                String str2 = str + ":";
                if (this.calcmaxtime.indexOf(str2) <= 0) {
                    this.calcmaxtime += (str2 + String.valueOf(calculateMixAvailable) + "#");
                }
            }
        }
    }

    private String ConfigStr() {
        String[] strArr = {"OC", "CCR"};
        switch (this.settings.VPMModel) {
            case 1:
            case 2:
            case 3:
                String string = getString(C0347R.string.Dive);
                Integer num = this.dive_N;
                Settings settings = this.settings;
                return String.format("%s #%d    %s  +%d    %s", string, num, settings.modelString(settings.VPMModel), Integer.valueOf(this.settings.Margin), strArr[this.settings.OC_CCR]);
            case 4:
                String string2 = getString(C0347R.string.Dive);
                Integer num2 = this.dive_N;
                Settings settings2 = this.settings;
                return String.format("%s #%d    %s/%d    %s", string2, num2, settings2.modelString(settings2.VPMModel), Integer.valueOf(this.settings.GFS), strArr[this.settings.OC_CCR]);
            case 5:
            case 6:
                String string3 = getString(C0347R.string.Dive);
                Integer num3 = this.dive_N;
                Settings settings3 = this.settings;
                return String.format("%s #%d    %s %d/%d    %s", string3, num3, settings3.modelString(settings3.VPMModel), Integer.valueOf(this.settings.GFLo), Integer.valueOf(this.settings.GFHi), strArr[this.settings.OC_CCR]);
            default:
                return "";
        }
    }

    @Override // android.app.Activity
    protected Dialog onCreateDialog(int i) {
        switch (i) {
            case 111111:
                ProgressDialog progressDialog = new ProgressDialog(this);
                this.progressDialogWait = progressDialog;
                progressDialog.setMessage(getString(C0347R.string.WaitCalc));
                this.progressDialogWait.setIndeterminate(true);
                this.progressDialogWait.setCancelable(false);
                this.progressDialogWait.show();
                return this.progressDialogWait;
            case 121234:
                ProgressDialog progressDialog2 = new ProgressDialog(this);
                this.progressDialogNag = progressDialog2;
                progressDialog2.setProgressStyle(1);
                this.progressDialogNag.setMessage(getString(C0347R.string.BuyReg));
                this.progressDialogNag.setCancelable(false);
                this.progressDialogNag.setProgress(0);
                this.progressDialogNag.setMax(100);
                this.progressDialogNag.show();
                return this.progressDialogNag;
            case 3434255:
                String str = getString(C0347R.string.Helpimprovelanguage) + " \"" + getLocaleCode() + "\" " + getString(C0347R.string.language);
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle(getString(C0347R.string.Newlanguage));
                builder.setIcon(android.R.drawable.ic_dialog_info);
                builder.setMessage(str);
                builder.setPositiveButton("support@hhssoftware.com", new DialogInterface.OnClickListener() { // from class: com.hhssoftware.multideco.multideco_main.11
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialogInterface, int i2) {
                        String str2 = "I would like to help translate MultiDeco Android to the \"" + multideco_main.this.getLocaleCode() + "\" language.";
                        Intent intent = new Intent("android.intent.action.SEND");
                        intent.putExtra("android.intent.extra.TEXT", str2);
                        intent.putExtra("android.intent.extra.SUBJECT", "MultiDeco Android language translation");
                        intent.putExtra("android.intent.extra.EMAIL", "support@hhssoftware.com");
                        intent.setType("message/rfc822");
                        multideco_main multideco_mainVar = multideco_main.this;
                        multideco_mainVar.startActivity(Intent.createChooser(intent, multideco_mainVar.getString(C0347R.string.SelectEmail)));
                        dialogInterface.cancel();
                    }
                });
                builder.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() { // from class: com.hhssoftware.multideco.multideco_main.12
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialogInterface, int i2) {
                        dialogInterface.cancel();
                    }
                });
                AlertDialog create = builder.create();
                create.show();
                return create;
            case 4543135:
                String str2 = getString(C0347R.string.Newversionready) + " v" + VersionCheck.CurVer + "\n\n" + getString(C0347R.string.Downloadnewversionnow);
                AlertDialog.Builder builder2 = new AlertDialog.Builder(this);
                builder2.setTitle(getString(C0347R.string.Newversion));
                builder2.setIcon(android.R.drawable.ic_dialog_info);
                builder2.setMessage(str2);
                builder2.setPositiveButton(C0347R.string.Yes, new DialogInterface.OnClickListener() { // from class: com.hhssoftware.multideco.multideco_main.9
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialogInterface, int i2) {
                        Intent intent = new Intent();
                        intent.setAction("android.intent.action.VIEW");
                        intent.addCategory("android.intent.category.BROWSABLE");
                        intent.setData(Uri.parse("http://www.multideco.com/download.html"));
                        multideco_main.this.startActivity(intent);
                        dialogInterface.cancel();
                        multideco_main.this.finish();
                    }
                });
                builder2.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() { // from class: com.hhssoftware.multideco.multideco_main.10
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialogInterface, int i2) {
                        dialogInterface.cancel();
                    }
                });
                AlertDialog create2 = builder2.create();
                create2.show();
                return create2;
            default:
                return null;
        }
    }

    private final class NagTask extends AsyncTask<Integer, Integer, Void> {
        private NagTask() {
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public Void doInBackground(Integer... numArr) {
            long intValue = numArr[0].intValue() * 4;
            float f = intValue;
            while (intValue > 0 && !isCancelled()) {
                int i = 100 - ((int) ((intValue / f) * 100.0f));
                if (numArr[0].intValue() > 5) {
                    publishProgress(Integer.valueOf(i));
                }
                intValue--;
                try {
                    Thread.sleep(250L);
                } catch (InterruptedException unused) {
                }
            }
            return null;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onProgressUpdate(Integer... numArr) {
            if (multideco_main.this.progressDialogNag != null) {
                multideco_main.this.progressDialogNag.setProgress(numArr[0].intValue());
            }
        }

        @Override // android.os.AsyncTask
        protected void onPreExecute() {
            multideco_main.this.onCreateDialog(121234);
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(Void r4) {
            if (multideco_main.this.progressDialogNag != null) {
                multideco_main.this.progressDialogNag.cancel();
                multideco_main.this.progressDialogNag = null;
            }
            multideco_main.this.asyncTaskNag = null;
            new CalcTask().execute(multideco_main.this.calclevels, multideco_main.this.calcdecos, multideco_main.this.calcmaxtime);
        }

        @Override // android.os.AsyncTask
        protected void onCancelled() {
            multideco_main.this.asyncTaskNag = null;
        }
    }

    private final class CalcTask extends AsyncTask<String, Void, Integer> {
        private CalcTask() {
        }

        @Override // android.os.AsyncTask
        protected void onPreExecute() {
            multideco_main.this.onCreateDialog(111111);
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public Integer doInBackground(String... strArr) {
            int initDecoCalc = multideco_main.this.settings.initDecoCalc(multideco_main.this.settings.surfInt, strArr[0], strArr[1], strArr[2]);
            if (initDecoCalc == 0) {
                initDecoCalc = multideco_main.this.settings.decoCalc();
            }
            return Integer.valueOf(initDecoCalc);
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(Integer num) {
            multideco_main.this.progressDialogWait.cancel();
            if (num.intValue() == 0) {
                multideco_main.this.launchResultActvity();
            } else {
                multideco_main.this.doCalcErrDlg(num.intValue());
            }
        }
    }

    private final class VersionTask extends AsyncTask<Object, Void, Integer> {
        @Override // android.os.AsyncTask
        protected void onPreExecute() {
        }

        private VersionTask() {
        }

        /* JADX INFO: Access modifiers changed from: protected */
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.AsyncTask
        public Integer doInBackground(Object... objArr) {
            if (new VersionCheck((Context) objArr[0], (Boolean) objArr[1]).newVersionCheck().booleanValue()) {
                return 1;
            }
            return 0;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(Integer num) {
            if (num.intValue() == 1) {
                multideco_main.this.showDialog(4543135);
            }
        }
    }

    private final class InstalledTask extends AsyncTask<Object, Void, Integer> {
        private String inst_code;

        private InstalledTask() {
        }

        @Override // android.os.AsyncTask
        protected void onPreExecute() {
            this.inst_code = multideco_main.this.reg_code;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.AsyncTask
        public Integer doInBackground(Object... objArr) {
            Android_RSA android_RSA = new Android_RSA(multideco_main.this.getApplicationContext());
            try {
                HttpsURLConnection httpsURLConnection = (HttpsURLConnection) new URL("https://www.hhssoftware.com/cgi-bin/android_install.cgi?data=" + URLEncoder.encode(android_RSA.base64_encode(android_RSA.rsaEncrypt((this.inst_code + "=" + (multideco_main.this.agreed / 1000)).getBytes())), "utf-8")).openConnection();
                httpsURLConnection.setConnectTimeout(10000);
                httpsURLConnection.setReadTimeout(10000);
                String str = "";
                if (httpsURLConnection.getResponseCode() == 200) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpsURLConnection.getInputStream()));
                    while (true) {
                        String readLine = bufferedReader.readLine();
                        if (readLine == null) {
                            break;
                        }
                        String trim = readLine.trim();
                        if (trim.length() > 0) {
                            str = str + trim;
                        }
                    }
                    bufferedReader.close();
                }
                httpsURLConnection.disconnect();
                if (str.length() < 256) {
                    return 0;
                }
                SharedPreferences.Editor edit = multideco_main.this.getSharedPreferences("install", 0).edit();
                edit.clear();
                edit.putString("installed", str);
                edit.commit();
                return 1;
            } catch (Exception unused) {
                return 0;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(Integer num) {
            if (num.intValue() == 1) {
                multideco_main.this.readinstalled();
            }
        }
    }
}
