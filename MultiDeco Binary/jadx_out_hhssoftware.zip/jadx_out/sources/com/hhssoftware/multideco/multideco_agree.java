package com.hhssoftware.multideco;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStreamReader;

/* loaded from: classes.dex */
public class multideco_agree extends Activity implements View.OnClickListener {
    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        setTheme(new Theme_setting(this).theme_id);
        super.onCreate(bundle);
        setContentView(C0347R.layout.multideco_agree);
        if (Build.VERSION.SDK_INT < 35) {
            findViewById(C0347R.id.multideco_agree_xml).setPadding(0, 0, 0, 0);
        }
        ((TextView) findViewById(C0347R.id.TextViewLicense)).setText(readFile(this, C0347R.raw.license));
        findViewById(C0347R.id.ButtonAccept).setOnClickListener(this);
        findViewById(C0347R.id.ButtonDecline).setOnClickListener(this);
    }

    private static CharSequence readFile(Activity activity, int i) {
        BufferedReader bufferedReader;
        BufferedReader bufferedReader2 = null;
        try {
            bufferedReader = new BufferedReader(new InputStreamReader(activity.getResources().openRawResource(i)));
        } catch (IOException unused) {
        } catch (Throwable th) {
            th = th;
        }
        try {
            StringBuilder sb = new StringBuilder();
            while (true) {
                String readLine = bufferedReader.readLine();
                if (readLine != null) {
                    sb.append(readLine).append('\n');
                } else {
                    closeStream(bufferedReader);
                    return sb;
                }
            }
        } catch (IOException unused2) {
            bufferedReader2 = bufferedReader;
            closeStream(bufferedReader2);
            return "";
        } catch (Throwable th2) {
            th = th2;
            bufferedReader2 = bufferedReader;
            closeStream(bufferedReader2);
            throw th;
        }
    }

    private static void closeStream(Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (IOException unused) {
            }
        }
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        int id = view.getId();
        if (id == C0347R.id.ButtonAccept) {
            setResult(-1);
        } else if (id == C0347R.id.ButtonDecline) {
            setResult(0);
        }
        finish();
    }
}
