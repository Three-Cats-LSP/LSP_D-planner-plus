package com.hhssoftware.multideco;

import android.content.Context;
import android.provider.Settings;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.RandomAccessFile;
import java.util.Locale;
import java.util.UUID;

/* loaded from: classes.dex */
public class Identity {
    private final String KEY_FILE = "key.file";
    private final Context context;

    public Identity(Context context) {
        this.context = context;
    }

    public Boolean saveKeyString(String str) {
        this.context.deleteFile("key.file");
        try {
            FileOutputStream openFileOutput = this.context.openFileOutput("key.file", 0);
            PrintStream printStream = new PrintStream(openFileOutput);
            printStream.print(str);
            printStream.close();
            openFileOutput.close();
            return true;
        } catch (FileNotFoundException unused) {
            return false;
        } catch (IOException unused2) {
            return false;
        }
    }

    public String getKeyString() {
        try {
            FileInputStream openFileInput = this.context.openFileInput("key.file");
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(openFileInput));
            String readLine = bufferedReader.readLine();
            bufferedReader.close();
            openFileInput.close();
            return readLine.trim();
        } catch (FileNotFoundException | IOException unused) {
            return "";
        }
    }

    public String getInstallcode() {
        String m52ic = new Settings(this.context).m52ic(getDevID());
        return m52ic != null ? m52ic : "";
    }

    private String getDevID() {
        String string = Settings.Secure.getString(this.context.getContentResolver(), "android_id");
        if (string != null) {
            String lowerCase = string.toLowerCase(Locale.US);
            if (!lowerCase.equals("9774d56d682e549c") && !lowerCase.contains("000000") && lowerCase.indexOf(110) == -1) {
                return lowerCase;
            }
        }
        return new Installation().m51id(this.context);
    }

    public Boolean getRegState() {
        Boolean.valueOf(false);
        return Boolean.valueOf(new Settings(this.context).m53rs(getInstallcode(), getKeyString()) == 1);
    }

    public class Installation {
        private String sID = null;
        private final String INSTALLATION = ".install";

        public Installation() {
        }

        /* renamed from: id */
        public synchronized String m51id(Context context) {
            if (this.sID == null) {
                File file = new File(context.getFilesDir(), ".install");
                try {
                    if (!file.exists()) {
                        writeInstallationFile(file);
                    }
                    this.sID = readInstallationFile(file);
                } catch (Exception unused) {
                    return "";
                }
            }
            return this.sID;
        }

        private String readInstallationFile(File file) throws IOException {
            RandomAccessFile randomAccessFile = new RandomAccessFile(file, "r");
            byte[] bArr = new byte[(int) randomAccessFile.length()];
            randomAccessFile.readFully(bArr);
            randomAccessFile.close();
            return new String(bArr);
        }

        private void writeInstallationFile(File file) throws IOException {
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            fileOutputStream.write(UUID.randomUUID().toString().getBytes());
            fileOutputStream.close();
        }
    }
}
