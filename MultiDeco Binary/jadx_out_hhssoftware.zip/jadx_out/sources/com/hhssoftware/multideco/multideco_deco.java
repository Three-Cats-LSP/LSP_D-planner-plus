package com.hhssoftware.multideco;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;

/* loaded from: classes.dex */
public class multideco_deco extends Activity implements View.OnClickListener {
    private boolean isMetric = false;
    private int editRow = -1;
    private final String PREFS_SELECTS = "decoselects";
    private String FtorM = "ft";

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        setTheme(new Theme_setting(this).theme_id);
        super.onCreate(bundle);
        setContentView(C0347R.layout.multideco_deco);
        if (Build.VERSION.SDK_INT < 35) {
            findViewById(C0347R.id.multideco_deco_xml).setPadding(0, 0, 0, 0);
        }
        findViewById(C0347R.id.ButtonSave).setOnClickListener(this);
        findViewById(C0347R.id.ButtonCancel).setOnClickListener(this);
        Bundle extras = getIntent().getExtras();
        SharedPreferences sharedPreferences = getSharedPreferences("decoselects", 0);
        Spinner spinner = (Spinner) findViewById(C0347R.id.SpinnerO2);
        int i = android.R.layout.simple_spinner_item;
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_deco.1
            @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
            public View getDropDownView(int i2, View view, ViewGroup viewGroup) {
                View dropDownView = super.getDropDownView(i2, view, viewGroup);
                ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                return dropDownView;
            }
        };
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        for (int i2 = 1; i2 <= 100; i2++) {
            arrayAdapter.add("" + i2 + " %");
        }
        spinner.setAdapter((SpinnerAdapter) arrayAdapter);
        if (sharedPreferences.getInt("O2Select", 0) > 0) {
            spinner.setSelection(sharedPreferences.getInt("O2Select", 49));
        } else {
            spinner.setSelection(49);
        }
        Spinner spinner2 = (Spinner) findViewById(C0347R.id.SpinnerHe);
        ArrayAdapter<String> arrayAdapter2 = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_deco.2
            @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
            public View getDropDownView(int i3, View view, ViewGroup viewGroup) {
                View dropDownView = super.getDropDownView(i3, view, viewGroup);
                ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                return dropDownView;
            }
        };
        arrayAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        for (int i3 = 0; i3 <= 99; i3++) {
            arrayAdapter2.add("" + i3 + " %");
        }
        spinner2.setAdapter((SpinnerAdapter) arrayAdapter2);
        if (sharedPreferences.getInt("HeSelect", 0) > 0) {
            spinner2.setSelection(sharedPreferences.getInt("HeSelect", 0));
        } else {
            spinner2.setSelection(0);
        }
        Spinner spinner3 = (Spinner) findViewById(C0347R.id.SpinnerDecoSwap);
        ArrayAdapter<String> arrayAdapter3 = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_deco.3
            @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
            public View getDropDownView(int i4, View view, ViewGroup viewGroup) {
                View dropDownView = super.getDropDownView(i4, view, viewGroup);
                ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                return dropDownView;
            }
        };
        arrayAdapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        arrayAdapter3.add(getString(C0347R.string.Off));
        boolean z = extras.getBoolean("Metric");
        this.isMetric = z;
        if (z) {
            this.FtorM = "m";
        }
        if (z) {
            for (int i4 = 9; i4 <= 90; i4++) {
                arrayAdapter3.add("" + i4 + this.FtorM);
            }
        } else {
            for (int i5 = 30; i5 <= 300; i5 += 5) {
                arrayAdapter3.add("" + i5 + this.FtorM);
            }
        }
        spinner3.setAdapter((SpinnerAdapter) arrayAdapter3);
        if (extras.get("Row") != null) {
            this.editRow = extras.getInt("Row");
        }
        if (this.editRow <= -1 || extras.get("Edit") == null) {
            return;
        }
        String string = extras.getString("Edit");
        ((Spinner) findViewById(C0347R.id.SpinnerO2)).setSelection(Settings.LegIntSeg(string, 4) - 1);
        ((Spinner) findViewById(C0347R.id.SpinnerHe)).setSelection(Settings.LegIntSeg(string, 5));
    }

    @Override // android.app.Activity
    protected void onStop() {
        super.onStop();
        SharedPreferences.Editor edit = getSharedPreferences("decoselects", 0).edit();
        edit.putInt("O2Select", ((Spinner) findViewById(C0347R.id.SpinnerO2)).getSelectedItemPosition());
        edit.putInt("HeSelect", ((Spinner) findViewById(C0347R.id.SpinnerHe)).getSelectedItemPosition());
        edit.commit();
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        int id = view.getId();
        if (id == C0347R.id.ButtonSave) {
            Intent intent = getIntent();
            String Buildlevel = Buildlevel();
            if (Buildlevel == null) {
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle(getString(C0347R.string.Error));
                builder.setIcon(android.R.drawable.ic_dialog_alert);
                builder.setMessage(getString(C0347R.string.ErrLegSelection));
                builder.setNeutralButton(android.R.string.ok, new DialogInterface.OnClickListener() { // from class: com.hhssoftware.multideco.multideco_deco.4
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                });
                builder.create().show();
                return;
            }
            intent.putExtra("deco", Buildlevel);
            int i = this.editRow;
            if (i > -1) {
                intent.putExtra("row", i);
            }
            setResult(-1, intent);
            finish();
            return;
        }
        if (id == C0347R.id.ButtonCancel) {
            setResult(0);
            finish();
        }
    }

    private String Buildlevel() {
        int selectedItemPosition = ((Spinner) findViewById(C0347R.id.SpinnerO2)).getSelectedItemPosition() + 1;
        int selectedItemPosition2 = ((Spinner) findViewById(C0347R.id.SpinnerHe)).getSelectedItemPosition();
        int selectedItemPosition3 = ((Spinner) findViewById(C0347R.id.SpinnerDecoSwap)).getSelectedItemPosition();
        if (selectedItemPosition3 > 0) {
            selectedItemPosition3 = this.isMetric ? selectedItemPosition3 + 8 : (selectedItemPosition3 + 5) * 5;
        }
        if (selectedItemPosition + selectedItemPosition2 > 100) {
            return null;
        }
        String str = "" + selectedItemPosition;
        if (selectedItemPosition2 > 0) {
            str = str + "/" + selectedItemPosition2;
        }
        return selectedItemPosition3 > 0 ? str + " " + selectedItemPosition3 + this.FtorM : str;
    }
}
