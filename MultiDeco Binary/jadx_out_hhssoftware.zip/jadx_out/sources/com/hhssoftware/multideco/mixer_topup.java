package com.hhssoftware.multideco;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.os.MessageQueue;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;

/* loaded from: classes.dex */
public class mixer_topup extends Activity implements MessageQueue.IdleHandler {
    private Boolean isIniting;
    private Settings settings;
    private final String PREFS_MIXER = "mixer_topup";
    private TextWatcher textWatcher = new TextWatcher() { // from class: com.hhssoftware.multideco.mixer_topup.1
        @Override // android.text.TextWatcher
        public void afterTextChanged(Editable editable) {
        }

        @Override // android.text.TextWatcher
        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        @Override // android.text.TextWatcher
        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            if (mixer_topup.this.isIniting.booleanValue()) {
                return;
            }
            mixer_topup.this.performCalc();
        }
    };

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        setTheme(new Theme_setting(this).theme_id);
        super.onCreate(bundle);
        setContentView(C0347R.layout.mixer_topup);
        this.settings = new Settings(this);
        this.isIniting = true;
        if (Build.VERSION.SDK_INT < 35) {
            findViewById(C0347R.id.mixer_topup_xml).setPadding(0, 0, 0, 0);
        }
        ((EditText) findViewById(C0347R.id.topuppressold)).addTextChangedListener(this.textWatcher);
        ((EditText) findViewById(C0347R.id.topuppressnew)).addTextChangedListener(this.textWatcher);
        ((EditText) findViewById(C0347R.id.topupo2old)).addTextChangedListener(this.textWatcher);
        ((EditText) findViewById(C0347R.id.topupheold)).addTextChangedListener(this.textWatcher);
        ((EditText) findViewById(C0347R.id.topupwitho2)).addTextChangedListener(this.textWatcher);
        ((EditText) findViewById(C0347R.id.topupwithhe)).addTextChangedListener(this.textWatcher);
        SharedPreferences sharedPreferences = getSharedPreferences("mixer_topup", 0);
        loadPrefs(sharedPreferences);
        try {
            performCalc();
        } catch (Exception unused) {
            SharedPreferences.Editor edit = sharedPreferences.edit();
            edit.clear();
            edit.commit();
            loadPrefs(sharedPreferences);
        }
        this.isIniting = false;
        Looper.myQueue().addIdleHandler(this);
    }

    private void loadPrefs(SharedPreferences sharedPreferences) {
        ((EditText) findViewById(C0347R.id.topuppressold)).setText(sharedPreferences.getString("topuppressold", ""));
        ((EditText) findViewById(C0347R.id.topuppressnew)).setText(sharedPreferences.getString("topuppressnew", ""));
        ((EditText) findViewById(C0347R.id.topupo2old)).setText(sharedPreferences.getString("topupo2old", ""));
        ((EditText) findViewById(C0347R.id.topupheold)).setText(sharedPreferences.getString("topupheold", ""));
        ((EditText) findViewById(C0347R.id.topupwitho2)).setText(sharedPreferences.getString("topupwitho2", ""));
        ((EditText) findViewById(C0347R.id.topupwithhe)).setText(sharedPreferences.getString("topupwithhe", ""));
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        SharedPreferences.Editor edit = getSharedPreferences("mixer_topup", 0).edit();
        edit.putString("topuppressold", ((EditText) findViewById(C0347R.id.topuppressold)).getText().toString());
        edit.putString("topuppressnew", ((EditText) findViewById(C0347R.id.topuppressnew)).getText().toString());
        edit.putString("topupo2old", ((EditText) findViewById(C0347R.id.topupo2old)).getText().toString());
        edit.putString("topupheold", ((EditText) findViewById(C0347R.id.topupheold)).getText().toString());
        edit.putString("topupwitho2", ((EditText) findViewById(C0347R.id.topupwitho2)).getText().toString());
        edit.putString("topupwithhe", ((EditText) findViewById(C0347R.id.topupwithhe)).getText().toString());
        edit.commit();
        super.onDestroy();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void performCalc() {
        String[] strArr = new String[10];
        ((EditText) findViewById(C0347R.id.topupresult)).setText("");
        if (((EditText) findViewById(C0347R.id.topuppressold)).getText().length() == 0 || ((EditText) findViewById(C0347R.id.topuppressnew)).getText().length() == 0 || ((EditText) findViewById(C0347R.id.topupo2old)).getText().length() == 0 || ((EditText) findViewById(C0347R.id.topupheold)).getText().length() == 0 || ((EditText) findViewById(C0347R.id.topupwitho2)).getText().length() == 0) {
            return;
        }
        if (((EditText) findViewById(C0347R.id.topupwithhe)).getText().length() == 0) {
            ((EditText) findViewById(C0347R.id.topupwithhe)).setText("0");
        }
        if (Double.parseDouble(((EditText) findViewById(C0347R.id.topuppressold)).getText().toString().replace(',', '.')) >= Double.parseDouble(((EditText) findViewById(C0347R.id.topuppressnew)).getText().toString().replace(',', '.')) || Double.parseDouble(((EditText) findViewById(C0347R.id.topupo2old)).getText().toString().replace(',', '.')) < 0.0d || Double.parseDouble(((EditText) findViewById(C0347R.id.topupo2old)).getText().toString().replace(',', '.')) > 100.0d || Double.parseDouble(((EditText) findViewById(C0347R.id.topupheold)).getText().toString().replace(',', '.')) > 100.0d || Double.parseDouble(((EditText) findViewById(C0347R.id.topupwitho2)).getText().toString().replace(',', '.')) < 0.0d || Double.parseDouble(((EditText) findViewById(C0347R.id.topupwitho2)).getText().toString().replace(',', '.')) > 100.0d || Double.parseDouble(((EditText) findViewById(C0347R.id.topupwithhe)).getText().toString().replace(',', '.')) > 100.0d) {
            return;
        }
        strArr[0] = "725";
        strArr[1] = this.settings.mix_units + "";
        strArr[2] = ((EditText) findViewById(C0347R.id.topuppressold)).getText().toString();
        strArr[3] = ((EditText) findViewById(C0347R.id.topuppressnew)).getText().toString();
        strArr[4] = ((EditText) findViewById(C0347R.id.topupo2old)).getText().toString();
        strArr[5] = ((EditText) findViewById(C0347R.id.topupheold)).getText().toString();
        strArr[6] = ((EditText) findViewById(C0347R.id.topupwitho2)).getText().toString();
        strArr[7] = "";
        strArr[8] = this.settings.mix_temp + "";
        strArr[9] = ((EditText) findViewById(C0347R.id.topupwithhe)).getText().toString();
        ((EditText) findViewById(C0347R.id.topupresult)).setText(new tools_calc().performCalc(strArr)[7]);
        Looper.myQueue().addIdleHandler(this);
    }

    @Override // android.os.MessageQueue.IdleHandler
    public boolean queueIdle() {
        this.isIniting = false;
        return false;
    }
}
