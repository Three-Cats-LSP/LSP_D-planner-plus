package com.hhssoftware.multideco;

import android.content.Context;
import android.content.pm.PackageManager;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

/* loaded from: classes.dex */
public class Settings implements Serializable {
    public static final int CCR_dive = 1;
    public static final int CuFt = 0;
    public static final int ERR_BAD_ASC_RATE = 4;
    public static final int ERR_BAD_DEC_RATE = 3;
    public static final int ERR_GAP_ASC_RATE = 5;
    public static final int ERR_GAP_DEC_RATE = 6;
    public static final int ERR_MAXPO2_STEP_CONFLICT = 8;
    public static final int ERR_MAXTIME_GAS_MISSMATCH = 21;
    public static final int ERR_MAXTIME_NOTENOUGHGAS = 22;
    public static final int ERR_MAXTIME_OUTOFRANGE = 20;
    public static final int ERR_MIX_STEP_CONFLICT = 7;
    public static final int ERR_NOOXY = 129;
    public static final int ERR_NO_BOTTOM_SEG = 1;
    public static final int ERR_NO_ERR = 0;
    public static final int ERR_NO_JNI_MEMORY = 10;
    public static final int ERR_PPOVER1 = 128;
    public static final int ERR_SEGSHORTPLAN = 131;
    public static final int ERR_SEGTOOSHORT = 130;
    public static final int ERR_STEP_SIZE_INVALID = 2;
    public static final int ERR_STOPTOOBIG = 132;
    public static final int ERR_UNKNOWN_ERROR = 9;
    public static final int Fresh = 1;
    public static final int Ltr = 1;
    public static final int MAX_RATES = 25;
    public static final int MAX_RMV = 55;
    public static final int MAX_WARNCOLOR = 9;
    public static final int OC_dive = 0;
    private static final long OLD_serialVersionUID = 2;
    private static final long OLD_serialVersionUID_4 = 4;
    private static final long OLD_serialVersionUID_5 = 5;
    public static final int Salt = 0;
    public static final int SetPtATA = 1;
    public static final int SetPtBar = 0;
    public static final int VPMA = 0;
    public static final int VPMB = 1;
    public static final int VPMBE = 2;
    public static final int VPMBFBO = 3;
    public static final int VPMB_GFS = 4;
    private static final String VPM_config_stream = "vpm_config.data";
    public static final int ZHLB_GF = 5;
    public static final int ZHLC_GF = 6;
    private static Boolean initialized = null;
    public static final int kASC_Asc = 8;
    public static final int kASC_Deco = 16;
    public static final int kASC_Surf = 24;
    public static final int kCCRWarn = 64;
    public static final int kCNSWarn = 8;
    public static final int kGasVolHardLimit = 128;
    public static final int kGasVolSoftLimit = 256;
    public static final int kHighppO2Warn = 1;
    public static final int kIBCDHeWarn = 32;
    public static final int kIBCDN2Warn = 16;
    public static final int kLowppO2Warn = 2;
    public static final int kOTUWarn = 4;
    public static final int lsDecoFrom = 9;
    public static final int lsDepth = 1;
    public static final int lsHe = 5;
    public static final int lsMix = 3;
    public static final int lsO2 = 4;
    public static final int lsOC = 6;
    public static final int lsSCR = 7;
    public static final int lsSP = 8;
    public static final int lsTime = 2;
    private static final long serialVersionUID = 6;
    public boolean AccelDeepStop;
    public boolean AccelMidStop;
    public boolean AccelShallowStop;
    public boolean Accelerate;
    public int Alerts;
    public int Alt;
    public int Brmv;
    public double CCRStart;
    public int CNSHigh;
    public int Depths;
    public boolean DoubleSizeDeep;
    public int Drmv;
    public int ExtStop;
    public int ExtStopDeep;
    public boolean Extend;
    public boolean ExtendAdd;
    public boolean ExtendAlways;
    public int FromAlt;
    public int GFHi;
    public int GFLo;
    public int GFS;
    public boolean GuageType;
    public boolean HalfTimeDeep;
    public int Last;
    public int LastCC;
    public int LastSavedAlt;
    public int Margin;
    public int MaxO2;
    public boolean Metric;
    public boolean O2Affect;
    public int OC_CCR;
    public int OTUHigh;
    public boolean OxyNarc;
    public int RMVs;
    public boolean SCRDataValid;
    public boolean SCRO2Drop;
    public int SetpointUnits;
    public int Step;
    public int StopTime;
    public double TimeAt;
    public double Travel;
    public int TwoWeeks;
    public int VPMModel;
    public int WaterType;
    public int ascent;
    public boolean bailCaveBail;
    public int bailCavePortion;
    public int bailConserve;
    public int bailConserveGFHi;
    public int bailConserveGFLo;
    public int bailConserveGFS;
    public int bailDiveN;
    public boolean bailExtraMin;
    public int bailExtraMinTime;
    public int bailModel;
    public int bailRMV;
    public boolean bailactive;
    private Context context;
    public int descent;
    public boolean mix_banked32;
    public int mix_temp;
    public int mix_temp_units;
    public int mix_units;
    public int ppHeHigh;
    public int ppN2High;
    public int ppO2;
    public int ppO2Above;
    public int ppO2Below;
    public int ppO2Deep;
    public int ppO2ReallyDeep;
    public int surfInt;
    public int[] warn_colors = new int[9];
    public static final float[] ppO2Swaps = {1.2f, 1.3f, 1.4f, 1.5f, 1.6f};
    public static final float[] StopTimes = {1.0f, 0.5f, 0.16666666f, 0.016666666f};

    static int elevationValue(int i, boolean z) {
        return z ? i * 75 : i * 250;
    }

    static float lastStopValue(int i, boolean z) {
        if (z) {
            if (i == 0) {
                return 3.0f;
            }
            if (i == 1) {
                return 4.5f;
            }
            if (i == 2) {
                return 5.0f;
            }
            if (i == 3) {
                return 6.0f;
            }
            if (i == 4) {
                return 9.0f;
            }
        }
        if (i == 0) {
            return 10.0f;
        }
        if (i == 1 || i == 2) {
            return 15.0f;
        }
        if (i == 3) {
            return 20.0f;
        }
        return i == 4 ? 30.0f : 1.0f;
    }

    static int rateValue(int i, boolean z) {
        if (!z) {
            if (i == 0) {
                return 1;
            }
            if (i == 1) {
                return 3;
            }
            if (i == 2) {
                return 5;
            }
            if (i != 3) {
                return (i - 2) * 5;
            }
            return 7;
        }
        switch (i) {
            case 0:
                return 1;
            case 1:
                return 2;
            case 2:
                return 3;
            case 3:
                return 5;
            case 4:
                return 6;
            case 5:
                return 7;
            case 6:
                return 8;
            case 7:
                return 9;
            default:
                return (i - 3) * 2;
        }
    }

    static float rmvValue(int i, boolean z) {
        return z ? i + 5 : (i * 0.04f) + 0.16f;
    }

    native int cleanup();

    native int decoCalc();

    native String[] diveReport();

    native int getCurrentDiveN();

    native String getErrString();

    native int getResultRows();

    native int getWarning(int i);

    /* renamed from: ic */
    native String m52ic(String str);

    native int initDecoCalc(int i, String str, String str2, String str3);

    native int nextDive(boolean z);

    native String[] resultRow(int i);

    /* renamed from: rs */
    native int m53rs(String str, String str2);

    native int setPackage(String str);

    static {
        System.loadLibrary("multideco");
        initialized = false;
    }

    public Settings(Context context) {
        this.context = context;
        initConfig();
        loadConfig();
        if (initialized.booleanValue()) {
            return;
        }
        try {
            if (setPackage(this.context.getPackageManager().getApplicationInfo(this.context.getPackageName(), 0).sourceDir) == 1) {
                resetConfig();
            }
        } catch (PackageManager.NameNotFoundException unused) {
        }
        initialized = true;
    }

    public void resetConfig() {
        int i = this.OC_CCR;
        initConfig();
        this.OC_CCR = i;
        saveConfig();
    }

    public void reloadConfig() {
        loadConfig();
    }

    public void upgrade_settings_version(long j) {
        int i = (int) j;
        if (i == 4) {
            this.Brmv += 5;
            this.Drmv += 5;
        } else if (i != 5) {
            return;
        }
        this.bailExtraMin = false;
        this.bailExtraMinTime = 2;
    }

    /* JADX WARN: Removed duplicated region for block: B:29:0x008a  */
    /* JADX WARN: Removed duplicated region for block: B:65:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    static String LegStrSeg(String str, int i) {
        String str2;
        String str3;
        String substring;
        String substring2;
        Boolean valueOf = Boolean.valueOf(str.indexOf(", ") > -1);
        int indexOf = str.indexOf("ft");
        if (indexOf > -1) {
            str = str.substring(0, indexOf);
        }
        int indexOf2 = str.indexOf("m");
        if (indexOf2 > -1) {
            str = str.substring(0, indexOf2);
        }
        int indexOf3 = str.indexOf(", ");
        if (indexOf3 <= -1) {
            str2 = "";
        } else {
            str2 = str.substring(0, indexOf3);
            str = str.substring(indexOf3 + 2);
        }
        if (i == 1) {
            return str2;
        }
        int indexOf4 = str.indexOf(", ");
        if (indexOf4 > -1) {
            str2 = str.substring(0, indexOf4);
            str = str.substring(indexOf4 + 2);
            if (str2.compareTo("-") == 0) {
                str2 = "0";
            }
        }
        if (i == 2) {
            return str2;
        }
        int indexOf5 = str.indexOf(", ");
        if (indexOf5 > -1) {
            substring = str.substring(0, indexOf5);
            substring2 = str.substring(indexOf5 + 2);
        } else {
            if (str.indexOf(" ") <= -1) {
                str3 = "";
                if (i != 3) {
                    return str;
                }
                if (i == 4) {
                    int indexOf6 = str.indexOf(47);
                    return indexOf6 > -1 ? str.substring(0, indexOf6) : str;
                }
                if (i == 5) {
                    int indexOf7 = str.indexOf(47);
                    if (indexOf7 <= -1) {
                        return "";
                    }
                    return str.substring(indexOf7 + 1);
                }
                if (i != 9 || valueOf.booleanValue()) {
                    return i == 8 ? "" : "";
                }
                return str3;
            }
            int indexOf8 = str.indexOf(" ");
            substring = str.substring(0, indexOf8);
            substring2 = str.substring(indexOf8 + 1);
        }
        str3 = substring2;
        str = substring;
        if (i != 3) {
        }
    }

    static double LegFloatSeg(String str, int i) {
        String LegStrSeg = LegStrSeg(str, i);
        if (LegStrSeg.length() == 0) {
            return 0.0d;
        }
        return Double.parseDouble(LegStrSeg.replace(',', '.'));
    }

    static int LegIntSeg(String str, int i) {
        return (int) LegFloatSeg(str, i);
    }

    static String LegStrFltFmt(String str) {
        String LegStrSeg = LegStrSeg(str, 8);
        if (LegStrSeg.length() == 0) {
            return str;
        }
        return str.substring(0, str.lastIndexOf(", ") + 2) + LegStrSeg.replace(',', '.');
    }

    String modelString(int i) {
        switch (i) {
            case 0:
                return "VPM";
            case 1:
                return "VPM-B";
            case 2:
                return "VPM-B/E";
            case 3:
                return "VPM-B/FBO";
            case 4:
                return "VPM-B + GFS";
            case 5:
                return "ZHLB-GF";
            case 6:
                return "ZHLC-GF";
            default:
                return "";
        }
    }

    private void initConfig() {
        this.CCRStart = 0.7d;
        this.LastSavedAlt = 0;
        this.Depths = 0;
        this.Metric = false;
        this.RMVs = 0;
        this.StopTime = 0;
        this.Margin = 2;
        this.Alt = 0;
        this.TimeAt = 2.0d;
        this.FromAlt = 0;
        this.Travel = 2.0d;
        this.TwoWeeks = 0;
        this.Extend = false;
        this.O2Affect = false;
        this.ExtendAlways = false;
        this.ExtStop = 5;
        this.ExtStopDeep = 2;
        this.Step = 0;
        this.Last = 0;
        this.LastCC = 0;
        this.Brmv = 17;
        this.Drmv = 15;
        this.ppO2 = 4;
        this.ppO2Deep = 3;
        this.ppO2ReallyDeep = 2;
        this.MaxO2 = 3;
        this.DoubleSizeDeep = false;
        this.HalfTimeDeep = false;
        this.ExtendAdd = false;
        this.WaterType = 0;
        this.SetpointUnits = 0;
        this.VPMModel = 1;
        this.SCRO2Drop = false;
        this.SCRDataValid = false;
        this.GuageType = true;
        this.AccelShallowStop = false;
        this.AccelMidStop = false;
        this.AccelDeepStop = false;
        this.Accelerate = false;
        this.OxyNarc = false;
        this.Alerts = Integer.MAX_VALUE;
        this.ppO2Above = 160;
        this.ppO2Below = 16;
        this.OTUHigh = 300;
        this.CNSHigh = 80;
        this.ppN2High = 50;
        this.ppHeHigh = 50;
        this.OC_CCR = 0;
        this.descent = 14;
        this.ascent = 7;
        int[] iArr = this.warn_colors;
        iArr[0] = 16744576;
        iArr[1] = 16744576;
        iArr[2] = 16776960;
        iArr[3] = 16776960;
        iArr[4] = 16711680;
        iArr[5] = 16711680;
        iArr[6] = 16744512;
        iArr[7] = 16744448;
        iArr[8] = 65280;
        this.mix_units = 0;
        this.mix_temp = 4;
        this.mix_temp_units = 0;
        this.mix_banked32 = false;
        this.bailactive = false;
        this.bailRMV = (int) (17 * 1.25d);
        this.bailModel = 3;
        this.bailConserve = 3;
        this.bailCaveBail = false;
        this.bailCavePortion = 5;
        this.bailConserveGFS = 90;
        this.bailConserveGFLo = 50;
        this.bailConserveGFHi = 90;
        this.GFLo = 30;
        this.GFHi = 85;
        this.GFS = 90;
        this.bailExtraMin = false;
        this.bailExtraMinTime = 2;
        this.surfInt = -1;
    }

    private void loadConfig() {
        int i;
        try {
            FileInputStream openFileInput = this.context.openFileInput(VPM_config_stream);
            ObjectInputStream objectInputStream = new ObjectInputStream(openFileInput);
            long readLong = objectInputStream.readLong();
            if (readLong >= OLD_serialVersionUID && readLong <= serialVersionUID) {
                this.CCRStart = objectInputStream.readDouble();
                this.LastSavedAlt = objectInputStream.readInt();
                this.Depths = objectInputStream.readInt();
                this.Metric = objectInputStream.readBoolean();
                this.RMVs = objectInputStream.readInt();
                this.StopTime = objectInputStream.readInt();
                this.Margin = objectInputStream.readInt();
                this.Alt = objectInputStream.readInt();
                this.TimeAt = objectInputStream.readDouble();
                this.FromAlt = objectInputStream.readInt();
                this.Travel = objectInputStream.readDouble();
                this.TwoWeeks = objectInputStream.readInt();
                this.Extend = objectInputStream.readBoolean();
                this.O2Affect = objectInputStream.readBoolean();
                this.ExtendAlways = objectInputStream.readBoolean();
                this.ExtStop = objectInputStream.readInt();
                this.ExtStopDeep = objectInputStream.readInt();
                this.Step = objectInputStream.readInt();
                this.Last = objectInputStream.readInt();
                this.LastCC = objectInputStream.readInt();
                this.Brmv = objectInputStream.readInt();
                this.Drmv = objectInputStream.readInt();
                this.ppO2 = objectInputStream.readInt();
                this.ppO2Deep = objectInputStream.readInt();
                this.ppO2ReallyDeep = objectInputStream.readInt();
                this.MaxO2 = objectInputStream.readInt();
                this.DoubleSizeDeep = objectInputStream.readBoolean();
                this.HalfTimeDeep = objectInputStream.readBoolean();
                this.ExtendAdd = objectInputStream.readBoolean();
                this.WaterType = objectInputStream.readInt();
                this.SetpointUnits = objectInputStream.readInt();
                this.VPMModel = objectInputStream.readInt();
                this.SCRO2Drop = objectInputStream.readBoolean();
                this.SCRDataValid = objectInputStream.readBoolean();
                this.GuageType = objectInputStream.readBoolean();
                this.AccelShallowStop = objectInputStream.readBoolean();
                this.AccelMidStop = objectInputStream.readBoolean();
                this.AccelDeepStop = objectInputStream.readBoolean();
                this.Accelerate = objectInputStream.readBoolean();
                this.OxyNarc = objectInputStream.readBoolean();
                this.Alerts = objectInputStream.readInt();
                this.ppO2Above = objectInputStream.readInt();
                this.ppO2Below = objectInputStream.readInt();
                this.OTUHigh = objectInputStream.readInt();
                this.CNSHigh = objectInputStream.readInt();
                this.ppN2High = objectInputStream.readInt();
                this.ppHeHigh = objectInputStream.readInt();
                this.OC_CCR = objectInputStream.readInt();
                this.descent = objectInputStream.readInt();
                this.ascent = objectInputStream.readInt();
                int i2 = 0;
                while (true) {
                    if (i2 >= 7) {
                        break;
                    }
                    this.warn_colors[i2] = objectInputStream.readInt();
                    i2++;
                }
                if (readLong >= OLD_serialVersionUID_4) {
                    for (i = 7; i < 9; i++) {
                        this.warn_colors[i] = objectInputStream.readInt();
                    }
                }
                this.mix_units = objectInputStream.readInt();
                this.mix_temp = objectInputStream.readInt();
                this.mix_temp_units = objectInputStream.readInt();
                this.mix_banked32 = objectInputStream.readBoolean();
                this.bailactive = objectInputStream.readBoolean();
                this.bailRMV = objectInputStream.readInt();
                this.bailModel = objectInputStream.readInt();
                this.bailConserve = objectInputStream.readInt();
                this.bailCaveBail = objectInputStream.readBoolean();
                this.bailCavePortion = objectInputStream.readInt();
                this.bailConserveGFS = objectInputStream.readInt();
                this.bailConserveGFLo = objectInputStream.readInt();
                this.bailConserveGFHi = objectInputStream.readInt();
                this.GFLo = objectInputStream.readInt();
                this.GFHi = objectInputStream.readInt();
                int readInt = objectInputStream.readInt();
                this.GFS = readInt;
                int i3 = this.GFLo;
                if (i3 < 10 || i3 > 100) {
                    this.GFLo = 30;
                }
                int i4 = this.GFHi;
                if (i4 < 50 || i4 > 100) {
                    this.GFHi = 85;
                }
                int i5 = this.GFHi;
                int i6 = this.GFLo;
                if (i5 < i6) {
                    this.GFHi = i6;
                }
                if (readInt < 70 || readInt > 100) {
                    this.GFS = 90;
                }
                if (readLong >= serialVersionUID) {
                    this.bailExtraMin = objectInputStream.readBoolean();
                    this.bailExtraMinTime = objectInputStream.readInt();
                }
                objectInputStream.close();
                openFileInput.close();
                if (readLong < serialVersionUID) {
                    upgrade_settings_version(readLong);
                    return;
                }
                return;
            }
            objectInputStream.close();
            this.context.deleteFile(VPM_config_stream);
        } catch (FileNotFoundException unused) {
        } catch (Exception unused2) {
            this.context.deleteFile(VPM_config_stream);
            initConfig();
        }
    }

    public void saveConfig() {
        try {
            FileOutputStream openFileOutput = this.context.openFileOutput(VPM_config_stream, 0);
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(openFileOutput);
            objectOutputStream.writeLong(serialVersionUID);
            objectOutputStream.writeDouble(this.CCRStart);
            objectOutputStream.writeInt(this.LastSavedAlt);
            objectOutputStream.writeInt(this.Depths);
            objectOutputStream.writeBoolean(this.Metric);
            objectOutputStream.writeInt(this.RMVs);
            objectOutputStream.writeInt(this.StopTime);
            objectOutputStream.writeInt(this.Margin);
            objectOutputStream.writeInt(this.Alt);
            objectOutputStream.writeDouble(this.TimeAt);
            objectOutputStream.writeInt(this.FromAlt);
            objectOutputStream.writeDouble(this.Travel);
            objectOutputStream.writeInt(this.TwoWeeks);
            objectOutputStream.writeBoolean(this.Extend);
            objectOutputStream.writeBoolean(this.O2Affect);
            objectOutputStream.writeBoolean(this.ExtendAlways);
            objectOutputStream.writeInt(this.ExtStop);
            objectOutputStream.writeInt(this.ExtStopDeep);
            objectOutputStream.writeInt(this.Step);
            objectOutputStream.writeInt(this.Last);
            objectOutputStream.writeInt(this.LastCC);
            objectOutputStream.writeInt(this.Brmv);
            objectOutputStream.writeInt(this.Drmv);
            objectOutputStream.writeInt(this.ppO2);
            objectOutputStream.writeInt(this.ppO2Deep);
            objectOutputStream.writeInt(this.ppO2ReallyDeep);
            objectOutputStream.writeInt(this.MaxO2);
            objectOutputStream.writeBoolean(this.DoubleSizeDeep);
            objectOutputStream.writeBoolean(this.HalfTimeDeep);
            objectOutputStream.writeBoolean(this.ExtendAdd);
            objectOutputStream.writeInt(this.WaterType);
            objectOutputStream.writeInt(this.SetpointUnits);
            objectOutputStream.writeInt(this.VPMModel);
            objectOutputStream.writeBoolean(this.SCRO2Drop);
            objectOutputStream.writeBoolean(this.SCRDataValid);
            objectOutputStream.writeBoolean(this.GuageType);
            objectOutputStream.writeBoolean(this.AccelShallowStop);
            objectOutputStream.writeBoolean(this.AccelMidStop);
            objectOutputStream.writeBoolean(this.AccelDeepStop);
            objectOutputStream.writeBoolean(this.Accelerate);
            objectOutputStream.writeBoolean(this.OxyNarc);
            objectOutputStream.writeInt(this.Alerts);
            objectOutputStream.writeInt(this.ppO2Above);
            objectOutputStream.writeInt(this.ppO2Below);
            objectOutputStream.writeInt(this.OTUHigh);
            objectOutputStream.writeInt(this.CNSHigh);
            objectOutputStream.writeInt(this.ppN2High);
            objectOutputStream.writeInt(this.ppHeHigh);
            objectOutputStream.writeInt(this.OC_CCR);
            objectOutputStream.writeInt(this.descent);
            objectOutputStream.writeInt(this.ascent);
            for (int i = 0; i < 9; i++) {
                objectOutputStream.writeInt(this.warn_colors[i]);
            }
            objectOutputStream.writeInt(this.mix_units);
            objectOutputStream.writeInt(this.mix_temp);
            objectOutputStream.writeInt(this.mix_temp_units);
            objectOutputStream.writeBoolean(this.mix_banked32);
            objectOutputStream.writeBoolean(this.bailactive);
            objectOutputStream.writeInt(this.bailRMV);
            objectOutputStream.writeInt(this.bailModel);
            objectOutputStream.writeInt(this.bailConserve);
            objectOutputStream.writeBoolean(this.bailCaveBail);
            objectOutputStream.writeInt(this.bailCavePortion);
            objectOutputStream.writeInt(this.bailConserveGFS);
            objectOutputStream.writeInt(this.bailConserveGFLo);
            objectOutputStream.writeInt(this.bailConserveGFHi);
            objectOutputStream.writeInt(this.GFLo);
            objectOutputStream.writeInt(this.GFHi);
            objectOutputStream.writeInt(this.GFS);
            objectOutputStream.writeBoolean(this.bailExtraMin);
            objectOutputStream.writeInt(this.bailExtraMinTime);
            objectOutputStream.close();
            openFileOutput.close();
        } catch (FileNotFoundException | IOException unused) {
        }
    }

    public long configVersion() {
        try {
            FileInputStream openFileInput = this.context.openFileInput(VPM_config_stream);
            ObjectInputStream objectInputStream = new ObjectInputStream(openFileInput);
            long readLong = objectInputStream.readLong();
            objectInputStream.close();
            openFileInput.close();
            return readLong;
        } catch (FileNotFoundException | Exception unused) {
            return -1L;
        }
    }

    public String err_str(int i) {
        switch (i) {
            case 0:
                return this.context.getString(C0347R.string.err_str_0);
            case 1:
                return this.context.getString(C0347R.string.err_str_1);
            case 2:
                return this.context.getString(C0347R.string.err_str_2);
            case 3:
                return this.context.getString(C0347R.string.err_str_3);
            case 4:
                return this.context.getString(C0347R.string.err_str_4);
            case 5:
                return this.context.getString(C0347R.string.err_str_5);
            case 6:
                return this.context.getString(C0347R.string.err_str_6);
            case 7:
                return this.context.getString(C0347R.string.err_str_7);
            case 8:
                return this.context.getString(C0347R.string.err_str_8);
            case 9:
                return this.context.getString(C0347R.string.err_str_9);
            case 10:
                return this.context.getString(C0347R.string.err_str_10);
            default:
                switch (i) {
                    case 20:
                        return this.context.getString(C0347R.string.err_str_20);
                    case 21:
                        return this.context.getString(C0347R.string.err_str_21);
                    case 22:
                        return this.context.getString(C0347R.string.err_str_22);
                    default:
                        switch (i) {
                            case 128:
                                return this.context.getString(C0347R.string.err_str_128);
                            case ERR_NOOXY /* 129 */:
                                return this.context.getString(C0347R.string.err_str_129);
                            case ERR_SEGTOOSHORT /* 130 */:
                                return this.context.getString(C0347R.string.err_str_130_1) + getErrString() + this.context.getString(C0347R.string.err_str_130_2);
                            case ERR_SEGSHORTPLAN /* 131 */:
                                return this.context.getString(C0347R.string.err_str_131_1) + getErrString() + this.context.getString(C0347R.string.err_str_131_2);
                            case ERR_STOPTOOBIG /* 132 */:
                                return this.context.getString(C0347R.string.err_str_132);
                            default:
                                return this.context.getString(C0347R.string.err_str_0);
                        }
                }
        }
    }

    public String warn_str(int i) {
        if (i == 1) {
            return this.context.getString(C0347R.string.warn_str_1);
        }
        if (i == 2) {
            return this.context.getString(C0347R.string.warn_str_2);
        }
        if (i == 4) {
            return this.context.getString(C0347R.string.warn_str_3);
        }
        if (i == 8) {
            return this.context.getString(C0347R.string.warn_str_4);
        }
        if (i == 16) {
            return this.context.getString(C0347R.string.warn_str_5);
        }
        if (i == 32) {
            return this.context.getString(C0347R.string.warn_str_6);
        }
        if (i == 64) {
            return this.context.getString(C0347R.string.warn_str_7);
        }
        if (i == 128) {
            return this.context.getString(C0347R.string.warn_str_8);
        }
        if (i == 256) {
            return this.context.getString(C0347R.string.warn_str_9);
        }
        return this.context.getString(C0347R.string.warn_str_0);
    }
}
