package com.hhssoftware.multideco;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;
import com.hhssoftware.multideco.Gastank_setting;

/* loaded from: classes.dex */
public class settank extends Activity implements View.OnClickListener {
    private Gastank_setting gastanksettings;

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        setTheme(new Theme_setting(this).theme_id);
        super.onCreate(bundle);
        setContentView(C0347R.layout.settank);
        findViewById(C0347R.id.imageBtnAddTank).setOnClickListener(this);
        findViewById(C0347R.id.imageBtnDeleteTank).setOnClickListener(this);
        Intent intent = getIntent();
        int i = intent.hasExtra("BAIL") ? 2 : 1;
        setResult(0, intent);
        this.gastanksettings = new Gastank_setting(this, i);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1) { // from class: com.hhssoftware.multideco.settank.1
            @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
            public View getDropDownView(int i2, View view, ViewGroup viewGroup) {
                View dropDownView = super.getDropDownView(i2, view, viewGroup);
                ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                return dropDownView;
            }
        };
        for (int i2 = 0; i2 < this.gastanksettings.valid_gastanks(); i2++) {
            Gastank_setting.TankSize tankSize = this.gastanksettings.gettank(i2);
            String str = tankSize.Name;
            if ((tankSize.Params & 4) > 0) {
                str = str + "psi";
            } else if ((tankSize.Params & 8) > 0) {
                str = str + "bar";
            }
            arrayAdapter.add(str);
        }
        if (arrayAdapter.isEmpty()) {
            arrayAdapter.add(getString(C0347R.string.NoneAddNow));
        }
        ListView listView = (ListView) findViewById(C0347R.id.listViewTanks);
        listView.setAdapter((ListAdapter) arrayAdapter);
        listView.setChoiceMode(1);
        listView.setSelector(android.R.color.darker_gray);
        getWindow().setSoftInputMode(2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void reload_listview() {
        ListView listView = (ListView) findViewById(C0347R.id.listViewTanks);
        ArrayAdapter arrayAdapter = (ArrayAdapter) listView.getAdapter();
        arrayAdapter.clear();
        for (int i = 0; i < this.gastanksettings.valid_gastanks(); i++) {
            Gastank_setting.TankSize tankSize = this.gastanksettings.gettank(i);
            String str = tankSize.Name;
            if ((tankSize.Params & 4) > 0) {
                str = str + "psi";
            } else if ((tankSize.Params & 8) > 0) {
                str = str + "bar";
            }
            arrayAdapter.add(str);
        }
        if (arrayAdapter.isEmpty()) {
            arrayAdapter.add(getString(C0347R.string.NoneAddNow));
        }
        listView.setItemChecked(listView.getCheckedItemPosition(), false);
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        int checkedItemPosition;
        int id = view.getId();
        if (id == C0347R.id.imageBtnAddTank) {
            EditText editText = (EditText) findViewById(C0347R.id.editTextTankName);
            RadioButton radioButton = (RadioButton) findViewById(C0347R.id.radioBtnLiter);
            CheckBox checkBox = (CheckBox) findViewById(C0347R.id.checkBoxDoubletank);
            EditText editText2 = (EditText) findViewById(C0347R.id.editTextPressFull);
            RadioButton radioButton2 = (RadioButton) findViewById(C0347R.id.radioBtnTankBAR);
            String obj = editText.getText().toString();
            if (obj.length() == 0 || editText2.getText().toString().length() == 0) {
                return;
            }
            final Gastank_setting.TankSize tankSize = new Gastank_setting.TankSize();
            tankSize.Name = obj;
            tankSize.Size = Double.parseDouble(obj.replace(",", "."));
            tankSize.Doubled = checkBox.isChecked();
            String obj2 = editText2.getText().toString();
            tankSize.FillPress = Double.parseDouble(obj2.replace(",", "."));
            if (tankSize.Doubled) {
                tankSize.Name += "x2";
            }
            tankSize.Name += " - " + obj2;
            tankSize.Params = 0;
            if (!radioButton.isChecked()) {
                tankSize.Params |= 1;
            } else {
                tankSize.Params |= 2;
            }
            if (!radioButton2.isChecked()) {
                tankSize.Params |= 4;
            } else {
                tankSize.Params |= 8;
            }
            int findtank = this.gastanksettings.findtank(tankSize.Name);
            if (findtank > -1) {
                this.gastanksettings.deletetank(findtank);
            }
            if (tankSize.FillPress < 500.0d && (tankSize.Params & 4) > 0) {
                String str = tankSize.Name + " PSI ?";
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle(getString(C0347R.string.Confirm));
                builder.setIcon(android.R.drawable.ic_dialog_alert);
                builder.setMessage(str);
                builder.setPositiveButton(C0347R.string.Yes, new DialogInterface.OnClickListener() { // from class: com.hhssoftware.multideco.settank.2
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                        settank.this.gastanksettings.appendtank(tankSize);
                        settank.this.reload_listview();
                        settank.this.gastanksettings.update_gastank_setting();
                        settank settankVar = settank.this;
                        settankVar.setResult(-1, settankVar.getIntent());
                    }
                });
                builder.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() { // from class: com.hhssoftware.multideco.settank.3
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                        settank settankVar = settank.this;
                        settankVar.setResult(-1, settankVar.getIntent());
                    }
                });
                builder.create().show();
                return;
            }
            this.gastanksettings.appendtank(tankSize);
            reload_listview();
            this.gastanksettings.update_gastank_setting();
            setResult(-1, getIntent());
            return;
        }
        if (id != C0347R.id.imageBtnDeleteTank || (checkedItemPosition = ((ListView) findViewById(C0347R.id.listViewTanks)).getCheckedItemPosition()) == -1) {
            return;
        }
        this.gastanksettings.deletetank(checkedItemPosition);
        reload_listview();
        this.gastanksettings.update_gastank_setting();
        setResult(-1, getIntent());
    }
}
