package com.hhssoftware.multideco;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.os.MessageQueue;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;

/* loaded from: classes.dex */
public class mixer_trimix extends Activity implements CompoundButton.OnCheckedChangeListener, MessageQueue.IdleHandler {
    private Boolean isIniting;
    private Settings settings;
    private final String PREFS_MIXER = "mixer_trimix";
    private final int PER_RADBTN = 0;
    private final int HE_1ST = 1;
    private final int O2_1ST = 2;
    private TextWatcher textWatcher = new TextWatcher() { // from class: com.hhssoftware.multideco.mixer_trimix.1
        @Override // android.text.TextWatcher
        public void afterTextChanged(Editable editable) {
        }

        @Override // android.text.TextWatcher
        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        @Override // android.text.TextWatcher
        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            if (mixer_trimix.this.isIniting.booleanValue()) {
                return;
            }
            mixer_trimix.this.performCalc(0);
        }
    };

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        setTheme(new Theme_setting(this).theme_id);
        super.onCreate(bundle);
        setContentView(C0347R.layout.mixer_trimix);
        this.settings = new Settings(this);
        this.isIniting = true;
        if (Build.VERSION.SDK_INT < 35) {
            findViewById(C0347R.id.mixer_trimix_xml).setPadding(0, 0, 0, 0);
        }
        if (this.settings.mix_banked32) {
            ((TextView) findViewById(C0347R.id.Texttrimixaddair)).setText(getString(C0347R.string.add32));
        }
        ((EditText) findViewById(C0347R.id.trimixpressold)).addTextChangedListener(this.textWatcher);
        ((EditText) findViewById(C0347R.id.trimixpressnew)).addTextChangedListener(this.textWatcher);
        ((EditText) findViewById(C0347R.id.trimixo2old)).addTextChangedListener(this.textWatcher);
        ((EditText) findViewById(C0347R.id.trimixo2new)).addTextChangedListener(this.textWatcher);
        ((EditText) findViewById(C0347R.id.trimixheold)).addTextChangedListener(this.textWatcher);
        ((EditText) findViewById(C0347R.id.trimixhenew)).addTextChangedListener(this.textWatcher);
        ((CompoundButton) findViewById(C0347R.id.trimixAddfirstHe)).setOnCheckedChangeListener(this);
        ((CompoundButton) findViewById(C0347R.id.trimixAddfirstO2)).setOnCheckedChangeListener(this);
        SharedPreferences sharedPreferences = getSharedPreferences("mixer_trimix", 0);
        loadPrefs(sharedPreferences);
        try {
            performCalc(0);
        } catch (Exception unused) {
            SharedPreferences.Editor edit = sharedPreferences.edit();
            edit.clear();
            edit.commit();
            loadPrefs(sharedPreferences);
        }
        Looper.myQueue().addIdleHandler(this);
    }

    private void loadPrefs(SharedPreferences sharedPreferences) {
        ((EditText) findViewById(C0347R.id.trimixpressold)).setText(sharedPreferences.getString("trimixpressold", ""));
        ((EditText) findViewById(C0347R.id.trimixpressnew)).setText(sharedPreferences.getString("trimixpressnew", ""));
        ((EditText) findViewById(C0347R.id.trimixo2old)).setText(sharedPreferences.getString("trimixo2old", ""));
        ((EditText) findViewById(C0347R.id.trimixo2new)).setText(sharedPreferences.getString("trimixo2new", ""));
        ((EditText) findViewById(C0347R.id.trimixheold)).setText(sharedPreferences.getString("trimixheold", ""));
        ((EditText) findViewById(C0347R.id.trimixhenew)).setText(sharedPreferences.getString("trimixhenew", ""));
        if (sharedPreferences.getBoolean("trimixaddfirstHe", true)) {
            ((CompoundButton) findViewById(C0347R.id.trimixAddfirstHe)).setChecked(true);
            return;
        }
        ((CompoundButton) findViewById(C0347R.id.trimixAddfirstO2)).setChecked(true);
        ((TextView) findViewById(C0347R.id.Texttrimixadd1st)).setText(C0347R.string.addO2);
        ((TextView) findViewById(C0347R.id.Texttrimixadd2nd)).setText(C0347R.string.addHe);
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        SharedPreferences.Editor edit = getSharedPreferences("mixer_trimix", 0).edit();
        edit.putString("trimixpressold", ((EditText) findViewById(C0347R.id.trimixpressold)).getText().toString());
        edit.putString("trimixpressnew", ((EditText) findViewById(C0347R.id.trimixpressnew)).getText().toString());
        edit.putString("trimixo2old", ((EditText) findViewById(C0347R.id.trimixo2old)).getText().toString());
        edit.putString("trimixo2new", ((EditText) findViewById(C0347R.id.trimixo2new)).getText().toString());
        edit.putString("trimixheold", ((EditText) findViewById(C0347R.id.trimixheold)).getText().toString());
        edit.putString("trimixhenew", ((EditText) findViewById(C0347R.id.trimixhenew)).getText().toString());
        edit.putBoolean("trimixaddfirstHe", ((CompoundButton) findViewById(C0347R.id.trimixAddfirstHe)).isChecked());
        edit.commit();
        super.onDestroy();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void performCalc(int i) {
        String[] strArr = new String[14];
        ((EditText) findViewById(C0347R.id.trimixaddo2)).setText("");
        ((EditText) findViewById(C0347R.id.trimixaddhe)).setText("");
        ((EditText) findViewById(C0347R.id.trimixtesto2)).setText("");
        ((EditText) findViewById(C0347R.id.trimixaddair)).setText("");
        if (((EditText) findViewById(C0347R.id.trimixpressold)).getText().length() == 0 || ((EditText) findViewById(C0347R.id.trimixpressnew)).getText().length() == 0 || ((EditText) findViewById(C0347R.id.trimixo2old)).getText().length() == 0 || ((EditText) findViewById(C0347R.id.trimixo2new)).getText().length() == 0 || ((EditText) findViewById(C0347R.id.trimixheold)).getText().length() == 0 || ((EditText) findViewById(C0347R.id.trimixhenew)).getText().length() == 0 || Double.parseDouble(((EditText) findViewById(C0347R.id.trimixpressold)).getText().toString().replace(',', '.')) >= Double.parseDouble(((EditText) findViewById(C0347R.id.trimixpressnew)).getText().toString().replace(',', '.')) || Double.parseDouble(((EditText) findViewById(C0347R.id.trimixo2old)).getText().toString().replace(',', '.')) == 0.0d || Double.parseDouble(((EditText) findViewById(C0347R.id.trimixo2new)).getText().toString().replace(',', '.')) == 0.0d || Double.parseDouble(((EditText) findViewById(C0347R.id.trimixhenew)).getText().toString().replace(',', '.')) == 0.0d || Double.parseDouble(((EditText) findViewById(C0347R.id.trimixo2old)).getText().toString().replace(',', '.')) > 100.0d || Double.parseDouble(((EditText) findViewById(C0347R.id.trimixo2new)).getText().toString().replace(',', '.')) > 100.0d || Double.parseDouble(((EditText) findViewById(C0347R.id.trimixheold)).getText().toString().replace(',', '.')) > 100.0d || Double.parseDouble(((EditText) findViewById(C0347R.id.trimixhenew)).getText().toString().replace(',', '.')) > 100.0d) {
            return;
        }
        strArr[0] = "752";
        strArr[1] = this.settings.mix_units + "";
        strArr[2] = ((EditText) findViewById(C0347R.id.trimixpressold)).getText().toString();
        strArr[3] = ((EditText) findViewById(C0347R.id.trimixpressnew)).getText().toString();
        strArr[4] = ((EditText) findViewById(C0347R.id.trimixo2old)).getText().toString();
        strArr[6] = ((EditText) findViewById(C0347R.id.trimixo2new)).getText().toString();
        strArr[5] = ((EditText) findViewById(C0347R.id.trimixheold)).getText().toString();
        strArr[7] = ((EditText) findViewById(C0347R.id.trimixhenew)).getText().toString();
        strArr[8] = "";
        strArr[9] = "";
        strArr[10] = "";
        strArr[11] = "";
        strArr[12] = this.settings.mix_temp + "";
        if (i == 0) {
            strArr[13] = Boolean.toString(((CompoundButton) findViewById(C0347R.id.trimixAddfirstHe)).isChecked());
        } else {
            strArr[13] = Boolean.toString(i == 1);
        }
        tools_calc tools_calcVar = new tools_calc();
        tools_calcVar.banked32 = Boolean.valueOf(this.settings.mix_banked32);
        String[] performCalc = tools_calcVar.performCalc(strArr);
        ((EditText) findViewById(C0347R.id.trimixaddo2)).setText(performCalc[8]);
        ((EditText) findViewById(C0347R.id.trimixaddhe)).setText(performCalc[9]);
        ((EditText) findViewById(C0347R.id.trimixaddair)).setText(performCalc[10]);
        ((EditText) findViewById(C0347R.id.trimixtesto2)).setText(performCalc[11]);
    }

    @Override // android.os.MessageQueue.IdleHandler
    public boolean queueIdle() {
        this.isIniting = false;
        return false;
    }

    @Override // android.widget.CompoundButton.OnCheckedChangeListener
    public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
        if (this.isIniting.booleanValue() || !z) {
            return;
        }
        if (compoundButton.getId() == C0347R.id.trimixAddfirstHe) {
            ((TextView) findViewById(C0347R.id.Texttrimixadd1st)).setText(C0347R.string.addHe);
            ((TextView) findViewById(C0347R.id.Texttrimixadd2nd)).setText(C0347R.string.addO2);
            performCalc(1);
        } else if (compoundButton.getId() == C0347R.id.trimixAddfirstO2) {
            ((TextView) findViewById(C0347R.id.Texttrimixadd1st)).setText(C0347R.string.addO2);
            ((TextView) findViewById(C0347R.id.Texttrimixadd2nd)).setText(C0347R.string.addHe);
            performCalc(2);
        }
    }
}
