package com.hhssoftware.multideco;

import android.content.Context;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import kotlin.UByte;

/* loaded from: classes.dex */
public class Android_RSA {
    public static final int MODE_CLIENT = 1;
    public static final int MODE_SERVER = 2;
    static String PubKeyFile = "pubkey_150103.pem";

    /* renamed from: kp */
    static KeyPair f82kp;
    static PrivateKey privateKey;
    static PublicKey publicKey;
    private final Context context;
    private final char[] ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".toCharArray();
    private final int[] toInt = new int[128];

    public void makekeypair() {
    }

    public void readPrivateKeyFromFile() {
    }

    public void saveToFile(String str, BigInteger bigInteger, BigInteger bigInteger2) {
    }

    public void savekeypair() {
    }

    public Android_RSA(Context context) {
        this.context = context;
    }

    public void readPubKeyFromFile() {
        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(this.context.getResources().openRawResource(C0347R.raw.pubkey_150103)));
            String str = "";
            while (true) {
                String readLine = bufferedReader.readLine();
                if (readLine != null) {
                    if (!readLine.contains("-")) {
                        str = str + readLine;
                    }
                } else {
                    bufferedReader.close();
                    publicKey = KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(base64_decode(str)));
                    return;
                }
            }
        } catch (Exception e) {
            throw new RuntimeException("Spurious serialisation error", e);
        }
    }

    public byte[] rsaEncrypt(byte[] bArr) {
        readPubKeyFromFile();
        try {
            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            cipher.init(1, publicKey);
            return cipher.doFinal(bArr);
        } catch (InvalidKeyException e) {
            e.printStackTrace();
            return null;
        } catch (NoSuchAlgorithmException e2) {
            e2.printStackTrace();
            return null;
        } catch (BadPaddingException e3) {
            e3.printStackTrace();
            return null;
        } catch (IllegalBlockSizeException e4) {
            e4.printStackTrace();
            return null;
        } catch (NoSuchPaddingException e5) {
            e5.printStackTrace();
            return null;
        }
    }

    public byte[] rsaDecrypt(byte[] bArr) {
        readPubKeyFromFile();
        try {
            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            cipher.init(2, publicKey);
            return cipher.doFinal(bArr);
        } catch (InvalidKeyException e) {
            e.printStackTrace();
            return null;
        } catch (NoSuchAlgorithmException e2) {
            e2.printStackTrace();
            return null;
        } catch (BadPaddingException e3) {
            e3.printStackTrace();
            return null;
        } catch (IllegalBlockSizeException e4) {
            e4.printStackTrace();
            return null;
        } catch (NoSuchPaddingException e5) {
            e5.printStackTrace();
            return null;
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:22:0x006f, code lost:
    
        if (r1 != 2) goto L23;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public String base64_encode(byte[] bArr) {
        int i;
        byte b;
        int i2;
        byte b2;
        int i3 = 0;
        while (true) {
            char[] cArr = this.ALPHABET;
            if (i3 >= cArr.length) {
                break;
            }
            this.toInt[cArr[i3]] = i3;
            i3++;
        }
        int length = bArr.length;
        char[] cArr2 = new char[((length + 2) / 3) * 4];
        int i4 = 0;
        int i5 = 0;
        while (i4 < length) {
            int i6 = i4 + 1;
            byte b3 = bArr[i4];
            if (i6 < length) {
                i = i4 + 2;
                b = bArr[i6];
            } else {
                i = i6;
                b = 0;
            }
            if (i < length) {
                i2 = i + 1;
                b2 = bArr[i];
            } else {
                i2 = i;
                b2 = 0;
            }
            char[] cArr3 = this.ALPHABET;
            cArr2[i5] = cArr3[(b3 >> 2) & 63];
            cArr2[i5 + 1] = cArr3[((b3 << 4) | ((b & UByte.MAX_VALUE) >> 4)) & 63];
            int i7 = i5 + 3;
            cArr2[i5 + 2] = cArr3[((b << 2) | ((b2 & UByte.MAX_VALUE) >> 6)) & 63];
            i5 += 4;
            cArr2[i7] = cArr3[b2 & 63];
            i4 = i2;
        }
        int i8 = length % 3;
        if (i8 == 1) {
            i5--;
            cArr2[i5] = '=';
        }
        cArr2[i5 - 1] = '=';
        return new String(cArr2);
    }

    public byte[] base64_decode(String str) {
        int i = 0;
        while (true) {
            char[] cArr = this.ALPHABET;
            if (i >= cArr.length) {
                break;
            }
            this.toInt[cArr[i]] = i;
            i++;
        }
        String replaceAll = str.trim().replaceAll("[\n\r]", "");
        int length = ((replaceAll.length() * 3) / 4) - (replaceAll.endsWith("==") ? 2 : replaceAll.endsWith("=") ? 1 : 0);
        byte[] bArr = new byte[length];
        int i2 = 0;
        for (int i3 = 0; i3 < replaceAll.length(); i3 += 4) {
            int i4 = this.toInt[replaceAll.charAt(i3)];
            int i5 = this.toInt[replaceAll.charAt(i3 + 1)];
            int i6 = i2 + 1;
            bArr[i2] = (byte) (((i4 << 2) | (i5 >> 4)) & 255);
            if (i6 >= length) {
                break;
            }
            int i7 = this.toInt[replaceAll.charAt(i3 + 2)];
            int i8 = i2 + 2;
            bArr[i6] = (byte) (((i5 << 4) | (i7 >> 2)) & 255);
            if (i8 >= length) {
                break;
            }
            i2 += 3;
            bArr[i8] = (byte) (((i7 << 6) | this.toInt[replaceAll.charAt(i3 + 3)]) & 255);
        }
        return bArr;
    }
}
