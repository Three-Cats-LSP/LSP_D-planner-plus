package com.hhssoftware.multideco;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

/* loaded from: classes.dex */
public class multideco_about extends Activity implements View.OnClickListener {
    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        setTheme(new Theme_setting(this).theme_id);
        super.onCreate(bundle);
        setContentView(C0347R.layout.multideco_about);
        if (Build.VERSION.SDK_INT < 35) {
            findViewById(C0347R.id.multideco_about_xml).setPadding(0, 0, 0, 0);
        }
        findViewById(C0347R.id.ButtonAboutIcon).setOnClickListener(this);
        findViewById(C0347R.id.ButtonAboutEmail).setOnClickListener(this);
        try {
            ((TextView) findViewById(C0347R.id.TextViewAboutProgram_version)).setText("MultiDeco " + getPackageManager().getPackageInfo(getPackageName(), 128).versionName);
        } catch (PackageManager.NameNotFoundException unused) {
        }
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        int id = view.getId();
        if (id == C0347R.id.ButtonAboutIcon) {
            Intent intent = new Intent();
            intent.setAction("android.intent.action.VIEW");
            intent.addCategory("android.intent.category.BROWSABLE");
            intent.setData(Uri.parse("https://www.multideco.com"));
            startActivity(intent);
            return;
        }
        if (id == C0347R.id.ButtonAboutEmail) {
            Intent intent2 = new Intent("android.intent.action.SEND");
            intent2.putExtra("android.intent.extra.TEXT", "<< enter some text >>");
            intent2.putExtra("android.intent.extra.SUBJECT", "MultiDeco Android question");
            intent2.putExtra("android.intent.extra.EMAIL", new String[]{"support@multideco.com"});
            intent2.setType("message/rfc822");
            startActivity(Intent.createChooser(intent2, getString(C0347R.string.SelectEmail)));
        }
    }
}
