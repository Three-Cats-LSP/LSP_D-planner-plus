package com.hhssoftware.multideco;

import android.content.Context;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

/* loaded from: classes.dex */
public class Theme_setting implements Serializable {
    private static final String Theme_setting_stream = "theme_setting.data";
    private static final long serialVersionUID = 1;
    private final Context context;
    public int theme_id = android.R.style.Theme.DeviceDefault.Light;

    public Theme_setting(Context context) {
        this.context = context;
        load_theme_setting();
    }

    private void load_theme_setting() {
        try {
            FileInputStream openFileInput = this.context.openFileInput(Theme_setting_stream);
            ObjectInputStream objectInputStream = new ObjectInputStream(openFileInput);
            if (serialVersionUID != objectInputStream.readLong()) {
                objectInputStream.close();
                this.context.deleteFile(Theme_setting_stream);
            } else {
                this.theme_id = objectInputStream.readInt();
                objectInputStream.close();
                openFileInput.close();
            }
        } catch (FileNotFoundException unused) {
        } catch (Exception unused2) {
            this.context.deleteFile(Theme_setting_stream);
        }
    }

    public void set_theme(int i) {
        this.theme_id = i;
        save_theme_setting();
    }

    private void save_theme_setting() {
        try {
            FileOutputStream openFileOutput = this.context.openFileOutput(Theme_setting_stream, 0);
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(openFileOutput);
            objectOutputStream.writeLong(serialVersionUID);
            objectOutputStream.writeInt(this.theme_id);
            objectOutputStream.close();
            openFileOutput.close();
        } catch (FileNotFoundException | IOException unused) {
        }
    }
}
