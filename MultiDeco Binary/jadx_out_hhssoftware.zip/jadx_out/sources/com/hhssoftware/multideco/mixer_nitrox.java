package com.hhssoftware.multideco;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.os.MessageQueue;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.TextView;

/* loaded from: classes.dex */
public class mixer_nitrox extends Activity implements MessageQueue.IdleHandler {
    private Boolean isIniting;
    private Settings settings;
    private final String PREFS_MIXER = "mixer_nitrox";
    private TextWatcher textWatcher = new TextWatcher() { // from class: com.hhssoftware.multideco.mixer_nitrox.1
        @Override // android.text.TextWatcher
        public void afterTextChanged(Editable editable) {
        }

        @Override // android.text.TextWatcher
        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        @Override // android.text.TextWatcher
        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            if (mixer_nitrox.this.isIniting.booleanValue()) {
                return;
            }
            mixer_nitrox.this.performCalc();
        }
    };

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        setTheme(new Theme_setting(this).theme_id);
        super.onCreate(bundle);
        setContentView(C0347R.layout.mixer_nitrox);
        this.settings = new Settings(this);
        this.isIniting = false;
        if (Build.VERSION.SDK_INT < 35) {
            findViewById(C0347R.id.mixer_nitrox_xml).setPadding(0, 0, 0, 0);
        }
        if (this.settings.mix_banked32) {
            ((TextView) findViewById(C0347R.id.Textnitroxaddair)).setText(getString(C0347R.string.add32));
        }
        ((EditText) findViewById(C0347R.id.nitroxpressold)).addTextChangedListener(this.textWatcher);
        ((EditText) findViewById(C0347R.id.nitroxpressnew)).addTextChangedListener(this.textWatcher);
        ((EditText) findViewById(C0347R.id.nitroxo2old)).addTextChangedListener(this.textWatcher);
        ((EditText) findViewById(C0347R.id.nitroxo2new)).addTextChangedListener(this.textWatcher);
        SharedPreferences sharedPreferences = getSharedPreferences("mixer_nitrox", 0);
        loadPrefs(sharedPreferences);
        try {
            performCalc();
        } catch (Exception unused) {
            SharedPreferences.Editor edit = sharedPreferences.edit();
            edit.clear();
            edit.commit();
            loadPrefs(sharedPreferences);
        }
        Looper.myQueue().addIdleHandler(this);
    }

    private void loadPrefs(SharedPreferences sharedPreferences) {
        ((EditText) findViewById(C0347R.id.nitroxpressold)).setText(sharedPreferences.getString("nitroxpressold", ""));
        ((EditText) findViewById(C0347R.id.nitroxpressnew)).setText(sharedPreferences.getString("nitroxpressnew", ""));
        ((EditText) findViewById(C0347R.id.nitroxo2old)).setText(sharedPreferences.getString("nitroxo2old", ""));
        ((EditText) findViewById(C0347R.id.nitroxo2new)).setText(sharedPreferences.getString("nitroxo2new", ""));
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        SharedPreferences.Editor edit = getSharedPreferences("mixer_nitrox", 0).edit();
        edit.putString("nitroxpressold", ((EditText) findViewById(C0347R.id.nitroxpressold)).getText().toString());
        edit.putString("nitroxpressnew", ((EditText) findViewById(C0347R.id.nitroxpressnew)).getText().toString());
        edit.putString("nitroxo2old", ((EditText) findViewById(C0347R.id.nitroxo2old)).getText().toString());
        edit.putString("nitroxo2new", ((EditText) findViewById(C0347R.id.nitroxo2new)).getText().toString());
        edit.commit();
        super.onDestroy();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void performCalc() {
        String[] strArr = new String[9];
        ((EditText) findViewById(C0347R.id.nitroxaddo2)).setText("");
        ((EditText) findViewById(C0347R.id.nitroxaddair)).setText("");
        if (((EditText) findViewById(C0347R.id.nitroxpressold)).getText().length() == 0 || ((EditText) findViewById(C0347R.id.nitroxpressnew)).getText().length() == 0 || ((EditText) findViewById(C0347R.id.nitroxo2old)).getText().length() == 0 || ((EditText) findViewById(C0347R.id.nitroxo2new)).getText().length() == 0 || Double.parseDouble(((EditText) findViewById(C0347R.id.nitroxpressold)).getText().toString().replace(',', '.')) >= Double.parseDouble(((EditText) findViewById(C0347R.id.nitroxpressnew)).getText().toString().replace(',', '.')) || Double.parseDouble(((EditText) findViewById(C0347R.id.nitroxo2old)).getText().toString().replace(',', '.')) == 0.0d || Double.parseDouble(((EditText) findViewById(C0347R.id.nitroxo2new)).getText().toString().replace(',', '.')) == 0.0d || Double.parseDouble(((EditText) findViewById(C0347R.id.nitroxo2old)).getText().toString().replace(',', '.')) > 100.0d || Double.parseDouble(((EditText) findViewById(C0347R.id.nitroxo2new)).getText().toString().replace(',', '.')) > 100.0d) {
            return;
        }
        strArr[0] = "36";
        strArr[1] = this.settings.mix_units + "";
        strArr[2] = ((EditText) findViewById(C0347R.id.nitroxpressold)).getText().toString();
        strArr[3] = ((EditText) findViewById(C0347R.id.nitroxpressnew)).getText().toString();
        strArr[4] = ((EditText) findViewById(C0347R.id.nitroxo2old)).getText().toString();
        strArr[5] = ((EditText) findViewById(C0347R.id.nitroxo2new)).getText().toString();
        strArr[6] = "";
        strArr[7] = "";
        strArr[8] = this.settings.mix_temp + "";
        tools_calc tools_calcVar = new tools_calc();
        tools_calcVar.banked32 = Boolean.valueOf(this.settings.mix_banked32);
        String[] performCalc = tools_calcVar.performCalc(strArr);
        ((EditText) findViewById(C0347R.id.nitroxaddo2)).setText(performCalc[6]);
        ((EditText) findViewById(C0347R.id.nitroxaddair)).setText(performCalc[7]);
        Looper.myQueue().addIdleHandler(this);
    }

    @Override // android.os.MessageQueue.IdleHandler
    public boolean queueIdle() {
        this.isIniting = false;
        return false;
    }
}
