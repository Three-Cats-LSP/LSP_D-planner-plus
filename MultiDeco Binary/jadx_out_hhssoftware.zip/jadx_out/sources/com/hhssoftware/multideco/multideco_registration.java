package com.hhssoftware.multideco;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import java.util.Locale;

/* loaded from: classes.dex */
public class multideco_registration extends Activity implements View.OnClickListener {
    private String link_newkey;
    private String link_reg;

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        String str;
        Spanned fromHtml;
        setTheme(new Theme_setting(this).theme_id);
        super.onCreate(bundle);
        setContentView(C0347R.layout.multideco_registration);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        Boolean valueOf = Boolean.valueOf(displayMetrics.widthPixels > displayMetrics.heightPixels);
        try {
            str = getPackageManager().getPackageInfo(getPackageName(), 128).versionName;
        } catch (PackageManager.NameNotFoundException unused) {
            str = "0.00";
        }
        String stringExtra = getIntent().getStringExtra("ic");
        if (stringExtra != null) {
            ((EditText) findViewById(C0347R.id.reginstallcode)).setText(stringExtra);
        }
        this.link_reg = getString(C0347R.string.SReg) + "version=" + str + "&multiand=1&installcode=" + ((EditText) findViewById(C0347R.id.reginstallcode)).getText().toString();
        if (valueOf.booleanValue()) {
            fromHtml = Html.fromHtml(getString(C0347R.string.regdescript) + " <a href=\"" + this.link_reg + "\">www.multideco.com</a> ");
        } else {
            fromHtml = Html.fromHtml(getString(C0347R.string.regdescript) + "<br><a href=\"" + this.link_reg + "\">www.multideco.com</a> ");
        }
        this.link_newkey = getString(C0347R.string.SNewKey) + "?ic=" + ((EditText) findViewById(C0347R.id.reginstallcode)).getText().toString() + "&set_page_lang=" + Locale.getDefault().getLanguage();
        TextView textView = (TextView) findViewById(C0347R.id.TextRegDescript);
        textView.setText(fromHtml);
        textView.setMovementMethod(LinkMovementMethod.getInstance());
        findViewById(C0347R.id.ButtonSave).setOnClickListener(this);
        findViewById(C0347R.id.ButtonCancel).setOnClickListener(this);
        findViewById(C0347R.id.ButtonRegister).setOnClickListener(this);
        findViewById(C0347R.id.ButtonNewKey).setOnClickListener(this);
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyUp(int i, KeyEvent keyEvent) {
        View currentFocus = getCurrentFocus();
        if (currentFocus == null) {
            return false;
        }
        Boolean valueOf = Boolean.valueOf((i >= 29 && i <= 54) || (i >= 7 && i <= 16));
        int id = currentFocus.getId();
        if (id == C0347R.id.regkey1 && ((EditText) currentFocus).getEditableText().length() == 4 && valueOf.booleanValue()) {
            findViewById(C0347R.id.regkey2).requestFocus();
        }
        if (id == C0347R.id.regkey2 && ((EditText) currentFocus).getEditableText().length() == 4 && valueOf.booleanValue()) {
            findViewById(C0347R.id.regkey3).requestFocus();
        }
        if (id == C0347R.id.regkey3 && ((EditText) currentFocus).getEditableText().length() == 4 && valueOf.booleanValue()) {
            findViewById(C0347R.id.ButtonSave).requestFocus();
        }
        return false;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        int id = view.getId();
        if (id == C0347R.id.ButtonSave) {
            String str = ((((EditText) findViewById(C0347R.id.regkey1)).getText().toString().trim() + '-') + ((EditText) findViewById(C0347R.id.regkey2)).getText().toString().trim() + '-') + ((EditText) findViewById(C0347R.id.regkey3)).getText().toString().trim();
            setResult(0);
            if (str.length() == 14) {
                if (new Identity(this).saveKeyString(str).booleanValue()) {
                    setResult(-1);
                }
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle(getString(C0347R.string.Info));
                builder.setIcon(android.R.drawable.ic_dialog_info);
                builder.setMessage(getString(C0347R.string.RegDetailsSavedRestart));
                builder.setNeutralButton(android.R.string.ok, new DialogInterface.OnClickListener() { // from class: com.hhssoftware.multideco.multideco_registration.1
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                        multideco_registration.this.finish();
                    }
                });
                builder.create().show();
                return;
            }
            return;
        }
        if (id == C0347R.id.ButtonCancel) {
            setResult(0);
            finish();
        } else if (id == C0347R.id.ButtonRegister) {
            startActivity(new Intent("android.intent.action.VIEW", Uri.parse(this.link_reg)));
        } else if (id == C0347R.id.ButtonNewKey) {
            startActivity(new Intent("android.intent.action.VIEW", Uri.parse(this.link_newkey)));
        }
    }
}
