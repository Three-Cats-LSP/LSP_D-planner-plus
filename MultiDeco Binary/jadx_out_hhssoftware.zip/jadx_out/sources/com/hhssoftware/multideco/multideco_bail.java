package com.hhssoftware.multideco;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Looper;
import android.os.MessageQueue;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.ToggleButton;
import com.hhssoftware.multideco.Gastank_setting;
import java.util.ArrayList;

/* loaded from: classes.dex */
public class multideco_bail extends Activity implements AdapterView.OnItemSelectedListener, View.OnClickListener, MessageQueue.IdleHandler {
    private SharedPreferences.Editor prefeditor;
    private SharedPreferences prefsettings;
    private Settings settings;
    private final int CHECKBOX_ID = 3535300;
    private final int TEXTVIEW_ID = 3535400;
    private int configed = 0;
    private boolean isIniting = true;
    private final int[] textMixID = new int[4];
    private final int[] tableRowID = new int[4];
    private final int[] spinnerTank = new int[4];
    private final int[] editFromP = new int[4];
    private final int[] editToP = new int[4];
    private final String PREFS_SELECTS = "bailmaxtimeselects";
    private final String PrefMaxTimePlan = "MaxTimePlan";

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public void onNothingSelected(AdapterView<?> adapterView) {
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        setTheme(new Theme_setting(this).theme_id);
        super.onCreate(bundle);
        setContentView(C0347R.layout.multideco_bail);
        this.textMixID[0] = C0347R.id.MixBailOCmix0;
        this.textMixID[1] = C0347R.id.MixBailOCmix1;
        this.textMixID[2] = C0347R.id.MixBailOCmix2;
        this.textMixID[3] = C0347R.id.MixBailOCmix3;
        this.tableRowID[0] = C0347R.id.TableBailOCmix0;
        this.tableRowID[1] = C0347R.id.TableBailOCmix1;
        this.tableRowID[2] = C0347R.id.TableBailOCmix2;
        this.tableRowID[3] = C0347R.id.TableBailOCmix3;
        this.spinnerTank[0] = C0347R.id.TanksBailOCmix0;
        this.spinnerTank[1] = C0347R.id.TanksBailOCmix1;
        this.spinnerTank[2] = C0347R.id.TanksBailOCmix2;
        this.spinnerTank[3] = C0347R.id.TanksBailOCmix3;
        this.editFromP[0] = C0347R.id.FromPBailOCmix0;
        this.editFromP[1] = C0347R.id.FromPBailOCmix1;
        this.editFromP[2] = C0347R.id.FromPBailOCmix2;
        this.editFromP[3] = C0347R.id.FromPBailOCmix3;
        this.editToP[0] = C0347R.id.ToPBailOCmix0;
        this.editToP[1] = C0347R.id.ToPBailOCmix1;
        this.editToP[2] = C0347R.id.ToPBailOCmix2;
        this.editToP[3] = C0347R.id.ToPBailOCmix3;
        this.settings = new Settings(this);
        initForm();
        getWindow().setSoftInputMode(2);
        Looper.myQueue().addIdleHandler(this);
    }

    @Override // android.os.MessageQueue.IdleHandler
    public boolean queueIdle() {
        this.isIniting = false;
        return false;
    }

    private void initForm() {
        String str;
        String format;
        this.isIniting = true;
        Spinner spinner = (Spinner) findViewById(C0347R.id.bailModel);
        int i = android.R.layout.simple_spinner_item;
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_bail.1
            @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
            public View getDropDownView(int i2, View view, ViewGroup viewGroup) {
                View dropDownView = super.getDropDownView(i2, view, viewGroup);
                ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                return dropDownView;
            }
        };
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        for (int i2 = 1; i2 <= 6; i2++) {
            arrayAdapter.add(this.settings.modelString(i2));
        }
        spinner.setAdapter((SpinnerAdapter) arrayAdapter);
        spinner.setSelection(this.settings.bailModel - 1);
        spinner.setOnItemSelectedListener(this);
        Spinner spinner2 = (Spinner) findViewById(C0347R.id.bailConserve);
        ArrayAdapter<String> arrayAdapter2 = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_bail.2
            @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
            public View getDropDownView(int i3, View view, ViewGroup viewGroup) {
                View dropDownView = super.getDropDownView(i3, view, viewGroup);
                ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                return dropDownView;
            }
        };
        arrayAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        arrayAdapter2.add("0");
        int i3 = 1;
        while (true) {
            if (i3 > 5) {
                break;
            }
            arrayAdapter2.add("+" + i3);
            i3++;
        }
        spinner2.setAdapter((SpinnerAdapter) arrayAdapter2);
        spinner2.setSelection(this.settings.bailConserve);
        spinner2.setOnItemSelectedListener(this);
        Spinner spinner3 = (Spinner) findViewById(C0347R.id.bailConserveGFLo);
        ArrayAdapter<String> arrayAdapter3 = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_bail.3
            @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
            public View getDropDownView(int i4, View view, ViewGroup viewGroup) {
                View dropDownView = super.getDropDownView(i4, view, viewGroup);
                ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                return dropDownView;
            }
        };
        arrayAdapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        for (int i4 = 100; i4 >= 10; i4 -= 5) {
            arrayAdapter3.add("" + i4);
        }
        spinner3.setAdapter((SpinnerAdapter) arrayAdapter3);
        spinner3.setSelection((100 - this.settings.bailConserveGFLo) / 5);
        spinner3.setOnItemSelectedListener(this);
        Spinner spinner4 = (Spinner) findViewById(C0347R.id.bailConserveGFHi);
        ArrayAdapter<String> arrayAdapter4 = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_bail.4
            @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
            public View getDropDownView(int i5, View view, ViewGroup viewGroup) {
                View dropDownView = super.getDropDownView(i5, view, viewGroup);
                ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                return dropDownView;
            }
        };
        arrayAdapter4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        for (int i5 = 100; i5 >= 50; i5 -= 5) {
            arrayAdapter4.add("" + i5);
        }
        spinner4.setAdapter((SpinnerAdapter) arrayAdapter4);
        spinner4.setSelection((100 - this.settings.bailConserveGFHi) / 5);
        spinner4.setOnItemSelectedListener(this);
        Spinner spinner5 = (Spinner) findViewById(C0347R.id.bailConserveGFS);
        ArrayAdapter<String> arrayAdapter5 = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_bail.5
            @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
            public View getDropDownView(int i6, View view, ViewGroup viewGroup) {
                View dropDownView = super.getDropDownView(i6, view, viewGroup);
                ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                return dropDownView;
            }
        };
        arrayAdapter5.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        for (int i6 = 100; i6 >= 70; i6 -= 5) {
            arrayAdapter5.add("" + i6);
        }
        spinner5.setAdapter((SpinnerAdapter) arrayAdapter5);
        spinner5.setSelection((100 - this.settings.bailConserveGFS) / 5);
        spinner5.setOnItemSelectedListener(this);
        conserveViews(this.settings.bailModel);
        Spinner spinner6 = (Spinner) findViewById(C0347R.id.bailBottomRMV);
        ArrayAdapter<String> arrayAdapter6 = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_bail.6
            @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
            public View getDropDownView(int i7, View view, ViewGroup viewGroup) {
                View dropDownView = super.getDropDownView(i7, view, viewGroup);
                ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                return dropDownView;
            }
        };
        arrayAdapter6.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        for (int i7 = 0; i7 <= 55; i7++) {
            float rmvValue = Settings.rmvValue(i7, this.settings.RMVs == 1);
            if (this.settings.RMVs == 1) {
                format = "" + ((int) rmvValue) + "ltr";
            } else {
                format = String.format("%.2f", Float.valueOf(rmvValue));
            }
            arrayAdapter6.add(format);
        }
        spinner6.setAdapter((SpinnerAdapter) arrayAdapter6);
        spinner6.setSelection(this.settings.bailRMV);
        spinner6.setOnItemSelectedListener(this);
        ((CompoundButton) findViewById(C0347R.id.BailToggleCaveBail)).setChecked(this.settings.bailCaveBail);
        findViewById(C0347R.id.BailToggleCaveBail).setOnClickListener(this);
        Spinner spinner7 = (Spinner) findViewById(C0347R.id.BailCaveBail);
        ArrayAdapter<String> arrayAdapter7 = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_bail.7
            @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
            public View getDropDownView(int i8, View view, ViewGroup viewGroup) {
                View dropDownView = super.getDropDownView(i8, view, viewGroup);
                ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                return dropDownView;
            }
        };
        arrayAdapter7.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        for (int i8 = 1; i8 <= 9; i8++) {
            arrayAdapter7.add((i8 * 10) + " %");
        }
        spinner7.setAdapter((SpinnerAdapter) arrayAdapter7);
        spinner7.setSelection(this.settings.bailCavePortion - 1);
        spinner7.setOnItemSelectedListener(this);
        ((CompoundButton) findViewById(C0347R.id.BailToggleExtraMins)).setChecked(this.settings.bailExtraMin);
        findViewById(C0347R.id.BailToggleExtraMins).setOnClickListener(this);
        Spinner spinner8 = (Spinner) findViewById(C0347R.id.BailExtraMins);
        ArrayAdapter<String> arrayAdapter8 = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_bail.8
            @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
            public View getDropDownView(int i9, View view, ViewGroup viewGroup) {
                View dropDownView = super.getDropDownView(i9, view, viewGroup);
                ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                return dropDownView;
            }
        };
        arrayAdapter8.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        for (int i9 = 1; i9 <= 5; i9++) {
            arrayAdapter8.add(i9 + "");
        }
        spinner8.setAdapter((SpinnerAdapter) arrayAdapter8);
        spinner8.setSelection(this.settings.bailExtraMinTime - 1);
        spinner8.setOnItemSelectedListener(this);
        Boolean.valueOf(false);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int i10 = !Boolean.valueOf(displayMetrics.widthPixels > displayMetrics.heightPixels).booleanValue() ? 3 : 5;
        TableLayout tableLayout = (TableLayout) findViewById(C0347R.id.TableBailOCmix);
        tableLayout.removeAllViews();
        Intent intent = getIntent();
        for (int i11 = 0; i11 < 4; i11++) {
            ((TextView) findViewById(this.textMixID[i11])).setTag(3535299);
            ((Spinner) findViewById(this.spinnerTank[i11])).setOnItemSelectedListener(this);
        }
        setTanks(false);
        if (intent.hasExtra("OCMixes") && intent.hasExtra("OCMixCheck")) {
            String[] stringArrayExtra = intent.getStringArrayExtra("OCMixes");
            int intExtra = intent.getIntExtra("OCMixCheck", 0);
            TableRow tableRow = null;
            for (int i12 = 0; i12 < stringArrayExtra.length && (str = stringArrayExtra[i12]) != null && str.length() != 0; i12++) {
                if (i12 % i10 == 0) {
                    tableRow = new TableRow(this);
                    tableLayout.addView(tableRow);
                }
                CheckBox checkBox = new CheckBox(this);
                boolean z = ((1 << i12) & intExtra) > 0;
                checkBox.setChecked(z);
                checkBox.setId(3535300 + i12);
                checkBox.setOnClickListener(this);
                tableRow.addView(checkBox);
                TextView textView = new TextView(this);
                textView.setId(3535400 + i12);
                textView.setText(str);
                textView.setTextSize(2, 20.0f);
                tableRow.addView(textView);
                if (z) {
                    setGasMix(str, true, i12);
                }
            }
        }
        SharedPreferences sharedPreferences = getSharedPreferences("bailmaxtimeselects", 0);
        this.prefsettings = sharedPreferences;
        this.prefeditor = sharedPreferences.edit();
        CompoundButton compoundButton = (CompoundButton) findViewById(C0347R.id.BailMaxtimeplanOnOff);
        compoundButton.setChecked(this.prefsettings.getBoolean("MaxTimePlan", false));
        setEditTankEnabled(compoundButton.isChecked());
        findViewById(C0347R.id.BailMaxtimeplanOnOff).setOnClickListener(this);
        findViewById(C0347R.id.BailMaxtimeplanSetup).setOnClickListener(this);
        findViewById(C0347R.id.ButtonBailCalculate).setOnClickListener(this);
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
        if (this.isIniting) {
            return;
        }
        int id = adapterView.getId();
        if (id == C0347R.id.bailModel) {
            conserveViews(i + 1);
        } else if (id == C0347R.id.TanksBailOCmix0 || id == C0347R.id.TanksBailOCmix1 || id == C0347R.id.TanksBailOCmix2 || id == C0347R.id.TanksBailOCmix3) {
            int id2 = adapterView.getId();
            Gastank_setting gastank_setting = new Gastank_setting(this, 2);
            int i2 = 0;
            while (true) {
                if (i2 >= 8) {
                    break;
                }
                if (id2 == this.spinnerTank[i2]) {
                    ((EditText) findViewById(this.editFromP[i2])).setText(Double.toString(gastank_setting.gettank(i).FillPress).replaceFirst(".0$", ""));
                    ((EditText) findViewById(this.editToP[i2])).setText("");
                    break;
                }
                i2++;
            }
        }
        this.configed = 1;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        if (this.isIniting) {
            return;
        }
        int id = view.getId();
        if (id == C0347R.id.BailToggleExtraMins) {
            this.configed = 1;
            if (((ToggleButton) view).isChecked()) {
                ((ToggleButton) findViewById(C0347R.id.BailToggleCaveBail)).setChecked(false);
                return;
            }
            return;
        }
        if (id == C0347R.id.BailToggleCaveBail) {
            this.configed = 1;
            if (((ToggleButton) view).isChecked()) {
                ((ToggleButton) findViewById(C0347R.id.BailToggleExtraMins)).setChecked(false);
                return;
            }
            return;
        }
        if (id == C0347R.id.ButtonBailCalculate) {
            saveSettings();
            Intent intent = getIntent();
            intent.putExtra("ConfigReload", this.configed);
            int length = intent.getStringArrayExtra("OCMixes").length;
            int i = 0;
            for (int i2 = 0; i2 < length; i2++) {
                CheckBox checkBox = (CheckBox) findViewById(i2 + 3535300);
                if (checkBox != null && checkBox.isChecked()) {
                    i |= 1 << i2;
                }
            }
            if (i == 0) {
                String string = getString(C0347R.string.bailOCMixSelectHelp);
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle(getString(C0347R.string.Error));
                builder.setIcon(android.R.drawable.ic_dialog_alert);
                builder.setMessage(string);
                builder.setPositiveButton(C0347R.string.Cancel, new DialogInterface.OnClickListener() { // from class: com.hhssoftware.multideco.multideco_bail.9
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialogInterface, int i3) {
                        dialogInterface.cancel();
                    }
                });
                builder.create().show();
                return;
            }
            intent.putExtra("MixSelect", i);
            ArrayList<String> arrayList = new ArrayList<>();
            if (((CompoundButton) findViewById(C0347R.id.BailMaxtimeplanOnOff)).isChecked()) {
                Gastank_setting gastank_setting = new Gastank_setting(this, 2);
                for (int i3 = 0; i3 < 4; i3++) {
                    TextView textView = (TextView) findViewById(this.textMixID[i3]);
                    if (((Integer) textView.getTag()).intValue() != 3535299) {
                        int selectedItemPosition = ((Spinner) findViewById(this.spinnerTank[i3])).getSelectedItemPosition();
                        gastank_setting.bailMaxTimeMixChoice[i3] = (byte) selectedItemPosition;
                        String obj = ((EditText) findViewById(this.editFromP[i3])).getText().toString();
                        String obj2 = ((EditText) findViewById(this.editToP[i3])).getText().toString();
                        try {
                            int intValue = ((Integer) textView.getTag()).intValue() - 3535300;
                            gastank_setting.setpress(i3, selectedItemPosition, Double.parseDouble(obj.replace(",", ".")), Double.parseDouble(obj2.replace(",", ".")));
                            arrayList.add(intValue + ":" + i3);
                        } catch (NumberFormatException unused) {
                            gastank_setting.setpress(i3, selectedItemPosition, 0.0d, 0.0d);
                        }
                    }
                }
                gastank_setting.update_gastank_setting();
                if (arrayList.size() > 0) {
                    intent.putStringArrayListExtra("MixTankSelected", arrayList);
                }
                intent.putExtra("MaxTimePlan", true);
            }
            setResult(-1, intent);
            finish();
            return;
        }
        if (id == C0347R.id.BailMaxtimeplanOnOff) {
            boolean isChecked = ((CompoundButton) findViewById(C0347R.id.BailMaxtimeplanOnOff)).isChecked();
            setEditTankEnabled(isChecked);
            this.prefeditor.putBoolean("MaxTimePlan", isChecked);
            this.prefeditor.commit();
            return;
        }
        if (id >= 3535300 && id <= 3535309) {
            setGasMix(((TextView) findViewById(view.getId() + 100)).getText().toString(), ((CompoundButton) view).isChecked(), view.getId() - 3535300);
        } else if (id == C0347R.id.BailMaxtimeplanSetup) {
            Intent intent2 = new Intent(this, (Class<?>) settank.class);
            intent2.putExtra("BAIL", true);
            startActivityForResult(intent2, C0347R.id.settank_xml);
        }
    }

    private void setEditTankEnabled(boolean z) {
        for (int i = 0; i < 4; i++) {
            ((EditText) findViewById(this.editFromP[i])).setEnabled(z);
        }
        for (int i2 = 0; i2 < 4; i2++) {
            ((EditText) findViewById(this.editToP[i2])).setEnabled(z);
        }
    }

    private void setGasMix(String str, boolean z, int i) {
        int i2 = 0;
        while (true) {
            if (i2 >= 4) {
                i2 = -1;
                break;
            }
            TextView textView = (TextView) findViewById(this.textMixID[i2]);
            String obj = textView.getText().toString();
            if (str.equals(obj) && !z) {
                textView.setText("");
                textView.setTag(3535299);
                ((EditText) findViewById(this.editFromP[i2])).setText("");
                ((EditText) findViewById(this.editToP[i2])).setText("");
                break;
            }
            if (obj.isEmpty() && z) {
                Gastank_setting gastank_setting = new Gastank_setting(this, 2);
                int selectedItemPosition = ((Spinner) findViewById(this.spinnerTank[i2])).getSelectedItemPosition();
                if (selectedItemPosition < 0) {
                    selectedItemPosition = 0;
                }
                Gastank_setting.TankSize tankSize = gastank_setting.gettank(selectedItemPosition);
                textView.setText(str);
                textView.setTag(Integer.valueOf(i + 3535300));
                EditText editText = (EditText) findViewById(this.editFromP[i2]);
                if (editText.getText().toString().isEmpty()) {
                    if (tankSize.FillPress > 0.0d) {
                        editText.setText(Double.toString(tankSize.FillPress).replaceFirst(".0$", ""));
                    }
                    Gastank_setting.TankPress tankPress = gastank_setting.getpress(i2);
                    if (tankPress.TankIdx == selectedItemPosition && tankPress.FromP > 0.0d) {
                        editText.setText(Double.toString(tankPress.FromP).replaceFirst(".0$", ""));
                        EditText editText2 = (EditText) findViewById(this.editToP[i2]);
                        if (editText2.getText().toString().isEmpty()) {
                            editText2.setText(Double.toString(tankPress.ToP).replaceFirst(".0$", ""));
                        }
                    }
                }
            } else {
                i2++;
            }
        }
        if (i2 > -1) {
            if (z) {
                ((TableRow) findViewById(this.tableRowID[i2])).setVisibility(0);
            } else {
                ((TableRow) findViewById(this.tableRowID[i2])).setVisibility(8);
            }
        }
    }

    private void setTanks(boolean z) {
        ArrayAdapter<String> arrayAdapter;
        Gastank_setting gastank_setting = new Gastank_setting(this, 2);
        if (!z) {
            arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item) { // from class: com.hhssoftware.multideco.multideco_bail.10
                @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
                public View getDropDownView(int i, View view, ViewGroup viewGroup) {
                    View dropDownView = super.getDropDownView(i, view, viewGroup);
                    ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                    return dropDownView;
                }
            };
            arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        } else {
            arrayAdapter = (ArrayAdapter) ((Spinner) findViewById(this.spinnerTank[0])).getAdapter();
            arrayAdapter.clear();
        }
        int valid_gastanks = gastank_setting.valid_gastanks();
        for (int i = 0; i < valid_gastanks; i++) {
            arrayAdapter.add(gastank_setting.gettank(i).Name);
        }
        for (int i2 = 0; i2 < 4; i2++) {
            Spinner spinner = (Spinner) findViewById(this.spinnerTank[i2]);
            if (!z) {
                spinner.setAdapter((SpinnerAdapter) arrayAdapter);
            }
            if (valid_gastanks == 0) {
                spinner.setSelection(-1);
            } else if (gastank_setting.bailMaxTimeMixChoice[i2] < valid_gastanks) {
                spinner.setSelection(gastank_setting.bailMaxTimeMixChoice[i2], true);
            }
        }
    }

    @Override // android.app.Activity
    protected void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == C0347R.id.settank_xml && i2 == -1) {
            setTanks(true);
        }
    }

    @Override // android.app.Activity
    protected void onPause() {
        super.onPause();
        saveSettings();
    }

    private void saveSettings() {
        if (this.configed == 1) {
            this.settings.bailModel = ((Spinner) findViewById(C0347R.id.bailModel)).getSelectedItemPosition() + 1;
            this.settings.bailConserve = ((Spinner) findViewById(C0347R.id.bailConserve)).getSelectedItemPosition();
            this.settings.bailConserveGFLo = 100 - (((Spinner) findViewById(C0347R.id.bailConserveGFLo)).getSelectedItemPosition() * 5);
            this.settings.bailConserveGFHi = 100 - (((Spinner) findViewById(C0347R.id.bailConserveGFHi)).getSelectedItemPosition() * 5);
            this.settings.bailConserveGFS = 100 - (((Spinner) findViewById(C0347R.id.bailConserveGFS)).getSelectedItemPosition() * 5);
            if (this.settings.bailConserveGFHi < this.settings.bailConserveGFLo) {
                Settings settings = this.settings;
                settings.bailConserveGFHi = settings.bailConserveGFLo;
            }
            this.settings.bailRMV = ((Spinner) findViewById(C0347R.id.bailBottomRMV)).getSelectedItemPosition();
            this.settings.bailCavePortion = ((Spinner) findViewById(C0347R.id.BailCaveBail)).getSelectedItemPosition() + 1;
            this.settings.bailCaveBail = ((ToggleButton) findViewById(C0347R.id.BailToggleCaveBail)).isChecked();
            this.settings.bailExtraMin = ((ToggleButton) findViewById(C0347R.id.BailToggleExtraMins)).isChecked();
            this.settings.bailExtraMinTime = ((Spinner) findViewById(C0347R.id.BailExtraMins)).getSelectedItemPosition() + 1;
            this.settings.saveConfig();
        }
    }

    private void conserveViews(int i) {
        switch (i) {
            case 1:
            case 2:
            case 3:
                ((LinearLayout) findViewById(C0347R.id.BailRowConserve)).setVisibility(0);
                ((TextView) findViewById(C0347R.id.BailRowConserveHelp)).setVisibility(0);
                findViewById(C0347R.id.BailRowConserveDivider).setVisibility(0);
                ((LinearLayout) findViewById(C0347R.id.BailRowConserveGF)).setVisibility(8);
                ((TextView) findViewById(C0347R.id.BailRowConserveGFHelp)).setVisibility(8);
                findViewById(C0347R.id.BailRowConserveGFDivider).setVisibility(8);
                ((LinearLayout) findViewById(C0347R.id.BailRowConserveGFS)).setVisibility(8);
                ((TextView) findViewById(C0347R.id.BailRowConserveGFSHelp)).setVisibility(8);
                findViewById(C0347R.id.BailRowConserveGFSDivider).setVisibility(8);
                break;
            case 4:
                ((LinearLayout) findViewById(C0347R.id.BailRowConserve)).setVisibility(0);
                ((TextView) findViewById(C0347R.id.BailRowConserveHelp)).setVisibility(0);
                findViewById(C0347R.id.BailRowConserveDivider).setVisibility(0);
                ((LinearLayout) findViewById(C0347R.id.BailRowConserveGF)).setVisibility(8);
                ((TextView) findViewById(C0347R.id.BailRowConserveGFHelp)).setVisibility(8);
                findViewById(C0347R.id.BailRowConserveGFDivider).setVisibility(8);
                ((LinearLayout) findViewById(C0347R.id.BailRowConserveGFS)).setVisibility(0);
                ((TextView) findViewById(C0347R.id.BailRowConserveGFSHelp)).setVisibility(0);
                findViewById(C0347R.id.BailRowConserveGFSDivider).setVisibility(0);
                break;
            case 5:
            case 6:
                ((LinearLayout) findViewById(C0347R.id.BailRowConserve)).setVisibility(8);
                ((TextView) findViewById(C0347R.id.BailRowConserveHelp)).setVisibility(8);
                findViewById(C0347R.id.BailRowConserveDivider).setVisibility(8);
                ((LinearLayout) findViewById(C0347R.id.BailRowConserveGF)).setVisibility(0);
                ((TextView) findViewById(C0347R.id.BailRowConserveGFHelp)).setVisibility(0);
                findViewById(C0347R.id.BailRowConserveGFDivider).setVisibility(0);
                ((LinearLayout) findViewById(C0347R.id.BailRowConserveGFS)).setVisibility(8);
                ((TextView) findViewById(C0347R.id.BailRowConserveGFSHelp)).setVisibility(8);
                findViewById(C0347R.id.BailRowConserveGFSDivider).setVisibility(8);
                break;
        }
    }
}
