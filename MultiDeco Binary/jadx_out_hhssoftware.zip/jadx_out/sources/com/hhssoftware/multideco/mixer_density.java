package com.hhssoftware.multideco;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.os.MessageQueue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;

/* loaded from: classes.dex */
public class mixer_density extends Activity implements CompoundButton.OnCheckedChangeListener, AdapterView.OnItemSelectedListener, MessageQueue.IdleHandler {
    private final String PREFS_MIXER = "mixer_density";
    private Boolean is20C;
    private Boolean isIniting;
    private Boolean isSP;
    private Settings settings;

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public void onNothingSelected(AdapterView<?> adapterView) {
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        setTheme(new Theme_setting(this).theme_id);
        super.onCreate(bundle);
        setContentView(C0347R.layout.mixer_density);
        this.settings = new Settings(this);
        SharedPreferences sharedPreferences = getSharedPreferences("mixer_density", 0);
        this.isIniting = true;
        initForm();
        loadPrefs(sharedPreferences);
        this.isIniting = false;
        performCalc();
    }

    private void initForm() {
        String str;
        int i;
        if (Build.VERSION.SDK_INT < 35) {
            findViewById(C0347R.id.mixer_density_xml).setPadding(0, 0, 0, 0);
        }
        if (this.settings.Metric) {
            str = " m";
        } else {
            str = " ft";
        }
        int i2 = 1;
        if (this.settings.OC_CCR == 0) {
            ((CompoundButton) findViewById(C0347R.id.densityOC)).setChecked(true);
            ((LinearLayout) findViewById(C0347R.id.DensityRowSP)).setVisibility(8);
            this.isSP = false;
        } else {
            ((CompoundButton) findViewById(C0347R.id.densitySP)).setChecked(true);
            this.isSP = true;
        }
        Spinner spinner = (Spinner) findViewById(C0347R.id.densityO2);
        int i3 = android.R.layout.simple_spinner_item;
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, i3) { // from class: com.hhssoftware.multideco.mixer_density.1
            @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
            public View getDropDownView(int i4, View view, ViewGroup viewGroup) {
                View dropDownView = super.getDropDownView(i4, view, viewGroup);
                ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                return dropDownView;
            }
        };
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        while (true) {
            if (i2 > 100) {
                break;
            }
            arrayAdapter.add(i2 + "%");
            i2++;
        }
        spinner.setAdapter((SpinnerAdapter) arrayAdapter);
        spinner.setSelection(20);
        spinner.setOnItemSelectedListener(this);
        Spinner spinner2 = (Spinner) findViewById(C0347R.id.densityHe);
        ArrayAdapter<String> arrayAdapter2 = new ArrayAdapter<String>(this, i3) { // from class: com.hhssoftware.multideco.mixer_density.2
            @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
            public View getDropDownView(int i4, View view, ViewGroup viewGroup) {
                View dropDownView = super.getDropDownView(i4, view, viewGroup);
                ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                return dropDownView;
            }
        };
        arrayAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        for (int i4 = 0; i4 <= 99; i4++) {
            arrayAdapter2.add(i4 + "%");
        }
        spinner2.setAdapter((SpinnerAdapter) arrayAdapter2);
        spinner2.setSelection(0);
        spinner2.setOnItemSelectedListener(this);
        Spinner spinner3 = (Spinner) findViewById(C0347R.id.densityDepth);
        ArrayAdapter<String> arrayAdapter3 = new ArrayAdapter<String>(this, i3) { // from class: com.hhssoftware.multideco.mixer_density.3
            @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
            public View getDropDownView(int i5, View view, ViewGroup viewGroup) {
                View dropDownView = super.getDropDownView(i5, view, viewGroup);
                ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                return dropDownView;
            }
        };
        arrayAdapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        int i5 = this.settings.Metric ? 2 : 5;
        for (int i6 = 10; i6 <= 80; i6++) {
            arrayAdapter3.add((i6 * i5) + str);
        }
        spinner3.setAdapter((SpinnerAdapter) arrayAdapter3);
        spinner3.setSelection(10);
        spinner3.setOnItemSelectedListener(this);
        Spinner spinner4 = (Spinner) findViewById(C0347R.id.densitypO2);
        ArrayAdapter<String> arrayAdapter4 = new ArrayAdapter<String>(this, i3) { // from class: com.hhssoftware.multideco.mixer_density.4
            @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
            public View getDropDownView(int i7, View view, ViewGroup viewGroup) {
                View dropDownView = super.getDropDownView(i7, view, viewGroup);
                ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                return dropDownView;
            }
        };
        arrayAdapter4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        for (i = 100; i <= 180; i += 5) {
            arrayAdapter4.add(String.format("%.2f", Double.valueOf(i * 0.01d)));
        }
        spinner4.setAdapter((SpinnerAdapter) arrayAdapter4);
        spinner4.setSelection(8);
        spinner4.setOnItemSelectedListener(this);
        ((CompoundButton) findViewById(C0347R.id.densitySP)).setOnCheckedChangeListener(this);
        ((CompoundButton) findViewById(C0347R.id.densityOC)).setOnCheckedChangeListener(this);
        ((CompoundButton) findViewById(C0347R.id.densitytemp0)).setOnCheckedChangeListener(this);
        ((CompoundButton) findViewById(C0347R.id.densitytemp20)).setOnCheckedChangeListener(this);
    }

    private void loadPrefs(SharedPreferences sharedPreferences) {
        if (sharedPreferences.getBoolean("densityTemperature20", true)) {
            ((CompoundButton) findViewById(C0347R.id.densitytemp20)).setChecked(true);
            this.is20C = true;
        } else {
            ((CompoundButton) findViewById(C0347R.id.densitytemp0)).setChecked(true);
            this.is20C = false;
        }
        if (sharedPreferences.contains("densityHe")) {
            ((Spinner) findViewById(C0347R.id.densityHe)).setSelection(sharedPreferences.getInt("densityHe", 0));
        }
        if (sharedPreferences.contains("densityO2")) {
            ((Spinner) findViewById(C0347R.id.densityO2)).setSelection(sharedPreferences.getInt("densityO2", 20));
        }
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        SharedPreferences.Editor edit = getSharedPreferences("mixer_density", 0).edit();
        edit.putBoolean("densityTemperature20", ((CompoundButton) findViewById(C0347R.id.densitytemp20)).isChecked());
        edit.putInt("densityHe", ((Spinner) findViewById(C0347R.id.densityHe)).getSelectedItemPosition());
        edit.putInt("densityO2", ((Spinner) findViewById(C0347R.id.densityO2)).getSelectedItemPosition());
        edit.commit();
        super.onDestroy();
    }

    private void performCalc() {
        if (this.isIniting.booleanValue()) {
            return;
        }
        this.isIniting = true;
        String[] strArr = new String[13];
        int selectedItemPosition = ((Spinner) findViewById(C0347R.id.densityO2)).getSelectedItemPosition() + 1;
        int selectedItemPosition2 = ((Spinner) findViewById(C0347R.id.densityHe)).getSelectedItemPosition();
        if (selectedItemPosition + selectedItemPosition2 > 100) {
            if (findViewById(C0347R.id.densityO2).isFocused()) {
                ((Spinner) findViewById(C0347R.id.densityHe)).setSelection(100 - selectedItemPosition);
            } else {
                ((Spinner) findViewById(C0347R.id.densityO2)).setSelection(99 - selectedItemPosition2);
            }
        }
        strArr[0] = "787";
        strArr[1] = Boolean.toString(this.settings.Metric);
        int selectedItemPosition3 = ((Spinner) findViewById(C0347R.id.densityDepth)).getSelectedItemPosition();
        strArr[2] = (this.settings.Metric ? (selectedItemPosition3 * 2) + 20 : (selectedItemPosition3 * 5) + 50) + "";
        strArr[3] = (((Spinner) findViewById(C0347R.id.densityO2)).getSelectedItemPosition() + 1) + "";
        strArr[4] = ((Spinner) findViewById(C0347R.id.densityHe)).getSelectedItemPosition() + "";
        strArr[5] = ((Spinner) findViewById(C0347R.id.densitypO2)).getSelectedItem().toString();
        strArr[6] = Boolean.toString(this.is20C.booleanValue());
        strArr[7] = Boolean.toString(this.isSP.booleanValue());
        strArr[8] = Boolean.toString(this.settings.WaterType > 0);
        strArr[9] = "";
        strArr[10] = "";
        strArr[11] = "";
        strArr[12] = "";
        String[] performCalc = new tools_calc().performCalc(strArr);
        ((EditText) findViewById(C0347R.id.densityGrams)).setText(performCalc[11]);
        ((EditText) findViewById(C0347R.id.densityATA)).setText(performCalc[12]);
        Looper.myQueue().addIdleHandler(this);
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
        String format;
        int selectedItemPosition = ((Spinner) findViewById(C0347R.id.densityO2)).getSelectedItemPosition() + 1;
        int selectedItemPosition2 = ((Spinner) findViewById(C0347R.id.densityHe)).getSelectedItemPosition();
        if (selectedItemPosition + selectedItemPosition2 > 100) {
            ((Spinner) findViewById(C0347R.id.densityHe)).setSelection(100 - selectedItemPosition);
            return;
        }
        if (selectedItemPosition2 > 0) {
            format = String.format("%d/%d", Integer.valueOf(selectedItemPosition), Integer.valueOf(selectedItemPosition2));
        } else {
            format = String.format("%d%%", Integer.valueOf(selectedItemPosition));
        }
        ((EditText) findViewById(C0347R.id.densityMix)).setText(format);
        performCalc();
    }

    @Override // android.os.MessageQueue.IdleHandler
    public boolean queueIdle() {
        this.isIniting = false;
        return false;
    }

    @Override // android.widget.CompoundButton.OnCheckedChangeListener
    public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
        if (this.isIniting.booleanValue() || !z) {
            return;
        }
        if (compoundButton.getId() == C0347R.id.densitySP) {
            ((LinearLayout) findViewById(C0347R.id.DensityRowSP)).setVisibility(0);
            this.isSP = true;
        } else if (compoundButton.getId() == C0347R.id.densityOC) {
            ((LinearLayout) findViewById(C0347R.id.DensityRowSP)).setVisibility(8);
            this.isSP = false;
        }
        if (compoundButton.getId() == C0347R.id.densitytemp20) {
            this.is20C = true;
        }
        if (compoundButton.getId() == C0347R.id.densitytemp0) {
            this.is20C = false;
        }
        performCalc();
    }
}
