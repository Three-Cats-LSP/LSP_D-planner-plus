package com.hhssoftware.multideco;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.os.MessageQueue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;

/* loaded from: classes.dex */
public class multideco_bestmix extends Activity implements View.OnClickListener, AdapterView.OnItemSelectedListener, MessageQueue.IdleHandler {
    private Boolean isIniting;
    private Settings settings;

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public void onNothingSelected(AdapterView<?> adapterView) {
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        setTheme(new Theme_setting(this).theme_id);
        super.onCreate(bundle);
        setContentView(C0347R.layout.multideco_bestmix);
        this.settings = new Settings(this);
        this.isIniting = true;
        initForm();
        this.isIniting = false;
        performCalc();
    }

    private void initForm() {
        String str;
        if (Build.VERSION.SDK_INT < 35) {
            findViewById(C0347R.id.multideco_bestmix_xml).setPadding(0, 0, 0, 0);
        }
        if (this.settings.Metric) {
            str = " m";
        } else {
            str = " ft";
        }
        Spinner spinner = (Spinner) findViewById(C0347R.id.bestmixDepth);
        int i = android.R.layout.simple_spinner_item;
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_bestmix.1
            @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
            public View getDropDownView(int i2, View view, ViewGroup viewGroup) {
                View dropDownView = super.getDropDownView(i2, view, viewGroup);
                ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                return dropDownView;
            }
        };
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        int i2 = this.settings.Metric ? 2 : 5;
        for (int i3 = 10; i3 <= 80; i3++) {
            arrayAdapter.add((i3 * i2) + str);
        }
        spinner.setAdapter((SpinnerAdapter) arrayAdapter);
        spinner.setSelection(10);
        spinner.setOnItemSelectedListener(this);
        Spinner spinner2 = (Spinner) findViewById(C0347R.id.bestmixppO2);
        ArrayAdapter<String> arrayAdapter2 = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_bestmix.2
            @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
            public View getDropDownView(int i4, View view, ViewGroup viewGroup) {
                View dropDownView = super.getDropDownView(i4, view, viewGroup);
                ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                return dropDownView;
            }
        };
        arrayAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        for (int i4 = 50; i4 <= 180; i4 += 5) {
            arrayAdapter2.add(String.format("%.2f", Double.valueOf(i4 * 0.01d)));
        }
        spinner2.setAdapter((SpinnerAdapter) arrayAdapter2);
        spinner2.setSelection(18);
        spinner2.setOnItemSelectedListener(this);
        Spinner spinner3 = (Spinner) findViewById(C0347R.id.bestmixtrimixead);
        ArrayAdapter<String> arrayAdapter3 = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_bestmix.3
            @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
            public View getDropDownView(int i5, View view, ViewGroup viewGroup) {
                View dropDownView = super.getDropDownView(i5, view, viewGroup);
                ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                return dropDownView;
            }
        };
        arrayAdapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        int i5 = this.settings.Metric ? 2 : 5;
        for (int i6 = 10; i6 <= 60; i6++) {
            arrayAdapter3.add((i6 * i5) + str);
        }
        spinner3.setAdapter((SpinnerAdapter) arrayAdapter3);
        spinner3.setSelection(10);
        spinner3.setOnItemSelectedListener(this);
        findViewById(C0347R.id.bestmixTrimix).setOnClickListener(this);
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        performCalc();
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
        performCalc();
    }

    private void performCalc() {
        if (this.isIniting.booleanValue()) {
            return;
        }
        this.isIniting = true;
        String[] strArr = new String[8];
        strArr[0] = "132";
        strArr[1] = Boolean.toString(this.settings.Metric);
        strArr[2] = ((Spinner) findViewById(C0347R.id.bestmixDepth)).getSelectedItemPosition() + "";
        strArr[3] = ((Spinner) findViewById(C0347R.id.bestmixppO2)).getSelectedItemPosition() + "";
        strArr[4] = Boolean.toString(((CompoundButton) findViewById(C0347R.id.bestmixTrimix)).isChecked());
        strArr[5] = ((Spinner) findViewById(C0347R.id.bestmixtrimixead)).getSelectedItemPosition() + "";
        strArr[6] = "";
        strArr[7] = Boolean.toString(this.settings.WaterType > 0);
        ((EditText) findViewById(C0347R.id.bestmix)).setText(new tools_calc().performCalc(strArr)[6]);
        Looper.myQueue().addIdleHandler(this);
    }

    @Override // android.os.MessageQueue.IdleHandler
    public boolean queueIdle() {
        this.isIniting = false;
        return false;
    }
}
