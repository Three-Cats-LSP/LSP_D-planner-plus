package com.hhssoftware.multideco;

import android.content.Context;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Arrays;

/* loaded from: classes.dex */
public class Gastank_setting {
    public static final int GASTANK_BAIL = 2;
    public static final int GASTANK_OC = 1;
    private static final String Gastank_setting_stream = "gastank_setting.data";
    public static final int MAX_BAILMIX = 4;
    public static final int MAX_OCMIX = 8;
    public static final int MAX_TANKSIZE = 10;
    public static final int TANK_FILL_BAR = 8;
    public static final int TANK_FILL_PSI = 4;
    public static final int TANK_SIZE_FT = 1;
    public static final int TANK_SIZE_LTR = 2;
    private static final long serialVersionUID = 1;
    public boolean bailoutMaxTime;
    private final Context context;
    private final int oc_bail;
    private final TankSize[] tanksizeOC = new TankSize[10];
    private final TankSize[] tanksizeCCR = new TankSize[10];
    private final TankPress[] tankpressOC = new TankPress[10];
    private final TankPress[] tankpressCCR = new TankPress[10];
    public byte[] bailMaxTimeMixChoice = new byte[4];
    public byte[] ocMaxTimeMixChoice = new byte[8];

    public static class TankPress {
        public double FromP;
        public int TankIdx;
        public double ToP;
    }

    public static class TankSize {
        public boolean Doubled;
        public double FillPress;
        public String Name;
        public int Params;
        public double Size;
    }

    public Gastank_setting(Context context, int i) {
        this.context = context;
        this.oc_bail = i;
        for (int i2 = 0; i2 < 10; i2++) {
            this.tanksizeOC[i2] = new TankSize();
        }
        for (int i3 = 0; i3 < 10; i3++) {
            this.tanksizeCCR[i3] = new TankSize();
        }
        for (int i4 = 0; i4 < 10; i4++) {
            this.tankpressOC[i4] = new TankPress();
        }
        for (int i5 = 0; i5 < 10; i5++) {
            this.tankpressCCR[i5] = new TankPress();
        }
        load_gastank_setting();
    }

    private void load_gastank_setting() {
        try {
            FileInputStream openFileInput = this.context.openFileInput(Gastank_setting_stream);
            ObjectInputStream objectInputStream = new ObjectInputStream(openFileInput);
            if (serialVersionUID != objectInputStream.readLong()) {
                objectInputStream.close();
                this.context.deleteFile(Gastank_setting_stream);
                return;
            }
            for (int i = 0; i < 10; i++) {
                this.tanksizeOC[i].Name = (String) objectInputStream.readObject();
                this.tanksizeOC[i].Size = objectInputStream.readDouble();
                this.tanksizeOC[i].Doubled = objectInputStream.readBoolean();
                this.tanksizeOC[i].FillPress = objectInputStream.readDouble();
                this.tanksizeOC[i].Params = objectInputStream.readInt();
                this.tankpressOC[i].TankIdx = objectInputStream.readInt();
                this.tankpressOC[i].FromP = objectInputStream.readDouble();
                this.tankpressOC[i].ToP = objectInputStream.readDouble();
            }
            for (int i2 = 0; i2 < 10; i2++) {
                this.tanksizeCCR[i2].Name = (String) objectInputStream.readObject();
                this.tanksizeCCR[i2].Size = objectInputStream.readDouble();
                this.tanksizeCCR[i2].Doubled = objectInputStream.readBoolean();
                this.tanksizeCCR[i2].FillPress = objectInputStream.readDouble();
                this.tanksizeCCR[i2].Params = objectInputStream.readInt();
                this.tankpressCCR[i2].TankIdx = objectInputStream.readInt();
                this.tankpressCCR[i2].FromP = objectInputStream.readDouble();
                this.tankpressCCR[i2].ToP = objectInputStream.readDouble();
            }
            for (int i3 = 0; i3 < 4; i3++) {
                this.bailMaxTimeMixChoice[i3] = objectInputStream.readByte();
            }
            for (int i4 = 0; i4 < 8; i4++) {
                this.ocMaxTimeMixChoice[i4] = objectInputStream.readByte();
            }
            this.bailoutMaxTime = objectInputStream.readBoolean();
            objectInputStream.close();
            openFileInput.close();
        } catch (FileNotFoundException unused) {
        } catch (Exception unused2) {
            this.context.deleteFile(Gastank_setting_stream);
        }
    }

    public void update_gastank_setting() {
        save_gastank_setting();
    }

    public void null_gastank_setting() {
        for (int i = 0; i < 10; i++) {
            this.tanksizeOC[i].Name = "";
            this.tanksizeOC[i].Size = 0.0d;
            this.tanksizeOC[i].Doubled = false;
            this.tanksizeOC[i].FillPress = 0.0d;
            this.tanksizeOC[i].Params = 0;
            this.tankpressOC[i].TankIdx = 0;
            this.tankpressOC[i].FromP = 0.0d;
            this.tankpressOC[i].ToP = 0.0d;
        }
        for (int i2 = 0; i2 < 10; i2++) {
            this.tanksizeCCR[i2].Name = "";
            this.tanksizeCCR[i2].Size = 0.0d;
            this.tanksizeCCR[i2].Doubled = false;
            this.tanksizeCCR[i2].FillPress = 0.0d;
            this.tanksizeCCR[i2].Params = 0;
            this.tankpressCCR[i2].TankIdx = 0;
            this.tankpressCCR[i2].FromP = 0.0d;
            this.tankpressCCR[i2].ToP = 0.0d;
        }
        Arrays.fill(this.bailMaxTimeMixChoice, (byte) 0);
        Arrays.fill(this.ocMaxTimeMixChoice, (byte) 0);
        this.bailoutMaxTime = false;
        save_gastank_setting();
    }

    private void save_gastank_setting() {
        try {
            FileOutputStream openFileOutput = this.context.openFileOutput(Gastank_setting_stream, 0);
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(openFileOutput);
            objectOutputStream.writeLong(serialVersionUID);
            for (int i = 0; i < 10; i++) {
                objectOutputStream.writeObject(this.tanksizeOC[i].Name);
                objectOutputStream.writeDouble(this.tanksizeOC[i].Size);
                objectOutputStream.writeBoolean(this.tanksizeOC[i].Doubled);
                objectOutputStream.writeDouble(this.tanksizeOC[i].FillPress);
                objectOutputStream.writeInt(this.tanksizeOC[i].Params);
                objectOutputStream.writeInt(this.tankpressOC[i].TankIdx);
                objectOutputStream.writeDouble(this.tankpressOC[i].FromP);
                objectOutputStream.writeDouble(this.tankpressOC[i].ToP);
            }
            for (int i2 = 0; i2 < 10; i2++) {
                objectOutputStream.writeObject(this.tanksizeCCR[i2].Name);
                objectOutputStream.writeDouble(this.tanksizeCCR[i2].Size);
                objectOutputStream.writeBoolean(this.tanksizeCCR[i2].Doubled);
                objectOutputStream.writeDouble(this.tanksizeCCR[i2].FillPress);
                objectOutputStream.writeInt(this.tanksizeCCR[i2].Params);
                objectOutputStream.writeInt(this.tankpressCCR[i2].TankIdx);
                objectOutputStream.writeDouble(this.tankpressCCR[i2].FromP);
                objectOutputStream.writeDouble(this.tankpressCCR[i2].ToP);
            }
            for (int i3 = 0; i3 < 4; i3++) {
                objectOutputStream.writeByte(this.bailMaxTimeMixChoice[i3]);
            }
            for (int i4 = 0; i4 < 8; i4++) {
                objectOutputStream.writeByte(this.ocMaxTimeMixChoice[i4]);
            }
            objectOutputStream.writeBoolean(this.bailoutMaxTime);
            objectOutputStream.close();
            openFileOutput.close();
        } catch (FileNotFoundException | IOException unused) {
        }
    }

    public int valid_gastanks() {
        int i;
        if (this.oc_bail == 1) {
            i = 0;
            for (int i2 = 0; i2 < 10; i2++) {
                if (this.tanksizeOC[i2].Name != null && this.tanksizeOC[i2].Name.length() > 0 && this.tanksizeOC[i2].Size > 0.0d && this.tanksizeOC[i2].FillPress > 0.0d) {
                    i++;
                }
            }
        } else {
            i = 0;
        }
        if (this.oc_bail == 2) {
            for (int i3 = 0; i3 < 10; i3++) {
                if (this.tanksizeCCR[i3].Name != null && this.tanksizeCCR[i3].Name.length() > 0 && this.tanksizeCCR[i3].Size > 0.0d && this.tanksizeCCR[i3].FillPress > 0.0d) {
                    i++;
                }
            }
        }
        return i;
    }

    public TankSize gettank(int i) {
        int i2 = this.oc_bail;
        return i2 == 2 ? this.tanksizeCCR[i] : i2 == 1 ? this.tanksizeOC[i] : null;
    }

    public int appendtank(TankSize tankSize) {
        int valid_gastanks = valid_gastanks();
        if (valid_gastanks >= 10) {
            return -1;
        }
        int i = this.oc_bail;
        if (i == 1) {
            this.tanksizeOC[valid_gastanks] = tankSize;
        }
        if (i == 2) {
            this.tanksizeCCR[valid_gastanks] = tankSize;
        }
        return valid_gastanks;
    }

    public int deletetank(int i) {
        while (i < 9) {
            int i2 = this.oc_bail;
            if (i2 == 1) {
                TankSize[] tankSizeArr = this.tanksizeOC;
                tankSizeArr[i] = tankSizeArr[i + 1];
            }
            if (i2 == 2) {
                TankSize[] tankSizeArr2 = this.tanksizeCCR;
                tankSizeArr2[i] = tankSizeArr2[i + 1];
            }
            i++;
        }
        if (this.oc_bail == 1) {
            TankSize[] tankSizeArr3 = this.tanksizeOC;
            tankSizeArr3[9] = null;
            tankSizeArr3[9] = new TankSize();
        }
        if (this.oc_bail == 2) {
            TankSize[] tankSizeArr4 = this.tanksizeCCR;
            tankSizeArr4[9] = null;
            tankSizeArr4[9] = new TankSize();
        }
        return valid_gastanks();
    }

    public int findtank(String str) {
        for (int i = 0; i < 10; i++) {
            if (this.oc_bail == 1) {
                if (this.tanksizeOC[i].Name == null) {
                    return -1;
                }
                if (this.tanksizeOC[i].Name.equals(str)) {
                    return i;
                }
            }
            if (this.oc_bail == 2) {
                if (this.tanksizeCCR[i].Name == null) {
                    return -1;
                }
                if (this.tanksizeCCR[i].Name.equals(str)) {
                    return i;
                }
            }
        }
        return -1;
    }

    public TankPress getpress(int i) {
        if (this.oc_bail == 1) {
            return this.tankpressOC[i];
        }
        return this.tankpressCCR[i];
    }

    public void setpress(int i, int i2, double d, double d2) {
        if (this.oc_bail == 1) {
            this.tankpressOC[i].TankIdx = i2;
            this.tankpressOC[i].FromP = d;
            this.tankpressOC[i].ToP = d2;
        } else {
            this.tankpressCCR[i].TankIdx = i2;
            this.tankpressCCR[i].FromP = d;
            this.tankpressCCR[i].ToP = d2;
        }
    }

    static double calculateMixAvailable(TankSize tankSize, TankPress tankPress, boolean z) {
        double d = tankPress.FromP;
        double d2 = tankPress.ToP;
        if (d <= d2) {
            return 0.0d;
        }
        double d3 = tankSize.FillPress;
        if ((tankSize.Params & 4) == 4) {
            d3 = tankSize.FillPress / 14.5078d;
        }
        double d4 = tankSize.Size;
        if ((tankSize.Params & 1) == 1) {
            d4 = (tankSize.Size * 28.3168d) / d3;
        }
        if (tankSize.Doubled) {
            d4 *= 2.0d;
        }
        double d5 = ((d - d2) / tankSize.FillPress) * d3 * d4;
        return !z ? d5 / 28.3168d : d5;
    }
}
