package com.hhssoftware.multideco;

/* renamed from: com.hhssoftware.multideco.R */
/* loaded from: classes.dex */
public final class C0347R {

    /* renamed from: com.hhssoftware.multideco.R$color */
    public static final class color {
        public static int colorAccent = 2131034155;
        public static int colorPrimary = 2131034156;
        public static int colorPrimaryDark = 2131034157;
        public static int darkgray = 2131034158;
        public static int ic_launcher_background = 2131034169;
        public static int ic_multideco_background = 2131034170;
        public static int lightgray = 2131034171;
        public static int red = 2131034194;

        /* JADX INFO: Added by JADX */
        public static final int abc_background_cache_hint_selector_material_dark = 2131034112;

        /* JADX INFO: Added by JADX */
        public static final int abc_background_cache_hint_selector_material_light = 2131034113;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_colored_borderless_text_material = 2131034114;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_colored_text_material = 2131034115;

        /* JADX INFO: Added by JADX */
        public static final int abc_color_highlight_material = 2131034116;

        /* JADX INFO: Added by JADX */
        public static final int abc_decor_view_status_guard = 2131034117;

        /* JADX INFO: Added by JADX */
        public static final int abc_decor_view_status_guard_light = 2131034118;

        /* JADX INFO: Added by JADX */
        public static final int abc_hint_foreground_material_dark = 2131034119;

        /* JADX INFO: Added by JADX */
        public static final int abc_hint_foreground_material_light = 2131034120;

        /* JADX INFO: Added by JADX */
        public static final int abc_primary_text_disable_only_material_dark = 2131034121;

        /* JADX INFO: Added by JADX */
        public static final int abc_primary_text_disable_only_material_light = 2131034122;

        /* JADX INFO: Added by JADX */
        public static final int abc_primary_text_material_dark = 2131034123;

        /* JADX INFO: Added by JADX */
        public static final int abc_primary_text_material_light = 2131034124;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_url_text = 2131034125;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_url_text_normal = 2131034126;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_url_text_pressed = 2131034127;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_url_text_selected = 2131034128;

        /* JADX INFO: Added by JADX */
        public static final int abc_secondary_text_material_dark = 2131034129;

        /* JADX INFO: Added by JADX */
        public static final int abc_secondary_text_material_light = 2131034130;

        /* JADX INFO: Added by JADX */
        public static final int abc_tint_btn_checkable = 2131034131;

        /* JADX INFO: Added by JADX */
        public static final int abc_tint_default = 2131034132;

        /* JADX INFO: Added by JADX */
        public static final int abc_tint_edittext = 2131034133;

        /* JADX INFO: Added by JADX */
        public static final int abc_tint_seek_thumb = 2131034134;

        /* JADX INFO: Added by JADX */
        public static final int abc_tint_spinner = 2131034135;

        /* JADX INFO: Added by JADX */
        public static final int abc_tint_switch_track = 2131034136;

        /* JADX INFO: Added by JADX */
        public static final int accent_material_dark = 2131034137;

        /* JADX INFO: Added by JADX */
        public static final int accent_material_light = 2131034138;

        /* JADX INFO: Added by JADX */
        public static final int androidx_core_ripple_material_light = 2131034139;

        /* JADX INFO: Added by JADX */
        public static final int androidx_core_secondary_text_default_material_light = 2131034140;

        /* JADX INFO: Added by JADX */
        public static final int background_floating_material_dark = 2131034141;

        /* JADX INFO: Added by JADX */
        public static final int background_floating_material_light = 2131034142;

        /* JADX INFO: Added by JADX */
        public static final int background_material_dark = 2131034143;

        /* JADX INFO: Added by JADX */
        public static final int background_material_light = 2131034144;

        /* JADX INFO: Added by JADX */
        public static final int bright_foreground_disabled_material_dark = 2131034145;

        /* JADX INFO: Added by JADX */
        public static final int bright_foreground_disabled_material_light = 2131034146;

        /* JADX INFO: Added by JADX */
        public static final int bright_foreground_inverse_material_dark = 2131034147;

        /* JADX INFO: Added by JADX */
        public static final int bright_foreground_inverse_material_light = 2131034148;

        /* JADX INFO: Added by JADX */
        public static final int bright_foreground_material_dark = 2131034149;

        /* JADX INFO: Added by JADX */
        public static final int bright_foreground_material_light = 2131034150;

        /* JADX INFO: Added by JADX */
        public static final int button_material_dark = 2131034151;

        /* JADX INFO: Added by JADX */
        public static final int button_material_light = 2131034152;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_answer_color = 2131034153;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_decline_color = 2131034154;

        /* JADX INFO: Added by JADX */
        public static final int dim_foreground_disabled_material_dark = 2131034159;

        /* JADX INFO: Added by JADX */
        public static final int dim_foreground_disabled_material_light = 2131034160;

        /* JADX INFO: Added by JADX */
        public static final int dim_foreground_material_dark = 2131034161;

        /* JADX INFO: Added by JADX */
        public static final int dim_foreground_material_light = 2131034162;

        /* JADX INFO: Added by JADX */
        public static final int error_color_material_dark = 2131034163;

        /* JADX INFO: Added by JADX */
        public static final int error_color_material_light = 2131034164;

        /* JADX INFO: Added by JADX */
        public static final int foreground_material_dark = 2131034165;

        /* JADX INFO: Added by JADX */
        public static final int foreground_material_light = 2131034166;

        /* JADX INFO: Added by JADX */
        public static final int highlighted_text_material_dark = 2131034167;

        /* JADX INFO: Added by JADX */
        public static final int highlighted_text_material_light = 2131034168;

        /* JADX INFO: Added by JADX */
        public static final int material_blue_grey_800 = 2131034172;

        /* JADX INFO: Added by JADX */
        public static final int material_blue_grey_900 = 2131034173;

        /* JADX INFO: Added by JADX */
        public static final int material_blue_grey_950 = 2131034174;

        /* JADX INFO: Added by JADX */
        public static final int material_deep_teal_200 = 2131034175;

        /* JADX INFO: Added by JADX */
        public static final int material_deep_teal_500 = 2131034176;

        /* JADX INFO: Added by JADX */
        public static final int material_grey_100 = 2131034177;

        /* JADX INFO: Added by JADX */
        public static final int material_grey_300 = 2131034178;

        /* JADX INFO: Added by JADX */
        public static final int material_grey_50 = 2131034179;

        /* JADX INFO: Added by JADX */
        public static final int material_grey_600 = 2131034180;

        /* JADX INFO: Added by JADX */
        public static final int material_grey_800 = 2131034181;

        /* JADX INFO: Added by JADX */
        public static final int material_grey_850 = 2131034182;

        /* JADX INFO: Added by JADX */
        public static final int material_grey_900 = 2131034183;

        /* JADX INFO: Added by JADX */
        public static final int notification_action_color_filter = 2131034184;

        /* JADX INFO: Added by JADX */
        public static final int notification_icon_bg_color = 2131034185;

        /* JADX INFO: Added by JADX */
        public static final int primary_dark_material_dark = 2131034186;

        /* JADX INFO: Added by JADX */
        public static final int primary_dark_material_light = 2131034187;

        /* JADX INFO: Added by JADX */
        public static final int primary_material_dark = 2131034188;

        /* JADX INFO: Added by JADX */
        public static final int primary_material_light = 2131034189;

        /* JADX INFO: Added by JADX */
        public static final int primary_text_default_material_dark = 2131034190;

        /* JADX INFO: Added by JADX */
        public static final int primary_text_default_material_light = 2131034191;

        /* JADX INFO: Added by JADX */
        public static final int primary_text_disabled_material_dark = 2131034192;

        /* JADX INFO: Added by JADX */
        public static final int primary_text_disabled_material_light = 2131034193;

        /* JADX INFO: Added by JADX */
        public static final int ripple_material_dark = 2131034195;

        /* JADX INFO: Added by JADX */
        public static final int ripple_material_light = 2131034196;

        /* JADX INFO: Added by JADX */
        public static final int secondary_text_default_material_dark = 2131034197;

        /* JADX INFO: Added by JADX */
        public static final int secondary_text_default_material_light = 2131034198;

        /* JADX INFO: Added by JADX */
        public static final int secondary_text_disabled_material_dark = 2131034199;

        /* JADX INFO: Added by JADX */
        public static final int secondary_text_disabled_material_light = 2131034200;

        /* JADX INFO: Added by JADX */
        public static final int switch_thumb_disabled_material_dark = 2131034201;

        /* JADX INFO: Added by JADX */
        public static final int switch_thumb_disabled_material_light = 2131034202;

        /* JADX INFO: Added by JADX */
        public static final int switch_thumb_material_dark = 2131034203;

        /* JADX INFO: Added by JADX */
        public static final int switch_thumb_material_light = 2131034204;

        /* JADX INFO: Added by JADX */
        public static final int switch_thumb_normal_material_dark = 2131034205;

        /* JADX INFO: Added by JADX */
        public static final int switch_thumb_normal_material_light = 2131034206;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_background_dark = 2131034207;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_background_light = 2131034208;

        private color() {
        }
    }

    /* renamed from: com.hhssoftware.multideco.R$drawable */
    public static final class drawable {
        public static int add = 2131165263;
        public static int ascend = 2131165264;
        public static int delete = 2131165273;
        public static int descend = 2131165274;
        public static int ic_menu_copy_holo_dark = 2131165281;
        public static int icon_about_mixer = 2131165282;
        public static int level = 2131165283;
        public static int listviewborder = 2131165284;
        public static int mixer32 = 2131165285;
        public static int multideco_114 = 2131165286;
        public static int settings = 2131165300;
        public static int stop = 2131165301;
        public static int surface = 2131165302;

        /* JADX INFO: Added by JADX */
        public static final int abc_ab_share_pack_mtrl_alpha = 2131165184;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_item_background_material = 2131165185;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_borderless_material = 2131165186;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_check_material = 2131165187;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_check_material_anim = 2131165188;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_check_to_on_mtrl_000 = 2131165189;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_check_to_on_mtrl_015 = 2131165190;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_colored_material = 2131165191;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_default_mtrl_shape = 2131165192;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_radio_material = 2131165193;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_radio_material_anim = 2131165194;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_radio_to_on_mtrl_000 = 2131165195;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_radio_to_on_mtrl_015 = 2131165196;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_switch_to_on_mtrl_00001 = 2131165197;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_switch_to_on_mtrl_00012 = 2131165198;

        /* JADX INFO: Added by JADX */
        public static final int abc_cab_background_internal_bg = 2131165199;

        /* JADX INFO: Added by JADX */
        public static final int abc_cab_background_top_material = 2131165200;

        /* JADX INFO: Added by JADX */
        public static final int abc_cab_background_top_mtrl_alpha = 2131165201;

        /* JADX INFO: Added by JADX */
        public static final int abc_control_background_material = 2131165202;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_material_background = 2131165203;

        /* JADX INFO: Added by JADX */
        public static final int abc_edit_text_material = 2131165204;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_ab_back_material = 2131165205;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_arrow_drop_right_black_24dp = 2131165206;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_clear_material = 2131165207;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_commit_search_api_mtrl_alpha = 2131165208;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_go_search_api_material = 2131165209;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_menu_copy_mtrl_am_alpha = 2131165210;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_menu_cut_mtrl_alpha = 2131165211;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_menu_overflow_material = 2131165212;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_menu_paste_mtrl_am_alpha = 2131165213;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_menu_selectall_mtrl_alpha = 2131165214;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_menu_share_mtrl_alpha = 2131165215;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_search_api_material = 2131165216;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_voice_search_api_material = 2131165217;

        /* JADX INFO: Added by JADX */
        public static final int abc_item_background_holo_dark = 2131165218;

        /* JADX INFO: Added by JADX */
        public static final int abc_item_background_holo_light = 2131165219;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_divider_material = 2131165220;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_divider_mtrl_alpha = 2131165221;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_focused_holo = 2131165222;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_longpressed_holo = 2131165223;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_pressed_holo_dark = 2131165224;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_pressed_holo_light = 2131165225;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_selector_background_transition_holo_dark = 2131165226;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_selector_background_transition_holo_light = 2131165227;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_selector_disabled_holo_dark = 2131165228;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_selector_disabled_holo_light = 2131165229;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_selector_holo_dark = 2131165230;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_selector_holo_light = 2131165231;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_hardkey_panel_mtrl_mult = 2131165232;

        /* JADX INFO: Added by JADX */
        public static final int abc_popup_background_mtrl_mult = 2131165233;

        /* JADX INFO: Added by JADX */
        public static final int abc_ratingbar_indicator_material = 2131165234;

        /* JADX INFO: Added by JADX */
        public static final int abc_ratingbar_material = 2131165235;

        /* JADX INFO: Added by JADX */
        public static final int abc_ratingbar_small_material = 2131165236;

        /* JADX INFO: Added by JADX */
        public static final int abc_scrubber_control_off_mtrl_alpha = 2131165237;

        /* JADX INFO: Added by JADX */
        public static final int abc_scrubber_control_to_pressed_mtrl_000 = 2131165238;

        /* JADX INFO: Added by JADX */
        public static final int abc_scrubber_control_to_pressed_mtrl_005 = 2131165239;

        /* JADX INFO: Added by JADX */
        public static final int abc_scrubber_primary_mtrl_alpha = 2131165240;

        /* JADX INFO: Added by JADX */
        public static final int abc_scrubber_track_mtrl_alpha = 2131165241;

        /* JADX INFO: Added by JADX */
        public static final int abc_seekbar_thumb_material = 2131165242;

        /* JADX INFO: Added by JADX */
        public static final int abc_seekbar_tick_mark_material = 2131165243;

        /* JADX INFO: Added by JADX */
        public static final int abc_seekbar_track_material = 2131165244;

        /* JADX INFO: Added by JADX */
        public static final int abc_spinner_mtrl_am_alpha = 2131165245;

        /* JADX INFO: Added by JADX */
        public static final int abc_spinner_textfield_background_material = 2131165246;

        /* JADX INFO: Added by JADX */
        public static final int abc_star_black_48dp = 2131165247;

        /* JADX INFO: Added by JADX */
        public static final int abc_star_half_black_48dp = 2131165248;

        /* JADX INFO: Added by JADX */
        public static final int abc_switch_thumb_material = 2131165249;

        /* JADX INFO: Added by JADX */
        public static final int abc_switch_track_mtrl_alpha = 2131165250;

        /* JADX INFO: Added by JADX */
        public static final int abc_tab_indicator_material = 2131165251;

        /* JADX INFO: Added by JADX */
        public static final int abc_tab_indicator_mtrl_alpha = 2131165252;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_cursor_material = 2131165253;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_select_handle_left_mtrl = 2131165254;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_select_handle_middle_mtrl = 2131165255;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_select_handle_right_mtrl = 2131165256;

        /* JADX INFO: Added by JADX */
        public static final int abc_textfield_activated_mtrl_alpha = 2131165257;

        /* JADX INFO: Added by JADX */
        public static final int abc_textfield_default_mtrl_alpha = 2131165258;

        /* JADX INFO: Added by JADX */
        public static final int abc_textfield_search_activated_mtrl_alpha = 2131165259;

        /* JADX INFO: Added by JADX */
        public static final int abc_textfield_search_default_mtrl_alpha = 2131165260;

        /* JADX INFO: Added by JADX */
        public static final int abc_textfield_search_material = 2131165261;

        /* JADX INFO: Added by JADX */
        public static final int abc_vector_test = 2131165262;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_checked_mtrl = 2131165265;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_checked_to_unchecked_mtrl_animation = 2131165266;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_unchecked_mtrl = 2131165267;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_unchecked_to_checked_mtrl_animation = 2131165268;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_off_mtrl = 2131165269;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_off_to_on_mtrl_animation = 2131165270;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_on_mtrl = 2131165271;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_on_to_off_mtrl_animation = 2131165272;

        /* JADX INFO: Added by JADX */
        public static final int ic_call_answer = 2131165275;

        /* JADX INFO: Added by JADX */
        public static final int ic_call_answer_low = 2131165276;

        /* JADX INFO: Added by JADX */
        public static final int ic_call_answer_video = 2131165277;

        /* JADX INFO: Added by JADX */
        public static final int ic_call_answer_video_low = 2131165278;

        /* JADX INFO: Added by JADX */
        public static final int ic_call_decline = 2131165279;

        /* JADX INFO: Added by JADX */
        public static final int ic_call_decline_low = 2131165280;

        /* JADX INFO: Added by JADX */
        public static final int notification_action_background = 2131165287;

        /* JADX INFO: Added by JADX */
        public static final int notification_bg = 2131165288;

        /* JADX INFO: Added by JADX */
        public static final int notification_bg_low = 2131165289;

        /* JADX INFO: Added by JADX */
        public static final int notification_bg_low_normal = 2131165290;

        /* JADX INFO: Added by JADX */
        public static final int notification_bg_low_pressed = 2131165291;

        /* JADX INFO: Added by JADX */
        public static final int notification_bg_normal = 2131165292;

        /* JADX INFO: Added by JADX */
        public static final int notification_bg_normal_pressed = 2131165293;

        /* JADX INFO: Added by JADX */
        public static final int notification_icon_background = 2131165294;

        /* JADX INFO: Added by JADX */
        public static final int notification_oversize_large_icon_bg = 2131165295;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_icon_bg = 2131165296;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_icon_low_bg = 2131165297;

        /* JADX INFO: Added by JADX */
        public static final int notification_tile_bg = 2131165298;

        /* JADX INFO: Added by JADX */
        public static final int notify_panel_notification_icon_bg = 2131165299;

        /* JADX INFO: Added by JADX */
        public static final int test_level_drawable = 2131165303;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_frame_dark = 2131165304;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_frame_light = 2131165305;

        private drawable() {
        }
    }

    /* renamed from: com.hhssoftware.multideco.R$id */
    public static final class id {
        public static int AboutScrollView = 2131230721;
        public static int AgreeScrollView = 2131230722;
        public static int BailCaveBail = 2131230723;
        public static int BailCavebailMode = 2131230724;
        public static int BailConserveGFLabel = 2131230725;
        public static int BailConserveGFSLabel = 2131230726;
        public static int BailConserveLabel = 2131230727;
        public static int BailExtraMins = 2131230728;
        public static int BailExtraMinsMode = 2131230729;
        public static int BailMaxTimeplan = 2131230730;
        public static int BailMaxtimeplanOnOff = 2131230731;
        public static int BailMaxtimeplanSetup = 2131230732;
        public static int BailRowBottomCavebailHelp = 2131230733;
        public static int BailRowBottomRMV = 2131230734;
        public static int BailRowBottomRMVHelp = 2131230735;
        public static int BailRowConserve = 2131230736;
        public static int BailRowConserveDivider = 2131230737;
        public static int BailRowConserveGF = 2131230738;
        public static int BailRowConserveGFDivider = 2131230739;
        public static int BailRowConserveGFHelp = 2131230740;
        public static int BailRowConserveGFS = 2131230741;
        public static int BailRowConserveGFSDivider = 2131230742;
        public static int BailRowConserveGFSHelp = 2131230743;
        public static int BailRowConserveHelp = 2131230744;
        public static int BailRowExtraMinsHelp = 2131230745;
        public static int BailRowIntroHelp = 2131230746;
        public static int BailRowMaxTimeHelp = 2131230747;
        public static int BailRowModel = 2131230748;
        public static int BailRowOCMixHelp = 2131230749;
        public static int BailRowVPMModelHelp = 2131230750;
        public static int BailScrollView = 2131230751;
        public static int BailToggleCaveBail = 2131230752;
        public static int BailToggleExtraMins = 2131230753;
        public static int BestMixRowDepth = 2131230754;
        public static int BestMixRowResult = 2131230755;
        public static int BestMixRowppO2 = 2131230756;
        public static int BestMixTrimix = 2131230757;
        public static int BestMixTrimixEAD = 2131230758;
        public static int ButtonAboutEmail = 2131230759;
        public static int ButtonAboutIcon = 2131230760;
        public static int ButtonAccept = 2131230761;
        public static int ButtonAddDeco = 2131230762;
        public static int ButtonAddLevel = 2131230763;
        public static int ButtonBailCalculate = 2131230764;
        public static int ButtonBailout = 2131230765;
        public static int ButtonCalc = 2131230766;
        public static int ButtonCancel = 2131230767;
        public static int ButtonDecline = 2131230768;
        public static int ButtonDeleteDeco = 2131230769;
        public static int ButtonDeleteLevel = 2131230770;
        public static int ButtonMaxtime = 2131230771;
        public static int ButtonNewKey = 2131230772;
        public static int ButtonOCMaxCalculate = 2131230773;
        public static int ButtonRegister = 2131230774;
        public static int ButtonSave = 2131230775;
        public static int CapacityScrollView = 2131230777;
        public static int Capacityequalize = 2131230778;
        public static int Capacityrepeat = 2131230779;
        public static int CheckBoxOC = 2131230780;
        public static int CheckBoxSCR = 2131230781;
        public static int ConfigAcclim = 2131230782;
        public static int ConfigAddAllMix = 2131230783;
        public static int ConfigAddAllMixText = 2131230784;
        public static int ConfigAddO2Window = 2131230785;
        public static int ConfigAddO2WindowText = 2131230786;
        public static int ConfigAddToStop = 2131230787;
        public static int ConfigAddToStopText = 2131230788;
        public static int ConfigAscentAsc = 2131230789;
        public static int ConfigAscentDeco = 2131230790;
        public static int ConfigAscentSurf = 2131230791;
        public static int ConfigCCRdilCheckColor = 2131230792;
        public static int ConfigCCRdilCheckHelp = 2131230793;
        public static int ConfigCNSAbove = 2131230794;
        public static int ConfigCNSAboveColor = 2131230795;
        public static int ConfigCNSAboveHelp = 2131230796;
        public static int ConfigCircuitATA = 2131230797;
        public static int ConfigCircuitBAR = 2131230798;
        public static int ConfigCircuitCCR = 2131230799;
        public static int ConfigCircuitOC = 2131230800;
        public static int ConfigConserveGFLabel = 2131230801;
        public static int ConfigConserveGFSLabel = 2131230802;
        public static int ConfigConserveLabel = 2131230803;
        public static int ConfigCuFt = 2131230804;
        public static int ConfigDescent = 2131230805;
        public static int ConfigElevation = 2131230806;
        public static int ConfigExtendDeepText = 2131230807;
        public static int ConfigExtendOnOff = 2131230808;
        public static int ConfigExtendShallow = 2131230809;
        public static int ConfigExtendShallowText = 2131230810;
        public static int ConfigFeet = 2131230811;
        public static int ConfigFresh = 2131230812;
        public static int ConfigGuagetypeDigital = 2131230813;
        public static int ConfigGuagetypeSimple = 2131230814;
        public static int ConfigIBCDHeWarn = 2131230815;
        public static int ConfigIBCDHeWarnColor = 2131230816;
        public static int ConfigIBCDHeWarnHelp = 2131230817;
        public static int ConfigIBCDN2Warn = 2131230818;
        public static int ConfigIBCDN2WarnColor = 2131230819;
        public static int ConfigIBCDN2WarnHelp = 2131230820;
        public static int ConfigLtr = 2131230821;
        public static int ConfigMeter = 2131230822;
        public static int ConfigO2FirstStop2x = 2131230823;
        public static int ConfigO2FirstStop30sec = 2131230824;
        public static int ConfigO2Narcotic = 2131230825;
        public static int ConfigOTUAbove = 2131230826;
        public static int ConfigOTUAboveColor = 2131230827;
        public static int ConfigOTUAboveHelp = 2131230828;
        public static int ConfigReset = 2131230829;
        public static int ConfigRowAcclimHelp = 2131230830;
        public static int ConfigRowAddAllMix = 2131230831;
        public static int ConfigRowAddO2Window = 2131230832;
        public static int ConfigRowAddToStop = 2131230833;
        public static int ConfigRowAddToStopHelp = 2131230834;
        public static int ConfigRowAscentAsc = 2131230835;
        public static int ConfigRowAscentDeco = 2131230836;
        public static int ConfigRowAscentDescentHelp = 2131230837;
        public static int ConfigRowAscentSurf = 2131230838;
        public static int ConfigRowBottomRMV = 2131230839;
        public static int ConfigRowBottomRMVHelp = 2131230840;
        public static int ConfigRowCCRSetPoint = 2131230841;
        public static int ConfigRowCCRSetPointHelp = 2131230842;
        public static int ConfigRowCCRdilCheckSettings = 2131230843;
        public static int ConfigRowCCRdilCheckWarnHelp = 2131230844;
        public static int ConfigRowCNSAboveHelp = 2131230845;
        public static int ConfigRowCNSAboveSettings = 2131230846;
        public static int ConfigRowCircuit = 2131230847;
        public static int ConfigRowCircuitHelp = 2131230848;
        public static int ConfigRowConserve = 2131230849;
        public static int ConfigRowConserveDivider = 2131230850;
        public static int ConfigRowConserveGF = 2131230851;
        public static int ConfigRowConserveGFDivider = 2131230852;
        public static int ConfigRowConserveGFHelp = 2131230853;
        public static int ConfigRowConserveGFS = 2131230854;
        public static int ConfigRowConserveGFSDivider = 2131230855;
        public static int ConfigRowConserveGFSHelp = 2131230856;
        public static int ConfigRowConserveHelp = 2131230857;
        public static int ConfigRowDecoRMV = 2131230858;
        public static int ConfigRowDecoRMVHelp = 2131230859;
        public static int ConfigRowDescent = 2131230860;
        public static int ConfigRowElevation = 2131230861;
        public static int ConfigRowElevationAcclim = 2131230862;
        public static int ConfigRowElevationHelp = 2131230863;
        public static int ConfigRowExtend = 2131230864;
        public static int ConfigRowExtendAnyHelp = 2131230865;
        public static int ConfigRowExtendDeep = 2131230866;
        public static int ConfigRowExtendHelp = 2131230867;
        public static int ConfigRowExtendShallow = 2131230868;
        public static int ConfigRowFeetMeter = 2131230869;
        public static int ConfigRowFeetMeterHelp = 2131230870;
        public static int ConfigRowFirstStop2x = 2131230871;
        public static int ConfigRowFirstStop30sec = 2131230872;
        public static int ConfigRowFirstStopHelp = 2131230873;
        public static int ConfigRowGasVol = 2131230874;
        public static int ConfigRowGasVolHelp = 2131230875;
        public static int ConfigRowGuagetype = 2131230876;
        public static int ConfigRowGuagetypeHelp = 2131230877;
        public static int ConfigRowIBCDHeWarnHelp = 2131230878;
        public static int ConfigRowIBCDHeWarnSettings = 2131230879;
        public static int ConfigRowIBCDN2WarnHelp = 2131230880;
        public static int ConfigRowIBCDN2WarnSettings = 2131230881;
        public static int ConfigRowLastCCR = 2131230882;
        public static int ConfigRowLastOC = 2131230883;
        public static int ConfigRowModel = 2131230884;
        public static int ConfigRowNarcotic = 2131230885;
        public static int ConfigRowNarcoticHelp = 2131230886;
        public static int ConfigRowO2Depth = 2131230887;
        public static int ConfigRowO2DepthHelp = 2131230888;
        public static int ConfigRowOTUAboveHelp = 2131230889;
        public static int ConfigRowOTUAboveSettings = 2131230890;
        public static int ConfigRowStepSize = 2131230891;
        public static int ConfigRowStepSizeHelp = 2131230892;
        public static int ConfigRowStopTime = 2131230893;
        public static int ConfigRowStopTimeHelp = 2131230894;
        public static int ConfigRowVPMModelHelp = 2131230895;
        public static int ConfigRowWater = 2131230896;
        public static int ConfigRowWaterHelp = 2131230897;
        public static int ConfigRowppO2AboveHelp = 2131230898;
        public static int ConfigRowppO2AboveSettings = 2131230899;
        public static int ConfigRowppO2BelowHelp = 2131230900;
        public static int ConfigRowppO2BelowSettings = 2131230901;
        public static int ConfigRowppO2Swap = 2131230902;
        public static int ConfigRowppO2Swap14 = 2131230903;
        public static int ConfigRowppO2Swap15 = 2131230904;
        public static int ConfigRowppO2SwapHelp = 2131230905;
        public static int ConfigSalt = 2131230906;
        public static int ConfigScrollView = 2131230907;
        public static int ConfigTextFirstStop2x = 2131230908;
        public static int ConfigToggleCCRDilCheck = 2131230909;
        public static int ConfigToggleCNSAbove = 2131230910;
        public static int ConfigToggleIBCDHeWarn = 2131230911;
        public static int ConfigToggleIBCDN2Warn = 2131230912;
        public static int ConfigToggleOTUAbove = 2131230913;
        public static int ConfigToggleppO2Above = 2131230914;
        public static int ConfigToggleppO2Below = 2131230915;
        public static int ConfigppO2Above = 2131230916;
        public static int ConfigppO2AboveColor = 2131230917;
        public static int ConfigppO2AboveHelp = 2131230918;
        public static int ConfigppO2Below = 2131230919;
        public static int ConfigppO2BelowColor = 2131230920;
        public static int ConfigppO2BelowHelp = 2131230921;
        public static int DensityRowDepth = 2131230922;
        public static int DensityRowO2He = 2131230923;
        public static int DensityRowOCSP = 2131230924;
        public static int DensityRowResult = 2131230925;
        public static int DensityRowResultATA = 2131230926;
        public static int DensityRowResultgrams = 2131230927;
        public static int DensityRowSP = 2131230928;
        public static int DensityRowTemp = 2131230929;
        public static int EADMODRowDepth = 2131230930;
        public static int EADMODRowMix = 2131230931;
        public static int EADMODRowO2He = 2131230932;
        public static int EADMODRowResultEADHelp = 2131230933;
        public static int EADMODRowResultEADLabels = 2131230934;
        public static int EADMODRowResultEADs = 2131230935;
        public static int EADMODRowResultMOD = 2131230936;
        public static int EADMODRowSP = 2131230937;
        public static int EADMODRowppO2 = 2131230938;
        public static int FromPBailOCmix0 = 2131230940;
        public static int FromPBailOCmix1 = 2131230941;
        public static int FromPBailOCmix2 = 2131230942;
        public static int FromPBailOCmix3 = 2131230943;
        public static int FromPMaxOCmix0 = 2131230944;
        public static int FromPMaxOCmix1 = 2131230945;
        public static int FromPMaxOCmix2 = 2131230946;
        public static int FromPMaxOCmix3 = 2131230947;
        public static int FromPMaxOCmix4 = 2131230948;
        public static int FromPMaxOCmix5 = 2131230949;
        public static int FromPMaxOCmix6 = 2131230950;
        public static int FromPMaxOCmix7 = 2131230951;
        public static int LinearLayout02 = 2131230952;
        public static int LinearLayout03 = 2131230953;
        public static int LinearLayout04 = 2131230954;
        public static int LinearLayout05 = 2131230955;
        public static int LinearLayout06 = 2131230956;
        public static int LinearLayoutBannerTop = 2131230957;
        public static int LinearLayoutCalc = 2131230958;
        public static int LinearLayoutConfigBtm = 2131230959;
        public static int LinearLayoutLevelsDeco = 2131230960;
        public static int MixBailOCfromheader = 2131230962;
        public static int MixBailOCmix0 = 2131230963;
        public static int MixBailOCmix1 = 2131230964;
        public static int MixBailOCmix2 = 2131230965;
        public static int MixBailOCmix3 = 2131230966;
        public static int MixBailOCmixheader = 2131230967;
        public static int MixBailOCtankheader = 2131230968;
        public static int MixBailOCtoheader = 2131230969;
        public static int MixMaxOCfromheader = 2131230970;
        public static int MixMaxOCmix0 = 2131230971;
        public static int MixMaxOCmix1 = 2131230972;
        public static int MixMaxOCmix2 = 2131230973;
        public static int MixMaxOCmix3 = 2131230974;
        public static int MixMaxOCmix4 = 2131230975;
        public static int MixMaxOCmix5 = 2131230976;
        public static int MixMaxOCmix6 = 2131230977;
        public static int MixMaxOCmix7 = 2131230978;
        public static int MixMaxOCmixheader = 2131230979;
        public static int MixMaxOCtankheader = 2131230980;
        public static int MixMaxOCtoheader = 2131230981;
        public static int OCMaxTimeplan = 2131230983;
        public static int OCMaxtimeplanSetup = 2131230984;
        public static int OCRowMaxTimeHelp = 2131230985;
        public static int RegRowButtons = 2131230986;
        public static int RegRowExisting = 2131230987;
        public static int ResultButtons = 2131230988;
        public static int ResultLayout = 2131230989;
        public static int ResultScrollView = 2131230990;
        public static int ScrollViewDecos = 2131230996;
        public static int ScrollViewLevels = 2131230997;
        public static int SpinnerDecoSwap = 2131230998;
        public static int SpinnerDepth = 2131230999;
        public static int SpinnerHe = 2131231000;
        public static int SpinnerO2 = 2131231001;
        public static int SpinnerSP = 2131231002;
        public static int SpinnerTime = 2131231003;
        public static int SurfIntButtonCancel = 2131231004;
        public static int SurfIntButtonSave = 2131231005;
        public static int SurfIntDay = 2131231006;
        public static int SurfIntHour = 2131231007;
        public static int SurfIntMin = 2131231008;
        public static int TableBailOCmix = 2131231009;
        public static int TableBailOCmix0 = 2131231010;
        public static int TableBailOCmix1 = 2131231011;
        public static int TableBailOCmix2 = 2131231012;
        public static int TableBailOCmix3 = 2131231013;
        public static int TableBailOCmixes = 2131231014;
        public static int TableBailOCmixheader = 2131231015;
        public static int TableDecos = 2131231016;
        public static int TableLayout01 = 2131231017;
        public static int TableLayout02 = 2131231018;
        public static int TableLayoutSPOCSCR = 2131231019;
        public static int TableLevels = 2131231020;
        public static int TableMaxOCmix0 = 2131231021;
        public static int TableMaxOCmix1 = 2131231022;
        public static int TableMaxOCmix2 = 2131231023;
        public static int TableMaxOCmix3 = 2131231024;
        public static int TableMaxOCmix4 = 2131231025;
        public static int TableMaxOCmix5 = 2131231026;
        public static int TableMaxOCmix6 = 2131231027;
        public static int TableMaxOCmix7 = 2131231028;
        public static int TableMaxOCmixes = 2131231029;
        public static int TableMaxOCmixheader = 2131231030;
        public static int TableRowDepth = 2131231031;
        public static int TableRowHe = 2131231032;
        public static int TableRowO2 = 2131231033;
        public static int TableRowOCSCR = 2131231034;
        public static int TableRowSP = 2131231035;
        public static int TableRowTime = 2131231036;
        public static int TanksBailOCmix0 = 2131231037;
        public static int TanksBailOCmix1 = 2131231038;
        public static int TanksBailOCmix2 = 2131231039;
        public static int TanksBailOCmix3 = 2131231040;
        public static int TanksMaxOCmix0 = 2131231041;
        public static int TanksMaxOCmix1 = 2131231042;
        public static int TanksMaxOCmix2 = 2131231043;
        public static int TanksMaxOCmix3 = 2131231044;
        public static int TanksMaxOCmix4 = 2131231045;
        public static int TanksMaxOCmix5 = 2131231046;
        public static int TanksMaxOCmix6 = 2131231047;
        public static int TanksMaxOCmix7 = 2131231048;
        public static int TextDensityATA = 2131231049;
        public static int TextDensitySP = 2131231050;
        public static int TextDensitygrams = 2131231051;
        public static int TextEadModSP = 2131231052;
        public static int TextEadModppO2 = 2131231053;
        public static int TextEnterRegKey = 2131231054;
        public static int TextInstallCode = 2131231055;
        public static int TextRegDescript = 2131231056;
        public static int TextRegNewKey = 2131231057;
        public static int TextRegTitle = 2131231058;
        public static int TextViewAboutProgram_version = 2131231059;
        public static int TextViewAgreeTitle = 2131231060;
        public static int TextViewBailoutSettings = 2131231061;
        public static int TextViewConfig = 2131231062;
        public static int TextViewDeco = 2131231063;
        public static int TextViewDepth = 2131231064;
        public static int TextViewDiveMonitorSettings = 2131231065;
        public static int TextViewExtendSettings = 2131231066;
        public static int TextViewHe = 2131231067;
        public static int TextViewLevelTitle = 2131231068;
        public static int TextViewLevels = 2131231069;
        public static int TextViewLicense = 2131231070;
        public static int TextViewModelSettings = 2131231071;
        public static int TextViewO2 = 2131231072;
        public static int TextViewOCorSCR = 2131231073;
        public static int TextViewReport = 2131231074;
        public static int TextViewSP = 2131231075;
        public static int TextViewStopAscentdescentSettings = 2131231076;
        public static int TextViewStopElevationSettings = 2131231077;
        public static int TextViewStopMixSettings = 2131231078;
        public static int TextViewTime = 2131231079;
        public static int TextViewUnitSettings = 2131231080;
        public static int Textcapacity = 2131231081;
        public static int TextcapacityAddPress = 2131231082;
        public static int TextcapacityResult = 2131231083;
        public static int Textcapacitystartpress = 2131231084;
        public static int Textcapacitytanksizes = 2131231085;
        public static int Textnitroxaddair = 2131231086;
        public static int Textnitroxaddo2 = 2131231087;
        public static int Textnitroxfinish = 2131231088;
        public static int Textnitroxo2 = 2131231089;
        public static int Textnitroxpress = 2131231090;
        public static int Textnitroxstart = 2131231091;
        public static int Texttopupfinish = 2131231092;
        public static int Texttopuphe = 2131231093;
        public static int Texttopupo2 = 2131231094;
        public static int Texttopuppress = 2131231095;
        public static int Texttopupresult = 2131231096;
        public static int Texttopupstart = 2131231097;
        public static int Texttopupwith = 2131231098;
        public static int TexttrimixReceive = 2131231099;
        public static int Texttrimixadd1st = 2131231100;
        public static int Texttrimixadd2nd = 2131231101;
        public static int Texttrimixaddair = 2131231102;
        public static int Texttrimixaddfirst = 2131231103;
        public static int Texttrimixfinish = 2131231104;
        public static int Texttrimixhe = 2131231105;
        public static int Texttrimixo2 = 2131231106;
        public static int Texttrimixpress = 2131231107;
        public static int Texttrimixstart = 2131231108;
        public static int Texttrimixtesto2 = 2131231109;
        public static int ToPBailOCmix0 = 2131231110;
        public static int ToPBailOCmix1 = 2131231111;
        public static int ToPBailOCmix2 = 2131231112;
        public static int ToPBailOCmix3 = 2131231113;
        public static int ToPMaxOCmix0 = 2131231114;
        public static int ToPMaxOCmix1 = 2131231115;
        public static int ToPMaxOCmix2 = 2131231116;
        public static int ToPMaxOCmix3 = 2131231117;
        public static int ToPMaxOCmix4 = 2131231118;
        public static int ToPMaxOCmix5 = 2131231119;
        public static int ToPMaxOCmix6 = 2131231120;
        public static int ToPMaxOCmix7 = 2131231121;
        public static int TrimixScrollView = 2131231122;
        public static int ViewDivider = 2131231123;
        public static int ViewDivider2 = 2131231124;
        public static int bailBottomRMV = 2131231198;
        public static int bailConserve = 2131231199;
        public static int bailConserveGFHi = 2131231200;
        public static int bailConserveGFLo = 2131231201;
        public static int bailConserveGFS = 2131231202;
        public static int bailModel = 2131231203;
        public static int bestmix = 2131231210;
        public static int bestmixDepth = 2131231211;
        public static int bestmixTrimix = 2131231212;
        public static int bestmixppO2 = 2131231213;
        public static int bestmixtrimixead = 2131231214;
        public static int buttonResultNext = 2131231222;
        public static int buttonResultReport = 2131231223;
        public static int capacityRowAddPress = 2131231226;
        public static int capacityRowEqualize = 2131231227;
        public static int capacityRowPress = 2131231228;
        public static int capacityRowResult = 2131231229;
        public static int capacityRowStartPress = 2131231230;
        public static int capacityreceiveaddpress = 2131231231;
        public static int capacityreceiveresult = 2131231232;
        public static int capacityreceivesize = 2131231233;
        public static int capacityreceivestartpress = 2131231234;
        public static int capacitysupplyresult = 2131231235;
        public static int capacitysupplysize = 2131231236;
        public static int capacitysupplystartpress = 2131231237;
        public static int checkBoxDoubletank = 2131231244;
        public static int checkbox0 = 2131231246;
        public static int checkbox1 = 2131231247;
        public static int checkbox2 = 2131231248;
        public static int checkbox3 = 2131231249;
        public static int checkbox4 = 2131231250;
        public static int checkbox5 = 2131231251;
        public static int configBottomRMV = 2131231257;
        public static int configConserve = 2131231258;
        public static int configConserveGFHi = 2131231259;
        public static int configConserveGFLo = 2131231260;
        public static int configConserveGFS = 2131231261;
        public static int configDecoRMV = 2131231262;
        public static int configExtendDeep = 2131231263;
        public static int configLastCCR = 2131231264;
        public static int configLastOC = 2131231265;
        public static int configModel = 2131231266;
        public static int configO2Depth = 2131231267;
        public static int configStepSize = 2131231268;
        public static int configStopTime = 2131231269;
        public static int configppO2Swap14 = 2131231270;
        public static int configppO2Swap15 = 2131231271;
        public static int configppO2Swap16 = 2131231272;
        public static int deletetablerow01 = 2131231285;
        public static int deletetablerow02 = 2131231286;
        public static int deletetablerow03 = 2131231287;
        public static int deletetablerow04 = 2131231288;
        public static int deletetablerow05 = 2131231289;
        public static int deletetablerow06 = 2131231290;
        public static int densityATA = 2131231292;
        public static int densityDepth = 2131231293;
        public static int densityGrams = 2131231294;
        public static int densityHe = 2131231295;
        public static int densityMix = 2131231296;
        public static int densityO2 = 2131231297;
        public static int densityOC = 2131231298;
        public static int densitySP = 2131231299;
        public static int densitypO2 = 2131231300;
        public static int densitytemp0 = 2131231301;
        public static int densitytemp20 = 2131231302;
        public static int ead = 2131231319;
        public static int eadd = 2131231320;
        public static int eaddhelp = 2131231321;
        public static int eadhelp = 2131231322;
        public static int eadmodDepth = 2131231323;
        public static int eadmodHe = 2131231324;
        public static int eadmodO2 = 2131231325;
        public static int eadmodSP = 2131231326;
        public static int eadmodead = 2131231327;
        public static int eadmodeadd = 2131231328;
        public static int eadmodend = 2131231329;
        public static int eadmodmod = 2131231330;
        public static int eadmodppO2 = 2131231331;
        public static int editTextPressFull = 2131231336;
        public static int editTextTankName = 2131231337;
        public static int end = 2131231340;
        public static int endhelp = 2131231341;
        public static int imageBtnAddTank = 2131231366;
        public static int imageBtnConfig = 2131231367;
        public static int imageBtnDeleteTank = 2131231368;
        public static int imageBtnResultCopy = 2131231369;
        public static int imageBtnResultEmail = 2131231370;
        public static int imageBtnResultWebFAQ = 2131231371;
        public static int imageBtnTools = 2131231372;
        public static int listViewTanks = 2131231387;
        public static int mixBanked32 = 2131231393;
        public static int mixBankedAir = 2131231394;
        public static int mixerBar = 2131231395;
        public static int mixerC = 2131231396;
        public static int mixerF = 2131231397;
        public static int mixerPSI = 2131231398;
        public static int mixerRowBanked32 = 2131231399;
        public static int mixerRowConfig = 2131231400;
        public static int mixerRowTemp = 2131231401;
        public static int mixerTemp = 2131231402;
        public static int mixer_capacity_xml = 2131231403;
        public static int mixer_config_xml = 2131231404;
        public static int mixer_density_xml = 2131231405;
        public static int mixer_nitrox_xml = 2131231406;
        public static int mixer_topup_xml = 2131231407;
        public static int mixer_trimix_xml = 2131231408;
        public static int mod = 2131231409;
        public static int modhelp = 2131231410;
        public static int multideco_about_xml = 2131231412;
        public static int multideco_agree_xml = 2131231413;
        public static int multideco_bail_xml = 2131231414;
        public static int multideco_bestmix_xml = 2131231415;
        public static int multideco_config_xml = 2131231416;
        public static int multideco_deco_xml = 2131231417;
        public static int multideco_eadmod_xml = 2131231418;
        public static int multideco_level = 2131231419;
        public static int multideco_level_xml = 2131231420;
        public static int multideco_main_xml = 2131231421;
        public static int multideco_maxtime_xml = 2131231422;
        public static int multideco_registration_xml = 2131231423;
        public static int multideco_report_xml = 2131231424;
        public static int multideco_result_xml = 2131231425;
        public static int multideco_surfint_xml = 2131231426;
        public static int nitroxRowO2 = 2131231431;
        public static int nitroxRowPress = 2131231432;
        public static int nitroxRowResultaddair = 2131231433;
        public static int nitroxRowResultaddo2 = 2131231434;
        public static int nitroxaddair = 2131231435;
        public static int nitroxaddo2 = 2131231436;
        public static int nitroxo2new = 2131231437;
        public static int nitroxo2old = 2131231438;
        public static int nitroxpressnew = 2131231439;
        public static int nitroxpressold = 2131231440;
        public static int radioBtnCuFt = 2131231464;
        public static int radioBtnLiter = 2131231465;
        public static int radioBtnTankBAR = 2131231466;
        public static int radioBtnTankPSI = 2131231467;
        public static int radioGroupSetTankPress = 2131231468;
        public static int radioGroupSetankVol = 2131231469;
        public static int regRowregkey = 2131231472;
        public static int reginstallcode = 2131231473;
        public static int regkey1 = 2131231474;
        public static int regkey2 = 2131231475;
        public static int regkey3 = 2131231476;
        public static int scrollView1 = 2131231487;
        public static int settank_xml = 2131231499;
        public static int textViewPressFull = 2131231548;
        public static int textViewTankName = 2131231549;
        public static int textViewTanks = 2131231550;
        public static int textViewTanksIntro = 2131231551;
        public static int topupRowHe = 2131231559;
        public static int topupRowO2 = 2131231560;
        public static int topupRowPress = 2131231561;
        public static int topupRowResultaddhe = 2131231562;
        public static int topupRowWithO2 = 2131231563;
        public static int topupScrollView = 2131231564;
        public static int topuphenew = 2131231565;
        public static int topupheold = 2131231566;
        public static int topupo2new = 2131231567;
        public static int topupo2old = 2131231568;
        public static int topuppressnew = 2131231569;
        public static int topuppressold = 2131231570;
        public static int topupresult = 2131231571;
        public static int topupwithhe = 2131231572;
        public static int topupwitho2 = 2131231573;
        public static int trimixAddfirstHe = 2131231577;
        public static int trimixAddfirstO2 = 2131231578;
        public static int trimixRowAddFirst = 2131231579;
        public static int trimixRowHe = 2131231580;
        public static int trimixRowO2 = 2131231581;
        public static int trimixRowPress = 2131231582;
        public static int trimixRowResultaddair = 2131231583;
        public static int trimixRowResultaddhe = 2131231584;
        public static int trimixRowResultaddo2 = 2131231585;
        public static int trimixRowResulttesto2 = 2131231586;
        public static int trimixaddair = 2131231587;
        public static int trimixaddhe = 2131231588;
        public static int trimixaddo2 = 2131231589;
        public static int trimixhenew = 2131231590;
        public static int trimixheold = 2131231591;
        public static int trimixo2new = 2131231592;
        public static int trimixo2old = 2131231593;
        public static int trimixpressnew = 2131231594;
        public static int trimixpressold = 2131231595;
        public static int trimixtesto2 = 2131231596;
        public static int viewDividerSetTank1 = 2131231603;
        public static int viewDividerSetTank2 = 2131231604;
        public static int viewDividerSetTank3 = 2131231605;

        /* JADX INFO: Added by JADX */
        public static final int ALT = 2131230720;

        /* JADX INFO: Added by JADX */
        public static final int CTRL = 2131230776;

        /* JADX INFO: Added by JADX */
        public static final int FUNCTION = 2131230939;

        /* JADX INFO: Added by JADX */
        public static final int META = 2131230961;

        /* JADX INFO: Added by JADX */
        public static final int NO_DEBUG = 2131230982;

        /* JADX INFO: Added by JADX */
        public static final int SHIFT = 2131230991;

        /* JADX INFO: Added by JADX */
        public static final int SHOW_ALL = 2131230992;

        /* JADX INFO: Added by JADX */
        public static final int SHOW_PATH = 2131230993;

        /* JADX INFO: Added by JADX */
        public static final int SHOW_PROGRESS = 2131230994;

        /* JADX INFO: Added by JADX */
        public static final int SYM = 2131230995;

        /* JADX INFO: Added by JADX */
        public static final int above = 2131231125;

        /* JADX INFO: Added by JADX */
        public static final int accelerate = 2131231126;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_action_clickable_span = 2131231127;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_0 = 2131231128;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_1 = 2131231129;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_10 = 2131231130;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_11 = 2131231131;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_12 = 2131231132;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_13 = 2131231133;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_14 = 2131231134;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_15 = 2131231135;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_16 = 2131231136;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_17 = 2131231137;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_18 = 2131231138;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_19 = 2131231139;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_2 = 2131231140;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_20 = 2131231141;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_21 = 2131231142;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_22 = 2131231143;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_23 = 2131231144;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_24 = 2131231145;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_25 = 2131231146;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_26 = 2131231147;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_27 = 2131231148;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_28 = 2131231149;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_29 = 2131231150;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_3 = 2131231151;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_30 = 2131231152;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_31 = 2131231153;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_4 = 2131231154;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_5 = 2131231155;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_6 = 2131231156;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_7 = 2131231157;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_8 = 2131231158;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_9 = 2131231159;

        /* JADX INFO: Added by JADX */
        public static final int actionDown = 2131231160;

        /* JADX INFO: Added by JADX */
        public static final int actionDownUp = 2131231161;

        /* JADX INFO: Added by JADX */
        public static final int actionUp = 2131231162;

        /* JADX INFO: Added by JADX */
        public static final int action_bar = 2131231163;

        /* JADX INFO: Added by JADX */
        public static final int action_bar_activity_content = 2131231164;

        /* JADX INFO: Added by JADX */
        public static final int action_bar_container = 2131231165;

        /* JADX INFO: Added by JADX */
        public static final int action_bar_root = 2131231166;

        /* JADX INFO: Added by JADX */
        public static final int action_bar_spinner = 2131231167;

        /* JADX INFO: Added by JADX */
        public static final int action_bar_subtitle = 2131231168;

        /* JADX INFO: Added by JADX */
        public static final int action_bar_title = 2131231169;

        /* JADX INFO: Added by JADX */
        public static final int action_container = 2131231170;

        /* JADX INFO: Added by JADX */
        public static final int action_context_bar = 2131231171;

        /* JADX INFO: Added by JADX */
        public static final int action_divider = 2131231172;

        /* JADX INFO: Added by JADX */
        public static final int action_image = 2131231173;

        /* JADX INFO: Added by JADX */
        public static final int action_menu_divider = 2131231174;

        /* JADX INFO: Added by JADX */
        public static final int action_menu_presenter = 2131231175;

        /* JADX INFO: Added by JADX */
        public static final int action_mode_bar = 2131231176;

        /* JADX INFO: Added by JADX */
        public static final int action_mode_bar_stub = 2131231177;

        /* JADX INFO: Added by JADX */
        public static final int action_mode_close_button = 2131231178;

        /* JADX INFO: Added by JADX */
        public static final int action_text = 2131231179;

        /* JADX INFO: Added by JADX */
        public static final int actions = 2131231180;

        /* JADX INFO: Added by JADX */
        public static final int activity_chooser_view_content = 2131231181;

        /* JADX INFO: Added by JADX */
        public static final int add = 2131231182;

        /* JADX INFO: Added by JADX */
        public static final int alertTitle = 2131231183;

        /* JADX INFO: Added by JADX */
        public static final int aligned = 2131231184;

        /* JADX INFO: Added by JADX */
        public static final int allStates = 2131231185;

        /* JADX INFO: Added by JADX */
        public static final int always = 2131231186;

        /* JADX INFO: Added by JADX */
        public static final int animateToEnd = 2131231187;

        /* JADX INFO: Added by JADX */
        public static final int animateToStart = 2131231188;

        /* JADX INFO: Added by JADX */
        public static final int antiClockwise = 2131231189;

        /* JADX INFO: Added by JADX */
        public static final int anticipate = 2131231190;

        /* JADX INFO: Added by JADX */
        public static final int asConfigured = 2131231191;

        /* JADX INFO: Added by JADX */
        public static final int async = 2131231192;

        /* JADX INFO: Added by JADX */
        public static final int auto = 2131231193;

        /* JADX INFO: Added by JADX */
        public static final int autoComplete = 2131231194;

        /* JADX INFO: Added by JADX */
        public static final int autoCompleteToEnd = 2131231195;

        /* JADX INFO: Added by JADX */
        public static final int autoCompleteToStart = 2131231196;

        /* JADX INFO: Added by JADX */
        public static final int axisRelative = 2131231197;

        /* JADX INFO: Added by JADX */
        public static final int barrier = 2131231204;

        /* JADX INFO: Added by JADX */
        public static final int baseline = 2131231205;

        /* JADX INFO: Added by JADX */
        public static final int beginOnFirstDraw = 2131231206;

        /* JADX INFO: Added by JADX */
        public static final int beginning = 2131231207;

        /* JADX INFO: Added by JADX */
        public static final int below = 2131231208;

        /* JADX INFO: Added by JADX */
        public static final int bestChoice = 2131231209;

        /* JADX INFO: Added by JADX */
        public static final int blocking = 2131231215;

        /* JADX INFO: Added by JADX */
        public static final int bottom = 2131231216;

        /* JADX INFO: Added by JADX */
        public static final int bounce = 2131231217;

        /* JADX INFO: Added by JADX */
        public static final int bounceBoth = 2131231218;

        /* JADX INFO: Added by JADX */
        public static final int bounceEnd = 2131231219;

        /* JADX INFO: Added by JADX */
        public static final int bounceStart = 2131231220;

        /* JADX INFO: Added by JADX */
        public static final int buttonPanel = 2131231221;

        /* JADX INFO: Added by JADX */
        public static final int cache_measures = 2131231224;

        /* JADX INFO: Added by JADX */
        public static final int callMeasure = 2131231225;

        /* JADX INFO: Added by JADX */
        public static final int carryVelocity = 2131231238;

        /* JADX INFO: Added by JADX */
        public static final int center = 2131231239;

        /* JADX INFO: Added by JADX */
        public static final int center_vertical = 2131231240;

        /* JADX INFO: Added by JADX */
        public static final int chain = 2131231241;

        /* JADX INFO: Added by JADX */
        public static final int chain2 = 2131231242;

        /* JADX INFO: Added by JADX */
        public static final int chains = 2131231243;

        /* JADX INFO: Added by JADX */
        public static final int checkbox = 2131231245;

        /* JADX INFO: Added by JADX */
        public static final int checked = 2131231252;

        /* JADX INFO: Added by JADX */
        public static final int chronometer = 2131231253;

        /* JADX INFO: Added by JADX */
        public static final int clockwise = 2131231254;

        /* JADX INFO: Added by JADX */
        public static final int closest = 2131231255;

        /* JADX INFO: Added by JADX */
        public static final int collapseActionView = 2131231256;

        /* JADX INFO: Added by JADX */
        public static final int constraint = 2131231273;

        /* JADX INFO: Added by JADX */
        public static final int content = 2131231274;

        /* JADX INFO: Added by JADX */
        public static final int contentPanel = 2131231275;

        /* JADX INFO: Added by JADX */
        public static final int continuousVelocity = 2131231276;

        /* JADX INFO: Added by JADX */
        public static final int cos = 2131231277;

        /* JADX INFO: Added by JADX */
        public static final int currentState = 2131231278;

        /* JADX INFO: Added by JADX */
        public static final int custom = 2131231279;

        /* JADX INFO: Added by JADX */
        public static final int customPanel = 2131231280;

        /* JADX INFO: Added by JADX */
        public static final int decelerate = 2131231281;

        /* JADX INFO: Added by JADX */
        public static final int decelerateAndComplete = 2131231282;

        /* JADX INFO: Added by JADX */
        public static final int decor_content_parent = 2131231283;

        /* JADX INFO: Added by JADX */
        public static final int default_activity_button = 2131231284;

        /* JADX INFO: Added by JADX */
        public static final int deltaRelative = 2131231291;

        /* JADX INFO: Added by JADX */
        public static final int dependency_ordering = 2131231303;

        /* JADX INFO: Added by JADX */
        public static final int dialog_button = 2131231304;

        /* JADX INFO: Added by JADX */
        public static final int dimensions = 2131231305;

        /* JADX INFO: Added by JADX */
        public static final int direct = 2131231306;

        /* JADX INFO: Added by JADX */
        public static final int disableHome = 2131231307;

        /* JADX INFO: Added by JADX */
        public static final int disableIntraAutoTransition = 2131231308;

        /* JADX INFO: Added by JADX */
        public static final int disablePostScroll = 2131231309;

        /* JADX INFO: Added by JADX */
        public static final int disableScroll = 2131231310;

        /* JADX INFO: Added by JADX */
        public static final int dragAnticlockwise = 2131231311;

        /* JADX INFO: Added by JADX */
        public static final int dragClockwise = 2131231312;

        /* JADX INFO: Added by JADX */
        public static final int dragDown = 2131231313;

        /* JADX INFO: Added by JADX */
        public static final int dragEnd = 2131231314;

        /* JADX INFO: Added by JADX */
        public static final int dragLeft = 2131231315;

        /* JADX INFO: Added by JADX */
        public static final int dragRight = 2131231316;

        /* JADX INFO: Added by JADX */
        public static final int dragStart = 2131231317;

        /* JADX INFO: Added by JADX */
        public static final int dragUp = 2131231318;

        /* JADX INFO: Added by JADX */
        public static final int easeIn = 2131231332;

        /* JADX INFO: Added by JADX */
        public static final int easeInOut = 2131231333;

        /* JADX INFO: Added by JADX */
        public static final int easeOut = 2131231334;

        /* JADX INFO: Added by JADX */
        public static final int east = 2131231335;

        /* JADX INFO: Added by JADX */
        public static final int edit_query = 2131231338;

        /* JADX INFO: Added by JADX */
        public static final int edit_text_id = 2131231339;

        /* JADX INFO: Added by JADX */
        public static final int expand_activities_button = 2131231342;

        /* JADX INFO: Added by JADX */
        public static final int expanded_menu = 2131231343;

        /* JADX INFO: Added by JADX */
        public static final int flip = 2131231344;

        /* JADX INFO: Added by JADX */
        public static final int forever = 2131231345;

        /* JADX INFO: Added by JADX */
        public static final int fragment_container_view_tag = 2131231346;

        /* JADX INFO: Added by JADX */
        public static final int frost = 2131231347;

        /* JADX INFO: Added by JADX */
        public static final int gone = 2131231348;

        /* JADX INFO: Added by JADX */
        public static final int graph = 2131231349;

        /* JADX INFO: Added by JADX */
        public static final int graph_wrap = 2131231350;

        /* JADX INFO: Added by JADX */
        public static final int group_divider = 2131231351;

        /* JADX INFO: Added by JADX */
        public static final int grouping = 2131231352;

        /* JADX INFO: Added by JADX */
        public static final int groups = 2131231353;

        /* JADX INFO: Added by JADX */
        public static final int hide_ime_id = 2131231354;

        /* JADX INFO: Added by JADX */
        public static final int home = 2131231355;

        /* JADX INFO: Added by JADX */
        public static final int homeAsUp = 2131231356;

        /* JADX INFO: Added by JADX */
        public static final int honorRequest = 2131231357;

        /* JADX INFO: Added by JADX */
        public static final int horizontal = 2131231358;

        /* JADX INFO: Added by JADX */
        public static final int horizontal_only = 2131231359;

        /* JADX INFO: Added by JADX */
        public static final int icon = 2131231360;

        /* JADX INFO: Added by JADX */
        public static final int icon_group = 2131231361;

        /* JADX INFO: Added by JADX */
        public static final int ifRoom = 2131231362;

        /* JADX INFO: Added by JADX */
        public static final int ignore = 2131231363;

        /* JADX INFO: Added by JADX */
        public static final int ignoreRequest = 2131231364;

        /* JADX INFO: Added by JADX */
        public static final int image = 2131231365;

        /* JADX INFO: Added by JADX */
        public static final int immediateStop = 2131231373;

        /* JADX INFO: Added by JADX */
        public static final int included = 2131231374;

        /* JADX INFO: Added by JADX */
        public static final int info = 2131231375;

        /* JADX INFO: Added by JADX */
        public static final int invisible = 2131231376;

        /* JADX INFO: Added by JADX */
        public static final int italic = 2131231377;

        /* JADX INFO: Added by JADX */
        public static final int jumpToEnd = 2131231378;

        /* JADX INFO: Added by JADX */
        public static final int jumpToStart = 2131231379;

        /* JADX INFO: Added by JADX */
        public static final int layout = 2131231380;

        /* JADX INFO: Added by JADX */
        public static final int left = 2131231381;

        /* JADX INFO: Added by JADX */
        public static final int legacy = 2131231382;

        /* JADX INFO: Added by JADX */
        public static final int line1 = 2131231383;

        /* JADX INFO: Added by JADX */
        public static final int line3 = 2131231384;

        /* JADX INFO: Added by JADX */
        public static final int linear = 2131231385;

        /* JADX INFO: Added by JADX */
        public static final int listMode = 2131231386;

        /* JADX INFO: Added by JADX */
        public static final int list_item = 2131231388;

        /* JADX INFO: Added by JADX */
        public static final int match_constraint = 2131231389;

        /* JADX INFO: Added by JADX */
        public static final int match_parent = 2131231390;

        /* JADX INFO: Added by JADX */
        public static final int message = 2131231391;

        /* JADX INFO: Added by JADX */
        public static final int middle = 2131231392;

        /* JADX INFO: Added by JADX */
        public static final int motion_base = 2131231411;

        /* JADX INFO: Added by JADX */
        public static final int multiply = 2131231427;

        /* JADX INFO: Added by JADX */
        public static final int never = 2131231428;

        /* JADX INFO: Added by JADX */
        public static final int neverCompleteToEnd = 2131231429;

        /* JADX INFO: Added by JADX */
        public static final int neverCompleteToStart = 2131231430;

        /* JADX INFO: Added by JADX */
        public static final int noState = 2131231441;

        /* JADX INFO: Added by JADX */
        public static final int none = 2131231442;

        /* JADX INFO: Added by JADX */
        public static final int normal = 2131231443;

        /* JADX INFO: Added by JADX */
        public static final int north = 2131231444;

        /* JADX INFO: Added by JADX */
        public static final int notification_background = 2131231445;

        /* JADX INFO: Added by JADX */
        public static final int notification_main_column = 2131231446;

        /* JADX INFO: Added by JADX */
        public static final int notification_main_column_container = 2131231447;

        /* JADX INFO: Added by JADX */
        public static final int off = 2131231448;

        /* JADX INFO: Added by JADX */
        public static final int on = 2131231449;

        /* JADX INFO: Added by JADX */
        public static final int onInterceptTouchReturnSwipe = 2131231450;

        /* JADX INFO: Added by JADX */
        public static final int overshoot = 2131231451;

        /* JADX INFO: Added by JADX */
        public static final int packed = 2131231452;

        /* JADX INFO: Added by JADX */
        public static final int parent = 2131231453;

        /* JADX INFO: Added by JADX */
        public static final int parentPanel = 2131231454;

        /* JADX INFO: Added by JADX */
        public static final int parentRelative = 2131231455;

        /* JADX INFO: Added by JADX */
        public static final int path = 2131231456;

        /* JADX INFO: Added by JADX */
        public static final int pathRelative = 2131231457;

        /* JADX INFO: Added by JADX */
        public static final int percent = 2131231458;

        /* JADX INFO: Added by JADX */
        public static final int position = 2131231459;

        /* JADX INFO: Added by JADX */
        public static final int postLayout = 2131231460;

        /* JADX INFO: Added by JADX */
        public static final int progress_circular = 2131231461;

        /* JADX INFO: Added by JADX */
        public static final int progress_horizontal = 2131231462;

        /* JADX INFO: Added by JADX */
        public static final int radio = 2131231463;

        /* JADX INFO: Added by JADX */
        public static final int ratio = 2131231470;

        /* JADX INFO: Added by JADX */
        public static final int rectangles = 2131231471;

        /* JADX INFO: Added by JADX */
        public static final int report_drawn = 2131231477;

        /* JADX INFO: Added by JADX */
        public static final int reverseSawtooth = 2131231478;

        /* JADX INFO: Added by JADX */
        public static final int right = 2131231479;

        /* JADX INFO: Added by JADX */
        public static final int right_icon = 2131231480;

        /* JADX INFO: Added by JADX */
        public static final int right_side = 2131231481;

        /* JADX INFO: Added by JADX */
        public static final int sawtooth = 2131231482;

        /* JADX INFO: Added by JADX */
        public static final int screen = 2131231483;

        /* JADX INFO: Added by JADX */
        public static final int scrollIndicatorDown = 2131231484;

        /* JADX INFO: Added by JADX */
        public static final int scrollIndicatorUp = 2131231485;

        /* JADX INFO: Added by JADX */
        public static final int scrollView = 2131231486;

        /* JADX INFO: Added by JADX */
        public static final int search_badge = 2131231488;

        /* JADX INFO: Added by JADX */
        public static final int search_bar = 2131231489;

        /* JADX INFO: Added by JADX */
        public static final int search_button = 2131231490;

        /* JADX INFO: Added by JADX */
        public static final int search_close_btn = 2131231491;

        /* JADX INFO: Added by JADX */
        public static final int search_edit_frame = 2131231492;

        /* JADX INFO: Added by JADX */
        public static final int search_go_btn = 2131231493;

        /* JADX INFO: Added by JADX */
        public static final int search_mag_icon = 2131231494;

        /* JADX INFO: Added by JADX */
        public static final int search_plate = 2131231495;

        /* JADX INFO: Added by JADX */
        public static final int search_src_text = 2131231496;

        /* JADX INFO: Added by JADX */
        public static final int search_voice_btn = 2131231497;

        /* JADX INFO: Added by JADX */
        public static final int select_dialog_listview = 2131231498;

        /* JADX INFO: Added by JADX */
        public static final int sharedValueSet = 2131231500;

        /* JADX INFO: Added by JADX */
        public static final int sharedValueUnset = 2131231501;

        /* JADX INFO: Added by JADX */
        public static final int shortcut = 2131231502;

        /* JADX INFO: Added by JADX */
        public static final int showCustom = 2131231503;

        /* JADX INFO: Added by JADX */
        public static final int showHome = 2131231504;

        /* JADX INFO: Added by JADX */
        public static final int showTitle = 2131231505;

        /* JADX INFO: Added by JADX */
        public static final int sin = 2131231506;

        /* JADX INFO: Added by JADX */
        public static final int skipped = 2131231507;

        /* JADX INFO: Added by JADX */
        public static final int south = 2131231508;

        /* JADX INFO: Added by JADX */
        public static final int spacer = 2131231509;

        /* JADX INFO: Added by JADX */
        public static final int special_effects_controller_view_tag = 2131231510;

        /* JADX INFO: Added by JADX */
        public static final int spline = 2131231511;

        /* JADX INFO: Added by JADX */
        public static final int split_action_bar = 2131231512;

        /* JADX INFO: Added by JADX */
        public static final int spread = 2131231513;

        /* JADX INFO: Added by JADX */
        public static final int spread_inside = 2131231514;

        /* JADX INFO: Added by JADX */
        public static final int spring = 2131231515;

        /* JADX INFO: Added by JADX */
        public static final int square = 2131231516;

        /* JADX INFO: Added by JADX */
        public static final int src_atop = 2131231517;

        /* JADX INFO: Added by JADX */
        public static final int src_in = 2131231518;

        /* JADX INFO: Added by JADX */
        public static final int src_over = 2131231519;

        /* JADX INFO: Added by JADX */
        public static final int standard = 2131231520;

        /* JADX INFO: Added by JADX */
        public static final int start = 2131231521;

        /* JADX INFO: Added by JADX */
        public static final int startHorizontal = 2131231522;

        /* JADX INFO: Added by JADX */
        public static final int startVertical = 2131231523;

        /* JADX INFO: Added by JADX */
        public static final int staticLayout = 2131231524;

        /* JADX INFO: Added by JADX */
        public static final int staticPostLayout = 2131231525;

        /* JADX INFO: Added by JADX */
        public static final int stop = 2131231526;

        /* JADX INFO: Added by JADX */
        public static final int submenuarrow = 2131231527;

        /* JADX INFO: Added by JADX */
        public static final int submit_area = 2131231528;

        /* JADX INFO: Added by JADX */
        public static final int supportScrollUp = 2131231529;

        /* JADX INFO: Added by JADX */
        public static final int tabMode = 2131231530;

        /* JADX INFO: Added by JADX */
        public static final int tag_accessibility_actions = 2131231531;

        /* JADX INFO: Added by JADX */
        public static final int tag_accessibility_clickable_spans = 2131231532;

        /* JADX INFO: Added by JADX */
        public static final int tag_accessibility_heading = 2131231533;

        /* JADX INFO: Added by JADX */
        public static final int tag_accessibility_pane_title = 2131231534;

        /* JADX INFO: Added by JADX */
        public static final int tag_on_apply_window_listener = 2131231535;

        /* JADX INFO: Added by JADX */
        public static final int tag_on_receive_content_listener = 2131231536;

        /* JADX INFO: Added by JADX */
        public static final int tag_on_receive_content_mime_types = 2131231537;

        /* JADX INFO: Added by JADX */
        public static final int tag_screen_reader_focusable = 2131231538;

        /* JADX INFO: Added by JADX */
        public static final int tag_state_description = 2131231539;

        /* JADX INFO: Added by JADX */
        public static final int tag_transition_group = 2131231540;

        /* JADX INFO: Added by JADX */
        public static final int tag_unhandled_key_event_manager = 2131231541;

        /* JADX INFO: Added by JADX */
        public static final int tag_unhandled_key_listeners = 2131231542;

        /* JADX INFO: Added by JADX */
        public static final int tag_window_insets_animation_callback = 2131231543;

        /* JADX INFO: Added by JADX */
        public static final int text = 2131231544;

        /* JADX INFO: Added by JADX */
        public static final int text2 = 2131231545;

        /* JADX INFO: Added by JADX */
        public static final int textSpacerNoButtons = 2131231546;

        /* JADX INFO: Added by JADX */
        public static final int textSpacerNoTitle = 2131231547;

        /* JADX INFO: Added by JADX */
        public static final int time = 2131231552;

        /* JADX INFO: Added by JADX */
        public static final int title = 2131231553;

        /* JADX INFO: Added by JADX */
        public static final int titleDividerNoCustom = 2131231554;

        /* JADX INFO: Added by JADX */
        public static final int title_template = 2131231555;

        /* JADX INFO: Added by JADX */
        public static final int toggle = 2131231556;

        /* JADX INFO: Added by JADX */
        public static final int top = 2131231557;

        /* JADX INFO: Added by JADX */
        public static final int topPanel = 2131231558;

        /* JADX INFO: Added by JADX */
        public static final int transitionToEnd = 2131231574;

        /* JADX INFO: Added by JADX */
        public static final int transitionToStart = 2131231575;

        /* JADX INFO: Added by JADX */
        public static final int triangle = 2131231576;

        /* JADX INFO: Added by JADX */
        public static final int unchecked = 2131231597;

        /* JADX INFO: Added by JADX */
        public static final int uniform = 2131231598;

        /* JADX INFO: Added by JADX */
        public static final int up = 2131231599;

        /* JADX INFO: Added by JADX */
        public static final int useLogo = 2131231600;

        /* JADX INFO: Added by JADX */
        public static final int vertical = 2131231601;

        /* JADX INFO: Added by JADX */
        public static final int vertical_only = 2131231602;

        /* JADX INFO: Added by JADX */
        public static final int view_transition = 2131231606;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_lifecycle_owner = 2131231607;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_on_back_pressed_dispatcher_owner = 2131231608;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_saved_state_registry_owner = 2131231609;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_view_model_store_owner = 2131231610;

        /* JADX INFO: Added by JADX */
        public static final int visible = 2131231611;

        /* JADX INFO: Added by JADX */
        public static final int visible_removing_fragment_view_tag = 2131231612;

        /* JADX INFO: Added by JADX */
        public static final int west = 2131231613;

        /* JADX INFO: Added by JADX */
        public static final int withText = 2131231614;

        /* JADX INFO: Added by JADX */
        public static final int wrap = 2131231615;

        /* JADX INFO: Added by JADX */
        public static final int wrap_content = 2131231616;

        /* JADX INFO: Added by JADX */
        public static final int wrap_content_constrained = 2131231617;

        /* JADX INFO: Added by JADX */
        public static final int x_left = 2131231618;

        /* JADX INFO: Added by JADX */
        public static final int x_right = 2131231619;

        private id() {
        }
    }

    /* renamed from: com.hhssoftware.multideco.R$layout */
    public static final class layout {
        public static int mixer_capacity = 2131427359;
        public static int mixer_config = 2131427360;
        public static int mixer_density = 2131427361;
        public static int mixer_nitrox = 2131427362;
        public static int mixer_topup = 2131427363;
        public static int mixer_trimix = 2131427364;
        public static int multideco_about = 2131427365;
        public static int multideco_agree = 2131427366;
        public static int multideco_bail = 2131427367;
        public static int multideco_bestmix = 2131427368;
        public static int multideco_config = 2131427369;
        public static int multideco_deco = 2131427370;
        public static int multideco_eadmod = 2131427371;
        public static int multideco_level = 2131427372;
        public static int multideco_main = 2131427373;
        public static int multideco_maxtime = 2131427374;
        public static int multideco_registration = 2131427375;
        public static int multideco_report = 2131427376;
        public static int multideco_result = 2131427377;
        public static int multideco_surfint = 2131427378;
        public static int settank = 2131427388;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_title_item = 2131427328;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_up_container = 2131427329;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_menu_item_layout = 2131427330;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_menu_layout = 2131427331;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_mode_bar = 2131427332;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_mode_close_item_material = 2131427333;

        /* JADX INFO: Added by JADX */
        public static final int abc_activity_chooser_view = 2131427334;

        /* JADX INFO: Added by JADX */
        public static final int abc_activity_chooser_view_list_item = 2131427335;

        /* JADX INFO: Added by JADX */
        public static final int abc_alert_dialog_button_bar_material = 2131427336;

        /* JADX INFO: Added by JADX */
        public static final int abc_alert_dialog_material = 2131427337;

        /* JADX INFO: Added by JADX */
        public static final int abc_alert_dialog_title_material = 2131427338;

        /* JADX INFO: Added by JADX */
        public static final int abc_cascading_menu_item_layout = 2131427339;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_title_material = 2131427340;

        /* JADX INFO: Added by JADX */
        public static final int abc_expanded_menu_layout = 2131427341;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_menu_item_checkbox = 2131427342;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_menu_item_icon = 2131427343;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_menu_item_layout = 2131427344;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_menu_item_radio = 2131427345;

        /* JADX INFO: Added by JADX */
        public static final int abc_popup_menu_header_item_layout = 2131427346;

        /* JADX INFO: Added by JADX */
        public static final int abc_popup_menu_item_layout = 2131427347;

        /* JADX INFO: Added by JADX */
        public static final int abc_screen_content_include = 2131427348;

        /* JADX INFO: Added by JADX */
        public static final int abc_screen_simple = 2131427349;

        /* JADX INFO: Added by JADX */
        public static final int abc_screen_simple_overlay_action_mode = 2131427350;

        /* JADX INFO: Added by JADX */
        public static final int abc_screen_toolbar = 2131427351;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_dropdown_item_icons_2line = 2131427352;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_view = 2131427353;

        /* JADX INFO: Added by JADX */
        public static final int abc_select_dialog_material = 2131427354;

        /* JADX INFO: Added by JADX */
        public static final int abc_tooltip = 2131427355;

        /* JADX INFO: Added by JADX */
        public static final int custom_dialog = 2131427356;

        /* JADX INFO: Added by JADX */
        public static final int ime_base_split_test_activity = 2131427357;

        /* JADX INFO: Added by JADX */
        public static final int ime_secondary_split_test_activity = 2131427358;

        /* JADX INFO: Added by JADX */
        public static final int notification_action = 2131427379;

        /* JADX INFO: Added by JADX */
        public static final int notification_action_tombstone = 2131427380;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_custom_big = 2131427381;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_icon_group = 2131427382;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_part_chronometer = 2131427383;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_part_time = 2131427384;

        /* JADX INFO: Added by JADX */
        public static final int select_dialog_item_material = 2131427385;

        /* JADX INFO: Added by JADX */
        public static final int select_dialog_multichoice_material = 2131427386;

        /* JADX INFO: Added by JADX */
        public static final int select_dialog_singlechoice_material = 2131427387;

        /* JADX INFO: Added by JADX */
        public static final int support_simple_spinner_dropdown_item = 2131427389;

        private layout() {
        }
    }

    /* renamed from: com.hhssoftware.multideco.R$mipmap */
    public static final class mipmap {
        public static int ic_launcher = 2131492864;
        public static int ic_launcher_background = 2131492865;
        public static int ic_launcher_foreground = 2131492866;
        public static int ic_launcher_round = 2131492867;

        private mipmap() {
        }
    }

    /* renamed from: com.hhssoftware.multideco.R$raw */
    public static final class raw {
        public static int license = 2131558400;
        public static int pubkey_150103 = 2131558401;

        private raw() {
        }
    }

    /* renamed from: com.hhssoftware.multideco.R$string */
    public static final class string {
        public static int ATA = 2131623936;
        public static int About = 2131623937;
        public static int Accept = 2131623938;
        public static int AcceptAgreement = 2131623939;
        public static int Addpressure = 2131623940;
        public static int Air = 2131623941;
        public static int AscentdescentSettings = 2131623942;
        public static int BAR = 2131623943;
        public static int Bail = 2131623944;
        public static int BailRowMaxTimeHelp = 2131623945;
        public static int Bailout = 2131623946;
        public static int BailoutSettings = 2131623947;
        public static int Bailoutnextversion = 2131623948;
        public static int Bottom_level = 2131623949;
        public static int BuyReg = 2131623950;
        public static int CCR = 2131623951;
        public static int CCRdilCheck = 2131623952;
        public static int CNSAbove = 2131623953;
        public static int Calculate = 2131623954;
        public static int Cancel = 2131623955;
        public static int Cavetypebail = 2131623956;
        public static int Config_menu_button = 2131623957;
        public static int Config_rates_changed = 2131623958;
        public static int Confirm = 2131623959;
        public static int CopyClip = 2131623960;
        public static int CuFt = 2131623961;
        public static int Darktheme = 2131623962;
        public static int Day = 2131623963;
        public static int Decline = 2131623964;
        public static int Deco = 2131623965;
        public static int DecoSwapDepth = 2131623966;
        public static int Deco_mix = 2131623967;
        public static int Decozonestart = 2131623968;
        public static int Delete = 2131623969;
        public static int DeleteEdit = 2131623970;
        public static int Depth = 2131623971;
        public static int Depth_ = 2131623972;
        public static int Depth_result = 2131623973;
        public static int Digital = 2131623974;
        public static int Dive = 2131623975;
        public static int DiveMonitorSettings = 2131623976;
        public static int Doubletanks = 2131623977;
        public static int Downloadnewversionnow = 2131623978;
        public static int EAD = 2131623979;
        public static int Edit = 2131623980;
        public static int Elevation = 2131623981;
        public static int Emailplan = 2131623982;
        public static int End = 2131623983;
        public static int EnterRegKey = 2131623984;
        public static int Equalize = 2131623985;
        public static int ErrLegSelection = 2131623986;
        public static int Error = 2131623987;
        public static int ExistingCustomer = 2131623988;
        public static int ExtraMinsbail = 2131623989;
        public static int Feet = 2131623990;
        public static int Finish = 2131623991;
        public static int Fresh = 2131623992;
        public static int Gas = 2131623993;
        public static int HHSSoftware = 2131623994;
        public static int Helpimprovelanguage = 2131623995;
        public static int Hepercent = 2131623996;
        public static int Hour = 2131623997;
        public static int IBCDHeWarn = 2131623998;
        public static int IBCDN2Warn = 2131623999;
        public static int Info = 2131624000;
        public static int Installcode = 2131624001;
        public static int Lighttheme = 2131624002;
        public static int Logs = 2131624003;
        public static int Ltr = 2131624004;
        public static int MaxTime = 2131624005;
        public static int Maximumtimeplan = 2131624006;
        public static int Meter = 2131624007;
        public static int Min = 2131624008;
        public static int Mix = 2131624009;
        public static int MixO2_He = 2131624010;
        public static int Mix_result = 2131624011;
        public static int Mixer = 2131624012;
        public static int ModelSettings = 2131624013;
        public static int NewKey = 2131624014;
        public static int Newlanguage = 2131624015;
        public static int Newversion = 2131624016;
        public static int Newversionready = 2131624017;
        public static int NextDive = 2131624018;

        /* renamed from: No */
        public static int f85No = 2131624019;
        public static int NoneAddNow = 2131624020;
        public static int O2percent = 2131624021;

        /* renamed from: OC */
        public static int f86OC = 2131624022;
        public static int OCorSCR = 2131624023;
        public static int OTUAbove = 2131624024;
        public static int Off = 2131624025;

        /* renamed from: On */
        public static int f87On = 2131624026;
        public static int PSI = 2131624027;
        public static int Pressure = 2131624028;
        public static int Pressurewhenfull = 2131624029;
        public static int Receive = 2131624030;
        public static int RegDetailsSavedRestart = 2131624031;
        public static int RegisterOnline = 2131624032;
        public static int Registration = 2131624033;
        public static int Repeat = 2131624034;
        public static int Report = 2131624035;
        public static int Result = 2131624036;
        public static int Run = 2131624037;
        public static int Run_result = 2131624038;
        public static int SNewKey = 2131624039;

        /* renamed from: SP */
        public static int f88SP = 2131624040;
        public static int SReg = 2131624041;
        public static int Salt = 2131624042;
        public static int Save = 2131624043;
        public static int SelectBottomRMV = 2131624044;
        public static int SelectCNS = 2131624045;
        public static int SelectConservatism = 2131624046;
        public static int SelectConservatismGFHi = 2131624047;
        public static int SelectConservatismGFLo = 2131624048;
        public static int SelectConservatismGFS = 2131624049;
        public static int SelectDecoRMV = 2131624050;
        public static int SelectDepth = 2131624051;
        public static int SelectElevation = 2131624052;
        public static int SelectEmail = 2131624053;
        public static int SelectExtraMins = 2131624054;
        public static int SelectHe = 2131624055;
        public static int SelectItem = 2131624056;
        public static int SelectLast = 2131624057;
        public static int SelectO2 = 2131624058;
        public static int SelectOTU = 2131624059;
        public static int SelectRate = 2131624060;
        public static int SelectSP = 2131624061;
        public static int SelectStepSize = 2131624062;
        public static int SelectStopTime = 2131624063;
        public static int SelectTemp = 2131624064;
        public static int SelectTheme = 2131624065;
        public static int SelectTime = 2131624066;
        public static int Selectcavereturn = 2131624067;
        public static int SelectppHeIncrease = 2131624068;
        public static int SelectppN2Increase = 2131624069;
        public static int SelectppO2 = 2131624070;
        public static int SelectppO2value = 2131624071;
        public static int Selecttanksize = 2131624072;
        public static int Setpoint = 2131624073;
        public static int Settings = 2131624074;
        public static int Setup = 2131624075;
        public static int Simple = 2131624076;
        public static int Start = 2131624077;
        public static int Startpressure = 2131624078;
        public static int Stop = 2131624079;
        public static int StopMixSettings = 2131624080;
        public static int Stop_result = 2131624081;
        public static int Supply = 2131624082;
        public static int Surface = 2131624083;
        public static int SurfaceInterval = 2131624084;
        public static int TankSizes = 2131624085;
        public static int Tanks = 2131624086;
        public static int Tanksize = 2131624087;
        public static int TanksizeSetupIntro = 2131624088;
        public static int Temperature = 2131624089;
        public static int Theme = 2131624090;
        public static int Time_ = 2131624091;
        public static int Tools = 2131624092;
        public static int TopOff = 2131624093;
        public static int TopUpwithO2percentage = 2131624094;
        public static int UnitSettings = 2131624095;
        public static int VPlannerdiveplan = 2131624096;
        public static int WaitCalc = 2131624097;
        public static int WaitLoading = 2131624098;
        public static int Watercapacity = 2131624099;
        public static int WebFAQ = 2131624100;
        public static int Yes = 2131624101;
        public static int add32 = 2131624129;
        public static int addHe = 2131624130;
        public static int addO2 = 2131624131;
        public static int addair = 2131624132;
        public static int app_name = 2131624134;
        public static int ataair = 2131624135;
        public static int bailBottomRMVHelp = 2131624136;
        public static int bailCavebailModeHelp = 2131624137;
        public static int bailExtraMinsModeHelp = 2131624138;
        public static int bailIntroHelp = 2131624139;
        public static int bailOCMixSelectHelp = 2131624140;
        public static int bailVPMModelHelp = 2131624141;
        public static int base_lang = 2131624142;
        public static int bestmix = 2131624143;
        public static int blurb = 2131624144;
        public static int configAcclim = 2131624152;
        public static int configAcclimHelp = 2131624153;
        public static int configAddAllMix = 2131624154;
        public static int configAddO2Window = 2131624155;
        public static int configAddToStop = 2131624156;
        public static int configAddToStopHelp = 2131624157;
        public static int configAscent = 2131624158;
        public static int configAscentDescentHelp = 2131624159;
        public static int configBottomRMV = 2131624160;
        public static int configBottomRMVHelp = 2131624161;
        public static int configCCRSetPoint = 2131624162;
        public static int configCCRSetPointHelp = 2131624163;
        public static int configCCRdilCheckHelp = 2131624164;
        public static int configCNSAboveHelp = 2131624165;
        public static int configCircuit = 2131624166;
        public static int configCircuitHelp = 2131624167;
        public static int configConserve = 2131624168;
        public static int configConserveHelp = 2131624169;
        public static int configConserveHelpGF = 2131624170;
        public static int configConserveHelpGFS = 2131624171;
        public static int configDecoRMV = 2131624172;
        public static int configDecoRMVHelp = 2131624173;
        public static int configDescent = 2131624174;
        public static int configElevation = 2131624175;
        public static int configElevationHelp = 2131624176;
        public static int configExtend = 2131624177;
        public static int configExtendAnyHelp = 2131624178;
        public static int configExtendDeepft = 2131624179;
        public static int configExtendDeepm = 2131624180;
        public static int configExtendHelp = 2131624181;
        public static int configExtendShallowft = 2131624182;
        public static int configExtendShallowm = 2131624183;
        public static int configFeetMeter = 2131624184;
        public static int configFeetMeterHelp = 2131624185;
        public static int configFirstStop2xft = 2131624186;
        public static int configFirstStop2xm = 2131624187;
        public static int configFirstStop30sec = 2131624188;
        public static int configFirstStopHelp = 2131624189;
        public static int configGFHi = 2131624190;
        public static int configGFLoHi = 2131624191;
        public static int configGasVol = 2131624192;
        public static int configGasVolHelp = 2131624193;
        public static int configGuagetype = 2131624194;
        public static int configGuagetypeHelp = 2131624195;
        public static int configIBCDHeWarnHelp = 2131624196;
        public static int configIBCDN2WarnHelp = 2131624197;
        public static int configLastCCR = 2131624198;
        public static int configLastOC = 2131624199;
        public static int configNarcotic = 2131624200;
        public static int configNarcoticHelp = 2131624201;
        public static int configO2Depth = 2131624202;
        public static int configO2DepthHelp = 2131624203;
        public static int configOTUAboveHelp = 2131624204;
        public static int configReset = 2131624205;
        public static int configResetStr = 2131624206;
        public static int configStepSize = 2131624207;
        public static int configStepSizeHelp = 2131624208;
        public static int configStopTime = 2131624209;
        public static int configStopTimeHelp = 2131624210;
        public static int configVPMModel = 2131624211;
        public static int configVPMModelHelp = 2131624212;
        public static int configWater = 2131624213;
        public static int configWaterHelp = 2131624214;
        public static int config_name = 2131624215;
        public static int config_result = 2131624216;
        public static int configppO2AboveHelp = 2131624217;
        public static int configppO2BelowHelp = 2131624218;
        public static int configppO2Swap14 = 2131624219;
        public static int configppO2Swap15 = 2131624220;
        public static int configppO2Swap16 = 2131624221;
        public static int configppO2SwapHelp = 2131624222;
        public static int copyright = 2131624223;
        public static int cuftfull = 2131624224;
        public static int decoList = 2131624225;
        public static int deco_name = 2131624226;
        public static int degreeC = 2131624227;
        public static int degreeF = 2131624228;
        public static int ead = 2131624229;
        public static int eadd = 2131624230;
        public static int eaddhelp = 2131624231;
        public static int eadhelp = 2131624232;
        public static int end = 2131624233;
        public static int endhelp = 2131624234;
        public static int err_str_0 = 2131624235;
        public static int err_str_1 = 2131624236;
        public static int err_str_10 = 2131624237;
        public static int err_str_128 = 2131624238;
        public static int err_str_129 = 2131624239;
        public static int err_str_130_1 = 2131624240;
        public static int err_str_130_2 = 2131624241;
        public static int err_str_131_1 = 2131624242;
        public static int err_str_131_2 = 2131624243;
        public static int err_str_132 = 2131624244;
        public static int err_str_2 = 2131624245;
        public static int err_str_20 = 2131624246;
        public static int err_str_21 = 2131624247;
        public static int err_str_22 = 2131624248;
        public static int err_str_3 = 2131624249;
        public static int err_str_4 = 2131624250;
        public static int err_str_5 = 2131624251;
        public static int err_str_6 = 2131624252;
        public static int err_str_7 = 2131624253;
        public static int err_str_8 = 2131624254;
        public static int err_str_9 = 2131624255;
        public static int finalmix02he = 2131624256;
        public static int gramltr = 2131624257;
        public static int language = 2131624258;
        public static int level_name = 2131624259;
        public static int levelsCCRList = 2131624260;
        public static int levelsOCList = 2131624261;
        public static int litertankvol = 2131624262;
        public static int mix32 = 2131624263;
        public static int mixer_instruct = 2131624264;
        public static int mobile_faq = 2131624265;
        public static int mod = 2131624266;
        public static int modhelp = 2131624267;
        public static int multideco_EADMOD = 2131624268;
        public static int multideco_about = 2131624269;
        public static int multideco_agree = 2131624270;
        public static int multideco_bail = 2131624271;
        public static int multideco_bestmix = 2131624272;
        public static int multideco_maxtime = 2131624273;
        public static int multideco_mixer_capacity = 2131624274;
        public static int multideco_mixer_config = 2131624275;
        public static int multideco_mixer_density = 2131624276;
        public static int multideco_mixer_nitrox = 2131624277;
        public static int multideco_mixer_topup = 2131624278;
        public static int multideco_mixer_trimix = 2131624279;
        public static int multideco_registration = 2131624280;
        public static int multideco_settank = 2131624281;
        public static int multideco_tools = 2131624282;
        public static int pO2 = 2131624283;
        public static int ppO2Above = 2131624284;
        public static int ppO2Below = 2131624285;
        public static int ppO2MOD = 2131624286;
        public static int ppO2limit = 2131624287;
        public static int regdescript = 2131624288;
        public static int regtitle = 2131624289;
        public static int temp0C = 2131624292;
        public static int temp20C = 2131624293;
        public static int testo2 = 2131624294;
        public static int toolListItems_Best = 2131624295;
        public static int toolListItems_Density = 2131624296;
        public static int toolListItems_EAD = 2131624297;
        public static int toolListItems_MixConfig = 2131624298;
        public static int toolListItems_MixFill = 2131624299;
        public static int toolListItems_MixNitrox = 2131624300;
        public static int toolListItems_MixTopup = 2131624301;
        public static int toolListItems_MixTrimix = 2131624302;
        public static int trimix = 2131624303;
        public static int trimixEAD = 2131624304;
        public static int waitLoadingsetting = 2131624305;
        public static int warn_str_0 = 2131624306;
        public static int warn_str_1 = 2131624307;
        public static int warn_str_2 = 2131624308;
        public static int warn_str_3 = 2131624309;
        public static int warn_str_4 = 2131624310;
        public static int warn_str_5 = 2131624311;
        public static int warn_str_6 = 2131624312;
        public static int warn_str_7 = 2131624313;
        public static int warn_str_8 = 2131624314;
        public static int warn_str_9 = 2131624315;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_home_description = 2131624102;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_up_description = 2131624103;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_menu_overflow_description = 2131624104;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_mode_done = 2131624105;

        /* JADX INFO: Added by JADX */
        public static final int abc_activity_chooser_view_see_all = 2131624106;

        /* JADX INFO: Added by JADX */
        public static final int abc_activitychooserview_choose_application = 2131624107;

        /* JADX INFO: Added by JADX */
        public static final int abc_capital_off = 2131624108;

        /* JADX INFO: Added by JADX */
        public static final int abc_capital_on = 2131624109;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_alt_shortcut_label = 2131624110;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_ctrl_shortcut_label = 2131624111;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_delete_shortcut_label = 2131624112;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_enter_shortcut_label = 2131624113;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_function_shortcut_label = 2131624114;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_meta_shortcut_label = 2131624115;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_shift_shortcut_label = 2131624116;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_space_shortcut_label = 2131624117;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_sym_shortcut_label = 2131624118;

        /* JADX INFO: Added by JADX */
        public static final int abc_prepend_shortcut_label = 2131624119;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_hint = 2131624120;

        /* JADX INFO: Added by JADX */
        public static final int abc_searchview_description_clear = 2131624121;

        /* JADX INFO: Added by JADX */
        public static final int abc_searchview_description_query = 2131624122;

        /* JADX INFO: Added by JADX */
        public static final int abc_searchview_description_search = 2131624123;

        /* JADX INFO: Added by JADX */
        public static final int abc_searchview_description_submit = 2131624124;

        /* JADX INFO: Added by JADX */
        public static final int abc_searchview_description_voice = 2131624125;

        /* JADX INFO: Added by JADX */
        public static final int abc_shareactionprovider_share_with = 2131624126;

        /* JADX INFO: Added by JADX */
        public static final int abc_shareactionprovider_share_with_application = 2131624127;

        /* JADX INFO: Added by JADX */
        public static final int abc_toolbar_collapse_description = 2131624128;

        /* JADX INFO: Added by JADX */
        public static final int androidx_startup = 2131624133;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_answer_action = 2131624145;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_answer_video_action = 2131624146;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_decline_action = 2131624147;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_hang_up_action = 2131624148;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_incoming_text = 2131624149;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_ongoing_text = 2131624150;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_screening_text = 2131624151;

        /* JADX INFO: Added by JADX */
        public static final int search_menu_title = 2131624290;

        /* JADX INFO: Added by JADX */
        public static final int status_bar_notification_info_overflow = 2131624291;

        private string() {
        }
    }

    /* renamed from: com.hhssoftware.multideco.R$style */
    public static final class style {
        public static int AppTheme = 2131689477;

        /* JADX INFO: Added by JADX */
        public static final int AlertDialog_AppCompat = 2131689472;

        /* JADX INFO: Added by JADX */
        public static final int AlertDialog_AppCompat_Light = 2131689473;

        /* JADX INFO: Added by JADX */
        public static final int Animation_AppCompat_Dialog = 2131689474;

        /* JADX INFO: Added by JADX */
        public static final int Animation_AppCompat_DropDownUp = 2131689475;

        /* JADX INFO: Added by JADX */
        public static final int Animation_AppCompat_Tooltip = 2131689476;

        /* JADX INFO: Added by JADX */
        public static final int Base_AlertDialog_AppCompat = 2131689478;

        /* JADX INFO: Added by JADX */
        public static final int Base_AlertDialog_AppCompat_Light = 2131689479;

        /* JADX INFO: Added by JADX */
        public static final int Base_Animation_AppCompat_Dialog = 2131689480;

        /* JADX INFO: Added by JADX */
        public static final int Base_Animation_AppCompat_DropDownUp = 2131689481;

        /* JADX INFO: Added by JADX */
        public static final int Base_Animation_AppCompat_Tooltip = 2131689482;

        /* JADX INFO: Added by JADX */
        public static final int Base_DialogWindowTitle_AppCompat = 2131689483;

        /* JADX INFO: Added by JADX */
        public static final int Base_DialogWindowTitleBackground_AppCompat = 2131689484;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat = 2131689485;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Body1 = 2131689486;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Body2 = 2131689487;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Button = 2131689488;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Caption = 2131689489;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Display1 = 2131689490;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Display2 = 2131689491;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Display3 = 2131689492;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Display4 = 2131689493;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Headline = 2131689494;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Inverse = 2131689495;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Large = 2131689496;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Large_Inverse = 2131689497;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 2131689498;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 2131689499;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Medium = 2131689500;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Medium_Inverse = 2131689501;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Menu = 2131689502;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_SearchResult = 2131689503;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_SearchResult_Subtitle = 2131689504;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_SearchResult_Title = 2131689505;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Small = 2131689506;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Small_Inverse = 2131689507;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Subhead = 2131689508;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Subhead_Inverse = 2131689509;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Title = 2131689510;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Title_Inverse = 2131689511;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Tooltip = 2131689512;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Menu = 2131689513;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 2131689514;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 2131689515;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title = 2131689516;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 2131689517;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 2131689518;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Title = 2131689519;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_Button = 2131689520;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 2131689521;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_Button_Colored = 2131689522;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_Button_Inverse = 2131689523;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_DropDownItem = 2131689524;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Header = 2131689525;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Large = 2131689526;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Small = 2131689527;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_Switch = 2131689528;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 2131689529;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 2131689530;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 2131689531;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Title = 2131689532;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat = 2131689533;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_CompactMenu = 2131689534;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Dialog = 2131689535;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Dialog_Alert = 2131689536;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Dialog_FixedSize = 2131689537;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Dialog_MinWidth = 2131689538;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_DialogWhenLarge = 2131689539;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Light = 2131689540;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Light_DarkActionBar = 2131689541;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Light_Dialog = 2131689542;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Light_Dialog_Alert = 2131689543;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Light_Dialog_FixedSize = 2131689544;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Light_Dialog_MinWidth = 2131689545;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Light_DialogWhenLarge = 2131689546;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_AppCompat = 2131689547;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_ActionBar = 2131689548;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_Dark = 2131689549;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_Dark_ActionBar = 2131689550;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_Dialog = 2131689551;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_Dialog_Alert = 2131689552;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_Light = 2131689553;

        /* JADX INFO: Added by JADX */
        public static final int Base_V21_Theme_AppCompat = 2131689554;

        /* JADX INFO: Added by JADX */
        public static final int Base_V21_Theme_AppCompat_Dialog = 2131689555;

        /* JADX INFO: Added by JADX */
        public static final int Base_V21_Theme_AppCompat_Light = 2131689556;

        /* JADX INFO: Added by JADX */
        public static final int Base_V21_Theme_AppCompat_Light_Dialog = 2131689557;

        /* JADX INFO: Added by JADX */
        public static final int Base_V21_ThemeOverlay_AppCompat_Dialog = 2131689558;

        /* JADX INFO: Added by JADX */
        public static final int Base_V22_Theme_AppCompat = 2131689559;

        /* JADX INFO: Added by JADX */
        public static final int Base_V22_Theme_AppCompat_Light = 2131689560;

        /* JADX INFO: Added by JADX */
        public static final int Base_V23_Theme_AppCompat = 2131689561;

        /* JADX INFO: Added by JADX */
        public static final int Base_V23_Theme_AppCompat_Light = 2131689562;

        /* JADX INFO: Added by JADX */
        public static final int Base_V26_Theme_AppCompat = 2131689563;

        /* JADX INFO: Added by JADX */
        public static final int Base_V26_Theme_AppCompat_Light = 2131689564;

        /* JADX INFO: Added by JADX */
        public static final int Base_V26_Widget_AppCompat_Toolbar = 2131689565;

        /* JADX INFO: Added by JADX */
        public static final int Base_V28_Theme_AppCompat = 2131689566;

        /* JADX INFO: Added by JADX */
        public static final int Base_V28_Theme_AppCompat_Light = 2131689567;

        /* JADX INFO: Added by JADX */
        public static final int Base_V7_Theme_AppCompat = 2131689568;

        /* JADX INFO: Added by JADX */
        public static final int Base_V7_Theme_AppCompat_Dialog = 2131689569;

        /* JADX INFO: Added by JADX */
        public static final int Base_V7_Theme_AppCompat_Light = 2131689570;

        /* JADX INFO: Added by JADX */
        public static final int Base_V7_Theme_AppCompat_Light_Dialog = 2131689571;

        /* JADX INFO: Added by JADX */
        public static final int Base_V7_ThemeOverlay_AppCompat_Dialog = 2131689572;

        /* JADX INFO: Added by JADX */
        public static final int Base_V7_Widget_AppCompat_AutoCompleteTextView = 2131689573;

        /* JADX INFO: Added by JADX */
        public static final int Base_V7_Widget_AppCompat_EditText = 2131689574;

        /* JADX INFO: Added by JADX */
        public static final int Base_V7_Widget_AppCompat_Toolbar = 2131689575;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionBar = 2131689576;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionBar_Solid = 2131689577;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionBar_TabBar = 2131689578;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionBar_TabText = 2131689579;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionBar_TabView = 2131689580;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionButton = 2131689581;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionButton_CloseMode = 2131689582;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionButton_Overflow = 2131689583;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionMode = 2131689584;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActivityChooserView = 2131689585;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_AutoCompleteTextView = 2131689586;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Button = 2131689587;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Button_Borderless = 2131689588;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Button_Borderless_Colored = 2131689589;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Button_ButtonBar_AlertDialog = 2131689590;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Button_Colored = 2131689591;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Button_Small = 2131689592;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ButtonBar = 2131689593;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ButtonBar_AlertDialog = 2131689594;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_CompoundButton_CheckBox = 2131689595;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_CompoundButton_RadioButton = 2131689596;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_CompoundButton_Switch = 2131689597;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_DrawerArrowToggle = 2131689598;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_DrawerArrowToggle_Common = 2131689599;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_DropDownItem_Spinner = 2131689600;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_EditText = 2131689601;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ImageButton = 2131689602;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar = 2131689603;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar_Solid = 2131689604;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabBar = 2131689605;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabText = 2131689606;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabText_Inverse = 2131689607;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabView = 2131689608;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Light_PopupMenu = 2131689609;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Light_PopupMenu_Overflow = 2131689610;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ListMenuView = 2131689611;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ListPopupWindow = 2131689612;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ListView = 2131689613;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ListView_DropDown = 2131689614;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ListView_Menu = 2131689615;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_PopupMenu = 2131689616;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_PopupMenu_Overflow = 2131689617;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_PopupWindow = 2131689618;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ProgressBar = 2131689619;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ProgressBar_Horizontal = 2131689620;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_RatingBar = 2131689621;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_RatingBar_Indicator = 2131689622;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_RatingBar_Small = 2131689623;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_SearchView = 2131689624;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_SearchView_ActionBar = 2131689625;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_SeekBar = 2131689626;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_SeekBar_Discrete = 2131689627;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Spinner = 2131689628;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Spinner_Underlined = 2131689629;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_TextView = 2131689630;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_TextView_SpinnerItem = 2131689631;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Toolbar = 2131689632;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Toolbar_Button_Navigation = 2131689633;

        /* JADX INFO: Added by JADX */
        public static final int Platform_AppCompat = 2131689634;

        /* JADX INFO: Added by JADX */
        public static final int Platform_AppCompat_Light = 2131689635;

        /* JADX INFO: Added by JADX */
        public static final int Platform_ThemeOverlay_AppCompat = 2131689636;

        /* JADX INFO: Added by JADX */
        public static final int Platform_ThemeOverlay_AppCompat_Dark = 2131689637;

        /* JADX INFO: Added by JADX */
        public static final int Platform_ThemeOverlay_AppCompat_Light = 2131689638;

        /* JADX INFO: Added by JADX */
        public static final int Platform_V21_AppCompat = 2131689639;

        /* JADX INFO: Added by JADX */
        public static final int Platform_V21_AppCompat_Light = 2131689640;

        /* JADX INFO: Added by JADX */
        public static final int Platform_V25_AppCompat = 2131689641;

        /* JADX INFO: Added by JADX */
        public static final int Platform_V25_AppCompat_Light = 2131689642;

        /* JADX INFO: Added by JADX */
        public static final int Platform_Widget_AppCompat_Spinner = 2131689643;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_DialogWindowTitle_AppCompat = 2131689644;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_ActionBar_TitleItem = 2131689645;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_DialogTitle_Icon = 2131689646;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem = 2131689647;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_InternalGroup = 2131689648;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Shortcut = 2131689649;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_SubmenuArrow = 2131689650;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Text = 2131689651;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Title = 2131689652;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown = 2131689653;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon1 = 2131689654;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon2 = 2131689655;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Query = 2131689656;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Text = 2131689657;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_SearchView_MagIcon = 2131689658;

        /* JADX INFO: Added by JADX */
        public static final int RtlUnderlay_Widget_AppCompat_ActionButton = 2131689659;

        /* JADX INFO: Added by JADX */
        public static final int RtlUnderlay_Widget_AppCompat_ActionButton_Overflow = 2131689660;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat = 2131689661;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Body1 = 2131689662;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Body2 = 2131689663;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Button = 2131689664;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Caption = 2131689665;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Display1 = 2131689666;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Display2 = 2131689667;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Display3 = 2131689668;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Display4 = 2131689669;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Headline = 2131689670;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Inverse = 2131689671;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Large = 2131689672;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Large_Inverse = 2131689673;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Light_SearchResult_Subtitle = 2131689674;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Light_SearchResult_Title = 2131689675;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 2131689676;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 2131689677;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Medium = 2131689678;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Medium_Inverse = 2131689679;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Menu = 2131689680;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_SearchResult_Subtitle = 2131689681;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_SearchResult_Title = 2131689682;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Small = 2131689683;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Small_Inverse = 2131689684;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Subhead = 2131689685;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Subhead_Inverse = 2131689686;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Title = 2131689687;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Title_Inverse = 2131689688;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Tooltip = 2131689689;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Menu = 2131689690;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 2131689691;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 2131689692;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Title = 2131689693;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 2131689694;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 2131689695;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle_Inverse = 2131689696;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Title = 2131689697;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Title_Inverse = 2131689698;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_Button = 2131689699;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 2131689700;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_Button_Colored = 2131689701;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_Button_Inverse = 2131689702;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_DropDownItem = 2131689703;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_PopupMenu_Header = 2131689704;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_PopupMenu_Large = 2131689705;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_PopupMenu_Small = 2131689706;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_Switch = 2131689707;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 2131689708;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification = 2131689709;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification_Info = 2131689710;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification_Line2 = 2131689711;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification_Time = 2131689712;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification_Title = 2131689713;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 2131689714;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 2131689715;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Widget_AppCompat_Toolbar_Title = 2131689716;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat = 2131689717;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_CompactMenu = 2131689718;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DayNight = 2131689719;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DayNight_DarkActionBar = 2131689720;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DayNight_Dialog = 2131689721;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DayNight_Dialog_Alert = 2131689722;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DayNight_Dialog_MinWidth = 2131689723;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DayNight_DialogWhenLarge = 2131689724;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DayNight_NoActionBar = 2131689725;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Dialog = 2131689726;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Dialog_Alert = 2131689727;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Dialog_MinWidth = 2131689728;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DialogWhenLarge = 2131689729;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Empty = 2131689730;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Light = 2131689731;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Light_DarkActionBar = 2131689732;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Light_Dialog = 2131689733;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Light_Dialog_Alert = 2131689734;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Light_Dialog_MinWidth = 2131689735;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Light_DialogWhenLarge = 2131689736;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Light_NoActionBar = 2131689737;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_NoActionBar = 2131689738;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat = 2131689739;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat_ActionBar = 2131689740;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat_Dark = 2131689741;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat_Dark_ActionBar = 2131689742;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat_DayNight = 2131689743;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat_DayNight_ActionBar = 2131689744;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat_Dialog = 2131689745;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat_Dialog_Alert = 2131689746;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat_Light = 2131689747;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionBar = 2131689748;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionBar_Solid = 2131689749;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionBar_TabBar = 2131689750;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionBar_TabText = 2131689751;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionBar_TabView = 2131689752;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionButton = 2131689753;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionButton_CloseMode = 2131689754;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionButton_Overflow = 2131689755;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionMode = 2131689756;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActivityChooserView = 2131689757;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_AutoCompleteTextView = 2131689758;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Button = 2131689759;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Button_Borderless = 2131689760;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Button_Borderless_Colored = 2131689761;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Button_ButtonBar_AlertDialog = 2131689762;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Button_Colored = 2131689763;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Button_Small = 2131689764;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ButtonBar = 2131689765;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ButtonBar_AlertDialog = 2131689766;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_CompoundButton_CheckBox = 2131689767;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_CompoundButton_RadioButton = 2131689768;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_CompoundButton_Switch = 2131689769;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_DrawerArrowToggle = 2131689770;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_DropDownItem_Spinner = 2131689771;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_EditText = 2131689772;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ImageButton = 2131689773;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar = 2131689774;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_Solid = 2131689775;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_Solid_Inverse = 2131689776;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_TabBar = 2131689777;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_TabBar_Inverse = 2131689778;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_TabText = 2131689779;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_TabText_Inverse = 2131689780;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_TabView = 2131689781;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_TabView_Inverse = 2131689782;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionButton = 2131689783;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionButton_CloseMode = 2131689784;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionButton_Overflow = 2131689785;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionMode_Inverse = 2131689786;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActivityChooserView = 2131689787;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_AutoCompleteTextView = 2131689788;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_DropDownItem_Spinner = 2131689789;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ListPopupWindow = 2131689790;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ListView_DropDown = 2131689791;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_PopupMenu = 2131689792;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_PopupMenu_Overflow = 2131689793;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_SearchView = 2131689794;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_Spinner_DropDown_ActionBar = 2131689795;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ListMenuView = 2131689796;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ListPopupWindow = 2131689797;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ListView = 2131689798;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ListView_DropDown = 2131689799;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ListView_Menu = 2131689800;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_PopupMenu = 2131689801;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_PopupMenu_Overflow = 2131689802;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_PopupWindow = 2131689803;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ProgressBar = 2131689804;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ProgressBar_Horizontal = 2131689805;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_RatingBar = 2131689806;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_RatingBar_Indicator = 2131689807;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_RatingBar_Small = 2131689808;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_SearchView = 2131689809;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_SearchView_ActionBar = 2131689810;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_SeekBar = 2131689811;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_SeekBar_Discrete = 2131689812;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Spinner = 2131689813;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Spinner_DropDown = 2131689814;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Spinner_DropDown_ActionBar = 2131689815;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Spinner_Underlined = 2131689816;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_TextView = 2131689817;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_TextView_SpinnerItem = 2131689818;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Toolbar = 2131689819;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Toolbar_Button_Navigation = 2131689820;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Compat_NotificationActionContainer = 2131689821;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Compat_NotificationActionText = 2131689822;

        private style() {
        }
    }

    /* JADX INFO: Added by JADX */
    /* renamed from: com.hhssoftware.multideco.R$anim */
    public static final class anim {

        /* JADX INFO: Added by JADX */
        public static final int abc_fade_in = 2130771968;

        /* JADX INFO: Added by JADX */
        public static final int abc_fade_out = 2130771969;

        /* JADX INFO: Added by JADX */
        public static final int abc_grow_fade_in_from_bottom = 2130771970;

        /* JADX INFO: Added by JADX */
        public static final int abc_popup_enter = 2130771971;

        /* JADX INFO: Added by JADX */
        public static final int abc_popup_exit = 2130771972;

        /* JADX INFO: Added by JADX */
        public static final int abc_shrink_fade_out_from_bottom = 2130771973;

        /* JADX INFO: Added by JADX */
        public static final int abc_slide_in_bottom = 2130771974;

        /* JADX INFO: Added by JADX */
        public static final int abc_slide_in_top = 2130771975;

        /* JADX INFO: Added by JADX */
        public static final int abc_slide_out_bottom = 2130771976;

        /* JADX INFO: Added by JADX */
        public static final int abc_slide_out_top = 2130771977;

        /* JADX INFO: Added by JADX */
        public static final int abc_tooltip_enter = 2130771978;

        /* JADX INFO: Added by JADX */
        public static final int abc_tooltip_exit = 2130771979;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_to_checked_box_inner_merged_animation = 2130771980;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_to_checked_box_outer_merged_animation = 2130771981;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_to_checked_icon_null_animation = 2130771982;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_to_unchecked_box_inner_merged_animation = 2130771983;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_to_unchecked_check_path_merged_animation = 2130771984;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_to_unchecked_icon_null_animation = 2130771985;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_off_mtrl_dot_group_animation = 2130771986;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_off_mtrl_ring_outer_animation = 2130771987;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_off_mtrl_ring_outer_path_animation = 2130771988;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_on_mtrl_dot_group_animation = 2130771989;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_on_mtrl_ring_outer_animation = 2130771990;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_on_mtrl_ring_outer_path_animation = 2130771991;

        /* JADX INFO: Added by JADX */
        public static final int fragment_fast_out_extra_slow_in = 2130771992;
    }

    /* JADX INFO: Added by JADX */
    /* renamed from: com.hhssoftware.multideco.R$animator */
    public static final class animator {

        /* JADX INFO: Added by JADX */
        public static final int fragment_close_enter = 2130837504;

        /* JADX INFO: Added by JADX */
        public static final int fragment_close_exit = 2130837505;

        /* JADX INFO: Added by JADX */
        public static final int fragment_fade_enter = 2130837506;

        /* JADX INFO: Added by JADX */
        public static final int fragment_fade_exit = 2130837507;

        /* JADX INFO: Added by JADX */
        public static final int fragment_open_enter = 2130837508;

        /* JADX INFO: Added by JADX */
        public static final int fragment_open_exit = 2130837509;
    }

    /* JADX INFO: Added by JADX */
    /* renamed from: com.hhssoftware.multideco.R$attr */
    public static final class attr {

        /* JADX INFO: Added by JADX */
        public static final int SharedValue = 2130903040;

        /* JADX INFO: Added by JADX */
        public static final int SharedValueId = 2130903041;

        /* JADX INFO: Added by JADX */
        public static final int actionBarDivider = 2130903042;

        /* JADX INFO: Added by JADX */
        public static final int actionBarItemBackground = 2130903043;

        /* JADX INFO: Added by JADX */
        public static final int actionBarPopupTheme = 2130903044;

        /* JADX INFO: Added by JADX */
        public static final int actionBarSize = 2130903045;

        /* JADX INFO: Added by JADX */
        public static final int actionBarSplitStyle = 2130903046;

        /* JADX INFO: Added by JADX */
        public static final int actionBarStyle = 2130903047;

        /* JADX INFO: Added by JADX */
        public static final int actionBarTabBarStyle = 2130903048;

        /* JADX INFO: Added by JADX */
        public static final int actionBarTabStyle = 2130903049;

        /* JADX INFO: Added by JADX */
        public static final int actionBarTabTextStyle = 2130903050;

        /* JADX INFO: Added by JADX */
        public static final int actionBarTheme = 2130903051;

        /* JADX INFO: Added by JADX */
        public static final int actionBarWidgetTheme = 2130903052;

        /* JADX INFO: Added by JADX */
        public static final int actionButtonStyle = 2130903053;

        /* JADX INFO: Added by JADX */
        public static final int actionDropDownStyle = 2130903054;

        /* JADX INFO: Added by JADX */
        public static final int actionLayout = 2130903055;

        /* JADX INFO: Added by JADX */
        public static final int actionMenuTextAppearance = 2130903056;

        /* JADX INFO: Added by JADX */
        public static final int actionMenuTextColor = 2130903057;

        /* JADX INFO: Added by JADX */
        public static final int actionModeBackground = 2130903058;

        /* JADX INFO: Added by JADX */
        public static final int actionModeCloseButtonStyle = 2130903059;

        /* JADX INFO: Added by JADX */
        public static final int actionModeCloseContentDescription = 2130903060;

        /* JADX INFO: Added by JADX */
        public static final int actionModeCloseDrawable = 2130903061;

        /* JADX INFO: Added by JADX */
        public static final int actionModeCopyDrawable = 2130903062;

        /* JADX INFO: Added by JADX */
        public static final int actionModeCutDrawable = 2130903063;

        /* JADX INFO: Added by JADX */
        public static final int actionModeFindDrawable = 2130903064;

        /* JADX INFO: Added by JADX */
        public static final int actionModePasteDrawable = 2130903065;

        /* JADX INFO: Added by JADX */
        public static final int actionModePopupWindowStyle = 2130903066;

        /* JADX INFO: Added by JADX */
        public static final int actionModeSelectAllDrawable = 2130903067;

        /* JADX INFO: Added by JADX */
        public static final int actionModeShareDrawable = 2130903068;

        /* JADX INFO: Added by JADX */
        public static final int actionModeSplitBackground = 2130903069;

        /* JADX INFO: Added by JADX */
        public static final int actionModeStyle = 2130903070;

        /* JADX INFO: Added by JADX */
        public static final int actionModeTheme = 2130903071;

        /* JADX INFO: Added by JADX */
        public static final int actionModeWebSearchDrawable = 2130903072;

        /* JADX INFO: Added by JADX */
        public static final int actionOverflowButtonStyle = 2130903073;

        /* JADX INFO: Added by JADX */
        public static final int actionOverflowMenuStyle = 2130903074;

        /* JADX INFO: Added by JADX */
        public static final int actionProviderClass = 2130903075;

        /* JADX INFO: Added by JADX */
        public static final int actionViewClass = 2130903076;

        /* JADX INFO: Added by JADX */
        public static final int activityChooserViewStyle = 2130903077;

        /* JADX INFO: Added by JADX */
        public static final int alertDialogButtonGroupStyle = 2130903078;

        /* JADX INFO: Added by JADX */
        public static final int alertDialogCenterButtons = 2130903079;

        /* JADX INFO: Added by JADX */
        public static final int alertDialogStyle = 2130903080;

        /* JADX INFO: Added by JADX */
        public static final int alertDialogTheme = 2130903081;

        /* JADX INFO: Added by JADX */
        public static final int allowStacking = 2130903082;

        /* JADX INFO: Added by JADX */
        public static final int alpha = 2130903083;

        /* JADX INFO: Added by JADX */
        public static final int alphabeticModifiers = 2130903084;

        /* JADX INFO: Added by JADX */
        public static final int altSrc = 2130903085;

        /* JADX INFO: Added by JADX */
        public static final int animateCircleAngleTo = 2130903086;

        /* JADX INFO: Added by JADX */
        public static final int animateRelativeTo = 2130903087;

        /* JADX INFO: Added by JADX */
        public static final int applyMotionScene = 2130903088;

        /* JADX INFO: Added by JADX */
        public static final int arcMode = 2130903089;

        /* JADX INFO: Added by JADX */
        public static final int arrowHeadLength = 2130903090;

        /* JADX INFO: Added by JADX */
        public static final int arrowShaftLength = 2130903091;

        /* JADX INFO: Added by JADX */
        public static final int attributeName = 2130903092;

        /* JADX INFO: Added by JADX */
        public static final int autoCompleteMode = 2130903093;

        /* JADX INFO: Added by JADX */
        public static final int autoCompleteTextViewStyle = 2130903094;

        /* JADX INFO: Added by JADX */
        public static final int autoSizeMaxTextSize = 2130903095;

        /* JADX INFO: Added by JADX */
        public static final int autoSizeMinTextSize = 2130903096;

        /* JADX INFO: Added by JADX */
        public static final int autoSizePresetSizes = 2130903097;

        /* JADX INFO: Added by JADX */
        public static final int autoSizeStepGranularity = 2130903098;

        /* JADX INFO: Added by JADX */
        public static final int autoSizeTextType = 2130903099;

        /* JADX INFO: Added by JADX */
        public static final int autoTransition = 2130903100;

        /* JADX INFO: Added by JADX */
        public static final int background = 2130903101;

        /* JADX INFO: Added by JADX */
        public static final int backgroundSplit = 2130903102;

        /* JADX INFO: Added by JADX */
        public static final int backgroundStacked = 2130903103;

        /* JADX INFO: Added by JADX */
        public static final int backgroundTint = 2130903104;

        /* JADX INFO: Added by JADX */
        public static final int backgroundTintMode = 2130903105;

        /* JADX INFO: Added by JADX */
        public static final int barLength = 2130903106;

        /* JADX INFO: Added by JADX */
        public static final int barrierAllowsGoneWidgets = 2130903107;

        /* JADX INFO: Added by JADX */
        public static final int barrierDirection = 2130903108;

        /* JADX INFO: Added by JADX */
        public static final int barrierMargin = 2130903109;

        /* JADX INFO: Added by JADX */
        public static final int blendSrc = 2130903110;

        /* JADX INFO: Added by JADX */
        public static final int borderRound = 2130903111;

        /* JADX INFO: Added by JADX */
        public static final int borderRoundPercent = 2130903112;

        /* JADX INFO: Added by JADX */
        public static final int borderlessButtonStyle = 2130903113;

        /* JADX INFO: Added by JADX */
        public static final int brightness = 2130903114;

        /* JADX INFO: Added by JADX */
        public static final int buttonBarButtonStyle = 2130903115;

        /* JADX INFO: Added by JADX */
        public static final int buttonBarNegativeButtonStyle = 2130903116;

        /* JADX INFO: Added by JADX */
        public static final int buttonBarNeutralButtonStyle = 2130903117;

        /* JADX INFO: Added by JADX */
        public static final int buttonBarPositiveButtonStyle = 2130903118;

        /* JADX INFO: Added by JADX */
        public static final int buttonBarStyle = 2130903119;

        /* JADX INFO: Added by JADX */
        public static final int buttonCompat = 2130903120;

        /* JADX INFO: Added by JADX */
        public static final int buttonGravity = 2130903121;

        /* JADX INFO: Added by JADX */
        public static final int buttonIconDimen = 2130903122;

        /* JADX INFO: Added by JADX */
        public static final int buttonPanelSideLayout = 2130903123;

        /* JADX INFO: Added by JADX */
        public static final int buttonStyle = 2130903124;

        /* JADX INFO: Added by JADX */
        public static final int buttonStyleSmall = 2130903125;

        /* JADX INFO: Added by JADX */
        public static final int buttonTint = 2130903126;

        /* JADX INFO: Added by JADX */
        public static final int buttonTintMode = 2130903127;

        /* JADX INFO: Added by JADX */
        public static final int carousel_backwardTransition = 2130903128;

        /* JADX INFO: Added by JADX */
        public static final int carousel_emptyViewsBehavior = 2130903129;

        /* JADX INFO: Added by JADX */
        public static final int carousel_firstView = 2130903130;

        /* JADX INFO: Added by JADX */
        public static final int carousel_forwardTransition = 2130903131;

        /* JADX INFO: Added by JADX */
        public static final int carousel_infinite = 2130903132;

        /* JADX INFO: Added by JADX */
        public static final int carousel_nextState = 2130903133;

        /* JADX INFO: Added by JADX */
        public static final int carousel_previousState = 2130903134;

        /* JADX INFO: Added by JADX */
        public static final int carousel_touchUpMode = 2130903135;

        /* JADX INFO: Added by JADX */
        public static final int carousel_touchUp_dampeningFactor = 2130903136;

        /* JADX INFO: Added by JADX */
        public static final int carousel_touchUp_velocityThreshold = 2130903137;

        /* JADX INFO: Added by JADX */
        public static final int chainUseRtl = 2130903138;

        /* JADX INFO: Added by JADX */
        public static final int checkMarkCompat = 2130903139;

        /* JADX INFO: Added by JADX */
        public static final int checkMarkTint = 2130903140;

        /* JADX INFO: Added by JADX */
        public static final int checkMarkTintMode = 2130903141;

        /* JADX INFO: Added by JADX */
        public static final int checkboxStyle = 2130903142;

        /* JADX INFO: Added by JADX */
        public static final int checkedTextViewStyle = 2130903143;

        /* JADX INFO: Added by JADX */
        public static final int circleRadius = 2130903144;

        /* JADX INFO: Added by JADX */
        public static final int circularflow_angles = 2130903145;

        /* JADX INFO: Added by JADX */
        public static final int circularflow_defaultAngle = 2130903146;

        /* JADX INFO: Added by JADX */
        public static final int circularflow_defaultRadius = 2130903147;

        /* JADX INFO: Added by JADX */
        public static final int circularflow_radiusInDP = 2130903148;

        /* JADX INFO: Added by JADX */
        public static final int circularflow_viewCenter = 2130903149;

        /* JADX INFO: Added by JADX */
        public static final int clearsTag = 2130903150;

        /* JADX INFO: Added by JADX */
        public static final int clickAction = 2130903151;

        /* JADX INFO: Added by JADX */
        public static final int closeIcon = 2130903152;

        /* JADX INFO: Added by JADX */
        public static final int closeItemLayout = 2130903153;

        /* JADX INFO: Added by JADX */
        public static final int collapseContentDescription = 2130903154;

        /* JADX INFO: Added by JADX */
        public static final int collapseIcon = 2130903155;

        /* JADX INFO: Added by JADX */
        public static final int color = 2130903156;

        /* JADX INFO: Added by JADX */
        public static final int colorAccent = 2130903157;

        /* JADX INFO: Added by JADX */
        public static final int colorBackgroundFloating = 2130903158;

        /* JADX INFO: Added by JADX */
        public static final int colorButtonNormal = 2130903159;

        /* JADX INFO: Added by JADX */
        public static final int colorControlActivated = 2130903160;

        /* JADX INFO: Added by JADX */
        public static final int colorControlHighlight = 2130903161;

        /* JADX INFO: Added by JADX */
        public static final int colorControlNormal = 2130903162;

        /* JADX INFO: Added by JADX */
        public static final int colorError = 2130903163;

        /* JADX INFO: Added by JADX */
        public static final int colorPrimary = 2130903164;

        /* JADX INFO: Added by JADX */
        public static final int colorPrimaryDark = 2130903165;

        /* JADX INFO: Added by JADX */
        public static final int colorSwitchThumbNormal = 2130903166;

        /* JADX INFO: Added by JADX */
        public static final int commitIcon = 2130903167;

        /* JADX INFO: Added by JADX */
        public static final int constraintRotate = 2130903168;

        /* JADX INFO: Added by JADX */
        public static final int constraintSet = 2130903169;

        /* JADX INFO: Added by JADX */
        public static final int constraintSetEnd = 2130903170;

        /* JADX INFO: Added by JADX */
        public static final int constraintSetStart = 2130903171;

        /* JADX INFO: Added by JADX */
        public static final int constraint_referenced_ids = 2130903172;

        /* JADX INFO: Added by JADX */
        public static final int constraint_referenced_tags = 2130903173;

        /* JADX INFO: Added by JADX */
        public static final int constraints = 2130903174;

        /* JADX INFO: Added by JADX */
        public static final int content = 2130903175;

        /* JADX INFO: Added by JADX */
        public static final int contentDescription = 2130903176;

        /* JADX INFO: Added by JADX */
        public static final int contentInsetEnd = 2130903177;

        /* JADX INFO: Added by JADX */
        public static final int contentInsetEndWithActions = 2130903178;

        /* JADX INFO: Added by JADX */
        public static final int contentInsetLeft = 2130903179;

        /* JADX INFO: Added by JADX */
        public static final int contentInsetRight = 2130903180;

        /* JADX INFO: Added by JADX */
        public static final int contentInsetStart = 2130903181;

        /* JADX INFO: Added by JADX */
        public static final int contentInsetStartWithNavigation = 2130903182;

        /* JADX INFO: Added by JADX */
        public static final int contrast = 2130903183;

        /* JADX INFO: Added by JADX */
        public static final int controlBackground = 2130903184;

        /* JADX INFO: Added by JADX */
        public static final int crossfade = 2130903185;

        /* JADX INFO: Added by JADX */
        public static final int currentState = 2130903186;

        /* JADX INFO: Added by JADX */
        public static final int curveFit = 2130903187;

        /* JADX INFO: Added by JADX */
        public static final int customBoolean = 2130903188;

        /* JADX INFO: Added by JADX */
        public static final int customColorDrawableValue = 2130903189;

        /* JADX INFO: Added by JADX */
        public static final int customColorValue = 2130903190;

        /* JADX INFO: Added by JADX */
        public static final int customDimension = 2130903191;

        /* JADX INFO: Added by JADX */
        public static final int customFloatValue = 2130903192;

        /* JADX INFO: Added by JADX */
        public static final int customIntegerValue = 2130903193;

        /* JADX INFO: Added by JADX */
        public static final int customNavigationLayout = 2130903194;

        /* JADX INFO: Added by JADX */
        public static final int customPixelDimension = 2130903195;

        /* JADX INFO: Added by JADX */
        public static final int customReference = 2130903196;

        /* JADX INFO: Added by JADX */
        public static final int customStringValue = 2130903197;

        /* JADX INFO: Added by JADX */
        public static final int defaultDuration = 2130903198;

        /* JADX INFO: Added by JADX */
        public static final int defaultQueryHint = 2130903199;

        /* JADX INFO: Added by JADX */
        public static final int defaultState = 2130903200;

        /* JADX INFO: Added by JADX */
        public static final int deltaPolarAngle = 2130903201;

        /* JADX INFO: Added by JADX */
        public static final int deltaPolarRadius = 2130903202;

        /* JADX INFO: Added by JADX */
        public static final int deriveConstraintsFrom = 2130903203;

        /* JADX INFO: Added by JADX */
        public static final int dialogCornerRadius = 2130903204;

        /* JADX INFO: Added by JADX */
        public static final int dialogPreferredPadding = 2130903205;

        /* JADX INFO: Added by JADX */
        public static final int dialogTheme = 2130903206;

        /* JADX INFO: Added by JADX */
        public static final int displayOptions = 2130903207;

        /* JADX INFO: Added by JADX */
        public static final int divider = 2130903208;

        /* JADX INFO: Added by JADX */
        public static final int dividerHorizontal = 2130903209;

        /* JADX INFO: Added by JADX */
        public static final int dividerPadding = 2130903210;

        /* JADX INFO: Added by JADX */
        public static final int dividerVertical = 2130903211;

        /* JADX INFO: Added by JADX */
        public static final int dragDirection = 2130903212;

        /* JADX INFO: Added by JADX */
        public static final int dragScale = 2130903213;

        /* JADX INFO: Added by JADX */
        public static final int dragThreshold = 2130903214;

        /* JADX INFO: Added by JADX */
        public static final int drawPath = 2130903215;

        /* JADX INFO: Added by JADX */
        public static final int drawableBottomCompat = 2130903216;

        /* JADX INFO: Added by JADX */
        public static final int drawableEndCompat = 2130903217;

        /* JADX INFO: Added by JADX */
        public static final int drawableLeftCompat = 2130903218;

        /* JADX INFO: Added by JADX */
        public static final int drawableRightCompat = 2130903219;

        /* JADX INFO: Added by JADX */
        public static final int drawableSize = 2130903220;

        /* JADX INFO: Added by JADX */
        public static final int drawableStartCompat = 2130903221;

        /* JADX INFO: Added by JADX */
        public static final int drawableTint = 2130903222;

        /* JADX INFO: Added by JADX */
        public static final int drawableTintMode = 2130903223;

        /* JADX INFO: Added by JADX */
        public static final int drawableTopCompat = 2130903224;

        /* JADX INFO: Added by JADX */
        public static final int drawerArrowStyle = 2130903225;

        /* JADX INFO: Added by JADX */
        public static final int dropDownListViewStyle = 2130903226;

        /* JADX INFO: Added by JADX */
        public static final int dropdownListPreferredItemHeight = 2130903227;

        /* JADX INFO: Added by JADX */
        public static final int duration = 2130903228;

        /* JADX INFO: Added by JADX */
        public static final int editTextBackground = 2130903229;

        /* JADX INFO: Added by JADX */
        public static final int editTextColor = 2130903230;

        /* JADX INFO: Added by JADX */
        public static final int editTextStyle = 2130903231;

        /* JADX INFO: Added by JADX */
        public static final int elevation = 2130903232;

        /* JADX INFO: Added by JADX */
        public static final int emojiCompatEnabled = 2130903233;

        /* JADX INFO: Added by JADX */
        public static final int expandActivityOverflowButtonDrawable = 2130903234;

        /* JADX INFO: Added by JADX */
        public static final int firstBaselineToTopHeight = 2130903235;

        /* JADX INFO: Added by JADX */
        public static final int flow_firstHorizontalBias = 2130903236;

        /* JADX INFO: Added by JADX */
        public static final int flow_firstHorizontalStyle = 2130903237;

        /* JADX INFO: Added by JADX */
        public static final int flow_firstVerticalBias = 2130903238;

        /* JADX INFO: Added by JADX */
        public static final int flow_firstVerticalStyle = 2130903239;

        /* JADX INFO: Added by JADX */
        public static final int flow_horizontalAlign = 2130903240;

        /* JADX INFO: Added by JADX */
        public static final int flow_horizontalBias = 2130903241;

        /* JADX INFO: Added by JADX */
        public static final int flow_horizontalGap = 2130903242;

        /* JADX INFO: Added by JADX */
        public static final int flow_horizontalStyle = 2130903243;

        /* JADX INFO: Added by JADX */
        public static final int flow_lastHorizontalBias = 2130903244;

        /* JADX INFO: Added by JADX */
        public static final int flow_lastHorizontalStyle = 2130903245;

        /* JADX INFO: Added by JADX */
        public static final int flow_lastVerticalBias = 2130903246;

        /* JADX INFO: Added by JADX */
        public static final int flow_lastVerticalStyle = 2130903247;

        /* JADX INFO: Added by JADX */
        public static final int flow_maxElementsWrap = 2130903248;

        /* JADX INFO: Added by JADX */
        public static final int flow_padding = 2130903249;

        /* JADX INFO: Added by JADX */
        public static final int flow_verticalAlign = 2130903250;

        /* JADX INFO: Added by JADX */
        public static final int flow_verticalBias = 2130903251;

        /* JADX INFO: Added by JADX */
        public static final int flow_verticalGap = 2130903252;

        /* JADX INFO: Added by JADX */
        public static final int flow_verticalStyle = 2130903253;

        /* JADX INFO: Added by JADX */
        public static final int flow_wrapMode = 2130903254;

        /* JADX INFO: Added by JADX */
        public static final int font = 2130903255;

        /* JADX INFO: Added by JADX */
        public static final int fontFamily = 2130903256;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderAuthority = 2130903257;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderCerts = 2130903258;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderFetchStrategy = 2130903259;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderFetchTimeout = 2130903260;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderPackage = 2130903261;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderQuery = 2130903262;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderSystemFontFamily = 2130903263;

        /* JADX INFO: Added by JADX */
        public static final int fontStyle = 2130903264;

        /* JADX INFO: Added by JADX */
        public static final int fontVariationSettings = 2130903265;

        /* JADX INFO: Added by JADX */
        public static final int fontWeight = 2130903266;

        /* JADX INFO: Added by JADX */
        public static final int framePosition = 2130903267;

        /* JADX INFO: Added by JADX */
        public static final int gapBetweenBars = 2130903268;

        /* JADX INFO: Added by JADX */
        public static final int goIcon = 2130903269;

        /* JADX INFO: Added by JADX */
        public static final int grid_columnWeights = 2130903270;

        /* JADX INFO: Added by JADX */
        public static final int grid_columns = 2130903271;

        /* JADX INFO: Added by JADX */
        public static final int grid_horizontalGaps = 2130903272;

        /* JADX INFO: Added by JADX */
        public static final int grid_orientation = 2130903273;

        /* JADX INFO: Added by JADX */
        public static final int grid_rowWeights = 2130903274;

        /* JADX INFO: Added by JADX */
        public static final int grid_rows = 2130903275;

        /* JADX INFO: Added by JADX */
        public static final int grid_skips = 2130903276;

        /* JADX INFO: Added by JADX */
        public static final int grid_spans = 2130903277;

        /* JADX INFO: Added by JADX */
        public static final int grid_useRtl = 2130903278;

        /* JADX INFO: Added by JADX */
        public static final int grid_validateInputs = 2130903279;

        /* JADX INFO: Added by JADX */
        public static final int grid_verticalGaps = 2130903280;

        /* JADX INFO: Added by JADX */
        public static final int guidelineUseRtl = 2130903281;

        /* JADX INFO: Added by JADX */
        public static final int height = 2130903282;

        /* JADX INFO: Added by JADX */
        public static final int hideOnContentScroll = 2130903283;

        /* JADX INFO: Added by JADX */
        public static final int homeAsUpIndicator = 2130903284;

        /* JADX INFO: Added by JADX */
        public static final int homeLayout = 2130903285;

        /* JADX INFO: Added by JADX */
        public static final int icon = 2130903286;

        /* JADX INFO: Added by JADX */
        public static final int iconTint = 2130903287;

        /* JADX INFO: Added by JADX */
        public static final int iconTintMode = 2130903288;

        /* JADX INFO: Added by JADX */
        public static final int iconifiedByDefault = 2130903289;

        /* JADX INFO: Added by JADX */
        public static final int ifTagNotSet = 2130903290;

        /* JADX INFO: Added by JADX */
        public static final int ifTagSet = 2130903291;

        /* JADX INFO: Added by JADX */
        public static final int imageButtonStyle = 2130903292;

        /* JADX INFO: Added by JADX */
        public static final int imagePanX = 2130903293;

        /* JADX INFO: Added by JADX */
        public static final int imagePanY = 2130903294;

        /* JADX INFO: Added by JADX */
        public static final int imageRotate = 2130903295;

        /* JADX INFO: Added by JADX */
        public static final int imageZoom = 2130903296;

        /* JADX INFO: Added by JADX */
        public static final int indeterminateProgressStyle = 2130903297;

        /* JADX INFO: Added by JADX */
        public static final int initialActivityCount = 2130903298;

        /* JADX INFO: Added by JADX */
        public static final int isLightTheme = 2130903299;

        /* JADX INFO: Added by JADX */
        public static final int itemPadding = 2130903300;

        /* JADX INFO: Added by JADX */
        public static final int keyPositionType = 2130903301;

        /* JADX INFO: Added by JADX */
        public static final int lStar = 2130903302;

        /* JADX INFO: Added by JADX */
        public static final int lastBaselineToBottomHeight = 2130903303;

        /* JADX INFO: Added by JADX */
        public static final int layout = 2130903304;

        /* JADX INFO: Added by JADX */
        public static final int layoutDescription = 2130903305;

        /* JADX INFO: Added by JADX */
        public static final int layoutDuringTransition = 2130903306;

        /* JADX INFO: Added by JADX */
        public static final int layout_constrainedHeight = 2130903307;

        /* JADX INFO: Added by JADX */
        public static final int layout_constrainedWidth = 2130903308;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintBaseline_creator = 2130903309;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintBaseline_toBaselineOf = 2130903310;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintBaseline_toBottomOf = 2130903311;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintBaseline_toTopOf = 2130903312;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintBottom_creator = 2130903313;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintBottom_toBottomOf = 2130903314;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintBottom_toTopOf = 2130903315;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintCircle = 2130903316;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintCircleAngle = 2130903317;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintCircleRadius = 2130903318;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintDimensionRatio = 2130903319;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintEnd_toEndOf = 2130903320;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintEnd_toStartOf = 2130903321;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintGuide_begin = 2130903322;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintGuide_end = 2130903323;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintGuide_percent = 2130903324;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintHeight = 2130903325;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintHeight_default = 2130903326;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintHeight_max = 2130903327;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintHeight_min = 2130903328;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintHeight_percent = 2130903329;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintHorizontal_bias = 2130903330;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintHorizontal_chainStyle = 2130903331;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintHorizontal_weight = 2130903332;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintLeft_creator = 2130903333;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintLeft_toLeftOf = 2130903334;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintLeft_toRightOf = 2130903335;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintRight_creator = 2130903336;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintRight_toLeftOf = 2130903337;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintRight_toRightOf = 2130903338;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintStart_toEndOf = 2130903339;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintStart_toStartOf = 2130903340;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintTag = 2130903341;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintTop_creator = 2130903342;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintTop_toBottomOf = 2130903343;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintTop_toTopOf = 2130903344;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintVertical_bias = 2130903345;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintVertical_chainStyle = 2130903346;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintVertical_weight = 2130903347;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintWidth = 2130903348;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintWidth_default = 2130903349;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintWidth_max = 2130903350;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintWidth_min = 2130903351;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintWidth_percent = 2130903352;

        /* JADX INFO: Added by JADX */
        public static final int layout_editor_absoluteX = 2130903353;

        /* JADX INFO: Added by JADX */
        public static final int layout_editor_absoluteY = 2130903354;

        /* JADX INFO: Added by JADX */
        public static final int layout_goneMarginBaseline = 2130903355;

        /* JADX INFO: Added by JADX */
        public static final int layout_goneMarginBottom = 2130903356;

        /* JADX INFO: Added by JADX */
        public static final int layout_goneMarginEnd = 2130903357;

        /* JADX INFO: Added by JADX */
        public static final int layout_goneMarginLeft = 2130903358;

        /* JADX INFO: Added by JADX */
        public static final int layout_goneMarginRight = 2130903359;

        /* JADX INFO: Added by JADX */
        public static final int layout_goneMarginStart = 2130903360;

        /* JADX INFO: Added by JADX */
        public static final int layout_goneMarginTop = 2130903361;

        /* JADX INFO: Added by JADX */
        public static final int layout_marginBaseline = 2130903362;

        /* JADX INFO: Added by JADX */
        public static final int layout_optimizationLevel = 2130903363;

        /* JADX INFO: Added by JADX */
        public static final int layout_wrapBehaviorInParent = 2130903364;

        /* JADX INFO: Added by JADX */
        public static final int limitBoundsTo = 2130903365;

        /* JADX INFO: Added by JADX */
        public static final int lineHeight = 2130903366;

        /* JADX INFO: Added by JADX */
        public static final int listChoiceBackgroundIndicator = 2130903367;

        /* JADX INFO: Added by JADX */
        public static final int listChoiceIndicatorMultipleAnimated = 2130903368;

        /* JADX INFO: Added by JADX */
        public static final int listChoiceIndicatorSingleAnimated = 2130903369;

        /* JADX INFO: Added by JADX */
        public static final int listDividerAlertDialog = 2130903370;

        /* JADX INFO: Added by JADX */
        public static final int listItemLayout = 2130903371;

        /* JADX INFO: Added by JADX */
        public static final int listLayout = 2130903372;

        /* JADX INFO: Added by JADX */
        public static final int listMenuViewStyle = 2130903373;

        /* JADX INFO: Added by JADX */
        public static final int listPopupWindowStyle = 2130903374;

        /* JADX INFO: Added by JADX */
        public static final int listPreferredItemHeight = 2130903375;

        /* JADX INFO: Added by JADX */
        public static final int listPreferredItemHeightLarge = 2130903376;

        /* JADX INFO: Added by JADX */
        public static final int listPreferredItemHeightSmall = 2130903377;

        /* JADX INFO: Added by JADX */
        public static final int listPreferredItemPaddingEnd = 2130903378;

        /* JADX INFO: Added by JADX */
        public static final int listPreferredItemPaddingLeft = 2130903379;

        /* JADX INFO: Added by JADX */
        public static final int listPreferredItemPaddingRight = 2130903380;

        /* JADX INFO: Added by JADX */
        public static final int listPreferredItemPaddingStart = 2130903381;

        /* JADX INFO: Added by JADX */
        public static final int logo = 2130903382;

        /* JADX INFO: Added by JADX */
        public static final int logoDescription = 2130903383;

        /* JADX INFO: Added by JADX */
        public static final int maxAcceleration = 2130903384;

        /* JADX INFO: Added by JADX */
        public static final int maxButtonHeight = 2130903385;

        /* JADX INFO: Added by JADX */
        public static final int maxHeight = 2130903386;

        /* JADX INFO: Added by JADX */
        public static final int maxVelocity = 2130903387;

        /* JADX INFO: Added by JADX */
        public static final int maxWidth = 2130903388;

        /* JADX INFO: Added by JADX */
        public static final int measureWithLargestChild = 2130903389;

        /* JADX INFO: Added by JADX */
        public static final int menu = 2130903390;

        /* JADX INFO: Added by JADX */
        public static final int methodName = 2130903391;

        /* JADX INFO: Added by JADX */
        public static final int minHeight = 2130903392;

        /* JADX INFO: Added by JADX */
        public static final int minWidth = 2130903393;

        /* JADX INFO: Added by JADX */
        public static final int mock_diagonalsColor = 2130903394;

        /* JADX INFO: Added by JADX */
        public static final int mock_label = 2130903395;

        /* JADX INFO: Added by JADX */
        public static final int mock_labelBackgroundColor = 2130903396;

        /* JADX INFO: Added by JADX */
        public static final int mock_labelColor = 2130903397;

        /* JADX INFO: Added by JADX */
        public static final int mock_showDiagonals = 2130903398;

        /* JADX INFO: Added by JADX */
        public static final int mock_showLabel = 2130903399;

        /* JADX INFO: Added by JADX */
        public static final int motionDebug = 2130903400;

        /* JADX INFO: Added by JADX */
        public static final int motionEffect_alpha = 2130903401;

        /* JADX INFO: Added by JADX */
        public static final int motionEffect_end = 2130903402;

        /* JADX INFO: Added by JADX */
        public static final int motionEffect_move = 2130903403;

        /* JADX INFO: Added by JADX */
        public static final int motionEffect_start = 2130903404;

        /* JADX INFO: Added by JADX */
        public static final int motionEffect_strict = 2130903405;

        /* JADX INFO: Added by JADX */
        public static final int motionEffect_translationX = 2130903406;

        /* JADX INFO: Added by JADX */
        public static final int motionEffect_translationY = 2130903407;

        /* JADX INFO: Added by JADX */
        public static final int motionEffect_viewTransition = 2130903408;

        /* JADX INFO: Added by JADX */
        public static final int motionInterpolator = 2130903409;

        /* JADX INFO: Added by JADX */
        public static final int motionPathRotate = 2130903410;

        /* JADX INFO: Added by JADX */
        public static final int motionProgress = 2130903411;

        /* JADX INFO: Added by JADX */
        public static final int motionStagger = 2130903412;

        /* JADX INFO: Added by JADX */
        public static final int motionTarget = 2130903413;

        /* JADX INFO: Added by JADX */
        public static final int motion_postLayoutCollision = 2130903414;

        /* JADX INFO: Added by JADX */
        public static final int motion_triggerOnCollision = 2130903415;

        /* JADX INFO: Added by JADX */
        public static final int moveWhenScrollAtTop = 2130903416;

        /* JADX INFO: Added by JADX */
        public static final int multiChoiceItemLayout = 2130903417;

        /* JADX INFO: Added by JADX */
        public static final int navigationContentDescription = 2130903418;

        /* JADX INFO: Added by JADX */
        public static final int navigationIcon = 2130903419;

        /* JADX INFO: Added by JADX */
        public static final int navigationMode = 2130903420;

        /* JADX INFO: Added by JADX */
        public static final int nestedScrollFlags = 2130903421;

        /* JADX INFO: Added by JADX */
        public static final int nestedScrollViewStyle = 2130903422;

        /* JADX INFO: Added by JADX */
        public static final int numericModifiers = 2130903423;

        /* JADX INFO: Added by JADX */
        public static final int onCross = 2130903424;

        /* JADX INFO: Added by JADX */
        public static final int onHide = 2130903425;

        /* JADX INFO: Added by JADX */
        public static final int onNegativeCross = 2130903426;

        /* JADX INFO: Added by JADX */
        public static final int onPositiveCross = 2130903427;

        /* JADX INFO: Added by JADX */
        public static final int onShow = 2130903428;

        /* JADX INFO: Added by JADX */
        public static final int onStateTransition = 2130903429;

        /* JADX INFO: Added by JADX */
        public static final int onTouchUp = 2130903430;

        /* JADX INFO: Added by JADX */
        public static final int overlapAnchor = 2130903431;

        /* JADX INFO: Added by JADX */
        public static final int overlay = 2130903432;

        /* JADX INFO: Added by JADX */
        public static final int paddingBottomNoButtons = 2130903433;

        /* JADX INFO: Added by JADX */
        public static final int paddingEnd = 2130903434;

        /* JADX INFO: Added by JADX */
        public static final int paddingStart = 2130903435;

        /* JADX INFO: Added by JADX */
        public static final int paddingTopNoTitle = 2130903436;

        /* JADX INFO: Added by JADX */
        public static final int panelBackground = 2130903437;

        /* JADX INFO: Added by JADX */
        public static final int panelMenuListTheme = 2130903438;

        /* JADX INFO: Added by JADX */
        public static final int panelMenuListWidth = 2130903439;

        /* JADX INFO: Added by JADX */
        public static final int pathMotionArc = 2130903440;

        /* JADX INFO: Added by JADX */
        public static final int path_percent = 2130903441;

        /* JADX INFO: Added by JADX */
        public static final int percentHeight = 2130903442;

        /* JADX INFO: Added by JADX */
        public static final int percentWidth = 2130903443;

        /* JADX INFO: Added by JADX */
        public static final int percentX = 2130903444;

        /* JADX INFO: Added by JADX */
        public static final int percentY = 2130903445;

        /* JADX INFO: Added by JADX */
        public static final int perpendicularPath_percent = 2130903446;

        /* JADX INFO: Added by JADX */
        public static final int pivotAnchor = 2130903447;

        /* JADX INFO: Added by JADX */
        public static final int placeholder_emptyVisibility = 2130903448;

        /* JADX INFO: Added by JADX */
        public static final int polarRelativeTo = 2130903449;

        /* JADX INFO: Added by JADX */
        public static final int popupMenuStyle = 2130903450;

        /* JADX INFO: Added by JADX */
        public static final int popupTheme = 2130903451;

        /* JADX INFO: Added by JADX */
        public static final int popupWindowStyle = 2130903452;

        /* JADX INFO: Added by JADX */
        public static final int preserveIconSpacing = 2130903453;

        /* JADX INFO: Added by JADX */
        public static final int progressBarPadding = 2130903454;

        /* JADX INFO: Added by JADX */
        public static final int progressBarStyle = 2130903455;

        /* JADX INFO: Added by JADX */
        public static final int quantizeMotionInterpolator = 2130903456;

        /* JADX INFO: Added by JADX */
        public static final int quantizeMotionPhase = 2130903457;

        /* JADX INFO: Added by JADX */
        public static final int quantizeMotionSteps = 2130903458;

        /* JADX INFO: Added by JADX */
        public static final int queryBackground = 2130903459;

        /* JADX INFO: Added by JADX */
        public static final int queryHint = 2130903460;

        /* JADX INFO: Added by JADX */
        public static final int queryPatterns = 2130903461;

        /* JADX INFO: Added by JADX */
        public static final int radioButtonStyle = 2130903462;

        /* JADX INFO: Added by JADX */
        public static final int ratingBarStyle = 2130903463;

        /* JADX INFO: Added by JADX */
        public static final int ratingBarStyleIndicator = 2130903464;

        /* JADX INFO: Added by JADX */
        public static final int ratingBarStyleSmall = 2130903465;

        /* JADX INFO: Added by JADX */
        public static final int reactiveGuide_animateChange = 2130903466;

        /* JADX INFO: Added by JADX */
        public static final int reactiveGuide_applyToAllConstraintSets = 2130903467;

        /* JADX INFO: Added by JADX */
        public static final int reactiveGuide_applyToConstraintSet = 2130903468;

        /* JADX INFO: Added by JADX */
        public static final int reactiveGuide_valueId = 2130903469;

        /* JADX INFO: Added by JADX */
        public static final int region_heightLessThan = 2130903470;

        /* JADX INFO: Added by JADX */
        public static final int region_heightMoreThan = 2130903471;

        /* JADX INFO: Added by JADX */
        public static final int region_widthLessThan = 2130903472;

        /* JADX INFO: Added by JADX */
        public static final int region_widthMoreThan = 2130903473;

        /* JADX INFO: Added by JADX */
        public static final int rotationCenterId = 2130903474;

        /* JADX INFO: Added by JADX */
        public static final int round = 2130903475;

        /* JADX INFO: Added by JADX */
        public static final int roundPercent = 2130903476;

        /* JADX INFO: Added by JADX */
        public static final int saturation = 2130903477;

        /* JADX INFO: Added by JADX */
        public static final int scaleFromTextSize = 2130903478;

        /* JADX INFO: Added by JADX */
        public static final int searchHintIcon = 2130903479;

        /* JADX INFO: Added by JADX */
        public static final int searchIcon = 2130903480;

        /* JADX INFO: Added by JADX */
        public static final int searchViewStyle = 2130903481;

        /* JADX INFO: Added by JADX */
        public static final int seekBarStyle = 2130903482;

        /* JADX INFO: Added by JADX */
        public static final int selectableItemBackground = 2130903483;

        /* JADX INFO: Added by JADX */
        public static final int selectableItemBackgroundBorderless = 2130903484;

        /* JADX INFO: Added by JADX */
        public static final int setsTag = 2130903485;

        /* JADX INFO: Added by JADX */
        public static final int shortcutMatchRequired = 2130903486;

        /* JADX INFO: Added by JADX */
        public static final int showAsAction = 2130903487;

        /* JADX INFO: Added by JADX */
        public static final int showDividers = 2130903488;

        /* JADX INFO: Added by JADX */
        public static final int showPaths = 2130903489;

        /* JADX INFO: Added by JADX */
        public static final int showText = 2130903490;

        /* JADX INFO: Added by JADX */
        public static final int showTitle = 2130903491;

        /* JADX INFO: Added by JADX */
        public static final int singleChoiceItemLayout = 2130903492;

        /* JADX INFO: Added by JADX */
        public static final int sizePercent = 2130903493;

        /* JADX INFO: Added by JADX */
        public static final int spinBars = 2130903494;

        /* JADX INFO: Added by JADX */
        public static final int spinnerDropDownItemStyle = 2130903495;

        /* JADX INFO: Added by JADX */
        public static final int spinnerStyle = 2130903496;

        /* JADX INFO: Added by JADX */
        public static final int splitTrack = 2130903497;

        /* JADX INFO: Added by JADX */
        public static final int springBoundary = 2130903498;

        /* JADX INFO: Added by JADX */
        public static final int springDamping = 2130903499;

        /* JADX INFO: Added by JADX */
        public static final int springMass = 2130903500;

        /* JADX INFO: Added by JADX */
        public static final int springStiffness = 2130903501;

        /* JADX INFO: Added by JADX */
        public static final int springStopThreshold = 2130903502;

        /* JADX INFO: Added by JADX */
        public static final int srcCompat = 2130903503;

        /* JADX INFO: Added by JADX */
        public static final int staggered = 2130903504;

        /* JADX INFO: Added by JADX */
        public static final int stateLabels = 2130903505;

        /* JADX INFO: Added by JADX */
        public static final int state_above_anchor = 2130903506;

        /* JADX INFO: Added by JADX */
        public static final int subMenuArrow = 2130903507;

        /* JADX INFO: Added by JADX */
        public static final int submitBackground = 2130903508;

        /* JADX INFO: Added by JADX */
        public static final int subtitle = 2130903509;

        /* JADX INFO: Added by JADX */
        public static final int subtitleTextAppearance = 2130903510;

        /* JADX INFO: Added by JADX */
        public static final int subtitleTextColor = 2130903511;

        /* JADX INFO: Added by JADX */
        public static final int subtitleTextStyle = 2130903512;

        /* JADX INFO: Added by JADX */
        public static final int suggestionRowLayout = 2130903513;

        /* JADX INFO: Added by JADX */
        public static final int switchMinWidth = 2130903514;

        /* JADX INFO: Added by JADX */
        public static final int switchPadding = 2130903515;

        /* JADX INFO: Added by JADX */
        public static final int switchStyle = 2130903516;

        /* JADX INFO: Added by JADX */
        public static final int switchTextAppearance = 2130903517;

        /* JADX INFO: Added by JADX */
        public static final int targetId = 2130903518;

        /* JADX INFO: Added by JADX */
        public static final int telltales_tailColor = 2130903519;

        /* JADX INFO: Added by JADX */
        public static final int telltales_tailScale = 2130903520;

        /* JADX INFO: Added by JADX */
        public static final int telltales_velocityMode = 2130903521;

        /* JADX INFO: Added by JADX */
        public static final int textAllCaps = 2130903522;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceLargePopupMenu = 2130903523;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceListItem = 2130903524;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceListItemSecondary = 2130903525;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceListItemSmall = 2130903526;

        /* JADX INFO: Added by JADX */
        public static final int textAppearancePopupMenuHeader = 2130903527;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceSearchResultSubtitle = 2130903528;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceSearchResultTitle = 2130903529;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceSmallPopupMenu = 2130903530;

        /* JADX INFO: Added by JADX */
        public static final int textBackground = 2130903531;

        /* JADX INFO: Added by JADX */
        public static final int textBackgroundPanX = 2130903532;

        /* JADX INFO: Added by JADX */
        public static final int textBackgroundPanY = 2130903533;

        /* JADX INFO: Added by JADX */
        public static final int textBackgroundRotate = 2130903534;

        /* JADX INFO: Added by JADX */
        public static final int textBackgroundZoom = 2130903535;

        /* JADX INFO: Added by JADX */
        public static final int textColorAlertDialogListItem = 2130903536;

        /* JADX INFO: Added by JADX */
        public static final int textColorSearchUrl = 2130903537;

        /* JADX INFO: Added by JADX */
        public static final int textFillColor = 2130903538;

        /* JADX INFO: Added by JADX */
        public static final int textLocale = 2130903539;

        /* JADX INFO: Added by JADX */
        public static final int textOutlineColor = 2130903540;

        /* JADX INFO: Added by JADX */
        public static final int textOutlineThickness = 2130903541;

        /* JADX INFO: Added by JADX */
        public static final int textPanX = 2130903542;

        /* JADX INFO: Added by JADX */
        public static final int textPanY = 2130903543;

        /* JADX INFO: Added by JADX */
        public static final int textureBlurFactor = 2130903544;

        /* JADX INFO: Added by JADX */
        public static final int textureEffect = 2130903545;

        /* JADX INFO: Added by JADX */
        public static final int textureHeight = 2130903546;

        /* JADX INFO: Added by JADX */
        public static final int textureWidth = 2130903547;

        /* JADX INFO: Added by JADX */
        public static final int theme = 2130903548;

        /* JADX INFO: Added by JADX */
        public static final int thickness = 2130903549;

        /* JADX INFO: Added by JADX */
        public static final int thumbTextPadding = 2130903550;

        /* JADX INFO: Added by JADX */
        public static final int thumbTint = 2130903551;

        /* JADX INFO: Added by JADX */
        public static final int thumbTintMode = 2130903552;

        /* JADX INFO: Added by JADX */
        public static final int tickMark = 2130903553;

        /* JADX INFO: Added by JADX */
        public static final int tickMarkTint = 2130903554;

        /* JADX INFO: Added by JADX */
        public static final int tickMarkTintMode = 2130903555;

        /* JADX INFO: Added by JADX */
        public static final int tint = 2130903556;

        /* JADX INFO: Added by JADX */
        public static final int tintMode = 2130903557;

        /* JADX INFO: Added by JADX */
        public static final int title = 2130903558;

        /* JADX INFO: Added by JADX */
        public static final int titleMargin = 2130903559;

        /* JADX INFO: Added by JADX */
        public static final int titleMarginBottom = 2130903560;

        /* JADX INFO: Added by JADX */
        public static final int titleMarginEnd = 2130903561;

        /* JADX INFO: Added by JADX */
        public static final int titleMarginStart = 2130903562;

        /* JADX INFO: Added by JADX */
        public static final int titleMarginTop = 2130903563;

        /* JADX INFO: Added by JADX */
        public static final int titleMargins = 2130903564;

        /* JADX INFO: Added by JADX */
        public static final int titleTextAppearance = 2130903565;

        /* JADX INFO: Added by JADX */
        public static final int titleTextColor = 2130903566;

        /* JADX INFO: Added by JADX */
        public static final int titleTextStyle = 2130903567;

        /* JADX INFO: Added by JADX */
        public static final int toolbarNavigationButtonStyle = 2130903568;

        /* JADX INFO: Added by JADX */
        public static final int toolbarStyle = 2130903569;

        /* JADX INFO: Added by JADX */
        public static final int tooltipForegroundColor = 2130903570;

        /* JADX INFO: Added by JADX */
        public static final int tooltipFrameBackground = 2130903571;

        /* JADX INFO: Added by JADX */
        public static final int tooltipText = 2130903572;

        /* JADX INFO: Added by JADX */
        public static final int touchAnchorId = 2130903573;

        /* JADX INFO: Added by JADX */
        public static final int touchAnchorSide = 2130903574;

        /* JADX INFO: Added by JADX */
        public static final int touchRegionId = 2130903575;

        /* JADX INFO: Added by JADX */
        public static final int track = 2130903576;

        /* JADX INFO: Added by JADX */
        public static final int trackTint = 2130903577;

        /* JADX INFO: Added by JADX */
        public static final int trackTintMode = 2130903578;

        /* JADX INFO: Added by JADX */
        public static final int transformPivotTarget = 2130903579;

        /* JADX INFO: Added by JADX */
        public static final int transitionDisable = 2130903580;

        /* JADX INFO: Added by JADX */
        public static final int transitionEasing = 2130903581;

        /* JADX INFO: Added by JADX */
        public static final int transitionFlags = 2130903582;

        /* JADX INFO: Added by JADX */
        public static final int transitionPathRotate = 2130903583;

        /* JADX INFO: Added by JADX */
        public static final int triggerId = 2130903584;

        /* JADX INFO: Added by JADX */
        public static final int triggerReceiver = 2130903585;

        /* JADX INFO: Added by JADX */
        public static final int triggerSlack = 2130903586;

        /* JADX INFO: Added by JADX */
        public static final int ttcIndex = 2130903587;

        /* JADX INFO: Added by JADX */
        public static final int upDuration = 2130903588;

        /* JADX INFO: Added by JADX */
        public static final int viewInflaterClass = 2130903589;

        /* JADX INFO: Added by JADX */
        public static final int viewTransitionMode = 2130903590;

        /* JADX INFO: Added by JADX */
        public static final int viewTransitionOnCross = 2130903591;

        /* JADX INFO: Added by JADX */
        public static final int viewTransitionOnNegativeCross = 2130903592;

        /* JADX INFO: Added by JADX */
        public static final int viewTransitionOnPositiveCross = 2130903593;

        /* JADX INFO: Added by JADX */
        public static final int visibilityMode = 2130903594;

        /* JADX INFO: Added by JADX */
        public static final int voiceIcon = 2130903595;

        /* JADX INFO: Added by JADX */
        public static final int warmth = 2130903596;

        /* JADX INFO: Added by JADX */
        public static final int waveDecay = 2130903597;

        /* JADX INFO: Added by JADX */
        public static final int waveOffset = 2130903598;

        /* JADX INFO: Added by JADX */
        public static final int wavePeriod = 2130903599;

        /* JADX INFO: Added by JADX */
        public static final int wavePhase = 2130903600;

        /* JADX INFO: Added by JADX */
        public static final int waveShape = 2130903601;

        /* JADX INFO: Added by JADX */
        public static final int waveVariesBy = 2130903602;

        /* JADX INFO: Added by JADX */
        public static final int windowActionBar = 2130903603;

        /* JADX INFO: Added by JADX */
        public static final int windowActionBarOverlay = 2130903604;

        /* JADX INFO: Added by JADX */
        public static final int windowActionModeOverlay = 2130903605;

        /* JADX INFO: Added by JADX */
        public static final int windowFixedHeightMajor = 2130903606;

        /* JADX INFO: Added by JADX */
        public static final int windowFixedHeightMinor = 2130903607;

        /* JADX INFO: Added by JADX */
        public static final int windowFixedWidthMajor = 2130903608;

        /* JADX INFO: Added by JADX */
        public static final int windowFixedWidthMinor = 2130903609;

        /* JADX INFO: Added by JADX */
        public static final int windowMinWidthMajor = 2130903610;

        /* JADX INFO: Added by JADX */
        public static final int windowMinWidthMinor = 2130903611;

        /* JADX INFO: Added by JADX */
        public static final int windowNoTitle = 2130903612;
    }

    /* JADX INFO: Added by JADX */
    /* renamed from: com.hhssoftware.multideco.R$bool */
    public static final class bool {

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_embed_tabs = 2130968576;

        /* JADX INFO: Added by JADX */
        public static final int abc_config_actionMenuItemAllCaps = 2130968577;
    }

    /* JADX INFO: Added by JADX */
    /* renamed from: com.hhssoftware.multideco.R$dimen */
    public static final class dimen {

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_content_inset_material = 2131099648;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_content_inset_with_nav = 2131099649;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_default_height_material = 2131099650;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_default_padding_end_material = 2131099651;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_default_padding_start_material = 2131099652;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_elevation_material = 2131099653;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_icon_vertical_padding_material = 2131099654;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_overflow_padding_end_material = 2131099655;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_overflow_padding_start_material = 2131099656;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_stacked_max_height = 2131099657;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_stacked_tab_max_width = 2131099658;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_subtitle_bottom_margin_material = 2131099659;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_subtitle_top_margin_material = 2131099660;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_button_min_height_material = 2131099661;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_button_min_width_material = 2131099662;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_button_min_width_overflow_material = 2131099663;

        /* JADX INFO: Added by JADX */
        public static final int abc_alert_dialog_button_bar_height = 2131099664;

        /* JADX INFO: Added by JADX */
        public static final int abc_alert_dialog_button_dimen = 2131099665;

        /* JADX INFO: Added by JADX */
        public static final int abc_button_inset_horizontal_material = 2131099666;

        /* JADX INFO: Added by JADX */
        public static final int abc_button_inset_vertical_material = 2131099667;

        /* JADX INFO: Added by JADX */
        public static final int abc_button_padding_horizontal_material = 2131099668;

        /* JADX INFO: Added by JADX */
        public static final int abc_button_padding_vertical_material = 2131099669;

        /* JADX INFO: Added by JADX */
        public static final int abc_cascading_menus_min_smallest_width = 2131099670;

        /* JADX INFO: Added by JADX */
        public static final int abc_config_prefDialogWidth = 2131099671;

        /* JADX INFO: Added by JADX */
        public static final int abc_control_corner_material = 2131099672;

        /* JADX INFO: Added by JADX */
        public static final int abc_control_inset_material = 2131099673;

        /* JADX INFO: Added by JADX */
        public static final int abc_control_padding_material = 2131099674;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_corner_radius_material = 2131099675;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_fixed_height_major = 2131099676;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_fixed_height_minor = 2131099677;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_fixed_width_major = 2131099678;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_fixed_width_minor = 2131099679;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_list_padding_bottom_no_buttons = 2131099680;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_list_padding_top_no_title = 2131099681;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_min_width_major = 2131099682;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_min_width_minor = 2131099683;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_padding_material = 2131099684;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_padding_top_material = 2131099685;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_title_divider_material = 2131099686;

        /* JADX INFO: Added by JADX */
        public static final int abc_disabled_alpha_material_dark = 2131099687;

        /* JADX INFO: Added by JADX */
        public static final int abc_disabled_alpha_material_light = 2131099688;

        /* JADX INFO: Added by JADX */
        public static final int abc_dropdownitem_icon_width = 2131099689;

        /* JADX INFO: Added by JADX */
        public static final int abc_dropdownitem_text_padding_left = 2131099690;

        /* JADX INFO: Added by JADX */
        public static final int abc_dropdownitem_text_padding_right = 2131099691;

        /* JADX INFO: Added by JADX */
        public static final int abc_edit_text_inset_bottom_material = 2131099692;

        /* JADX INFO: Added by JADX */
        public static final int abc_edit_text_inset_horizontal_material = 2131099693;

        /* JADX INFO: Added by JADX */
        public static final int abc_edit_text_inset_top_material = 2131099694;

        /* JADX INFO: Added by JADX */
        public static final int abc_floating_window_z = 2131099695;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_item_height_large_material = 2131099696;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_item_height_material = 2131099697;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_item_height_small_material = 2131099698;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_item_padding_horizontal_material = 2131099699;

        /* JADX INFO: Added by JADX */
        public static final int abc_panel_menu_list_width = 2131099700;

        /* JADX INFO: Added by JADX */
        public static final int abc_progress_bar_height_material = 2131099701;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_view_preferred_height = 2131099702;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_view_preferred_width = 2131099703;

        /* JADX INFO: Added by JADX */
        public static final int abc_seekbar_track_background_height_material = 2131099704;

        /* JADX INFO: Added by JADX */
        public static final int abc_seekbar_track_progress_height_material = 2131099705;

        /* JADX INFO: Added by JADX */
        public static final int abc_select_dialog_padding_start_material = 2131099706;

        /* JADX INFO: Added by JADX */
        public static final int abc_star_big = 2131099707;

        /* JADX INFO: Added by JADX */
        public static final int abc_star_medium = 2131099708;

        /* JADX INFO: Added by JADX */
        public static final int abc_star_small = 2131099709;

        /* JADX INFO: Added by JADX */
        public static final int abc_switch_padding = 2131099710;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_body_1_material = 2131099711;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_body_2_material = 2131099712;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_button_material = 2131099713;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_caption_material = 2131099714;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_display_1_material = 2131099715;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_display_2_material = 2131099716;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_display_3_material = 2131099717;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_display_4_material = 2131099718;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_headline_material = 2131099719;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_large_material = 2131099720;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_medium_material = 2131099721;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_menu_header_material = 2131099722;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_menu_material = 2131099723;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_small_material = 2131099724;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_subhead_material = 2131099725;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_subtitle_material_toolbar = 2131099726;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_title_material = 2131099727;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_title_material_toolbar = 2131099728;

        /* JADX INFO: Added by JADX */
        public static final int compat_button_inset_horizontal_material = 2131099729;

        /* JADX INFO: Added by JADX */
        public static final int compat_button_inset_vertical_material = 2131099730;

        /* JADX INFO: Added by JADX */
        public static final int compat_button_padding_horizontal_material = 2131099731;

        /* JADX INFO: Added by JADX */
        public static final int compat_button_padding_vertical_material = 2131099732;

        /* JADX INFO: Added by JADX */
        public static final int compat_control_corner_material = 2131099733;

        /* JADX INFO: Added by JADX */
        public static final int compat_notification_large_icon_max_height = 2131099734;

        /* JADX INFO: Added by JADX */
        public static final int compat_notification_large_icon_max_width = 2131099735;

        /* JADX INFO: Added by JADX */
        public static final int disabled_alpha_material_dark = 2131099736;

        /* JADX INFO: Added by JADX */
        public static final int disabled_alpha_material_light = 2131099737;

        /* JADX INFO: Added by JADX */
        public static final int highlight_alpha_material_colored = 2131099738;

        /* JADX INFO: Added by JADX */
        public static final int highlight_alpha_material_dark = 2131099739;

        /* JADX INFO: Added by JADX */
        public static final int highlight_alpha_material_light = 2131099740;

        /* JADX INFO: Added by JADX */
        public static final int hint_alpha_material_dark = 2131099741;

        /* JADX INFO: Added by JADX */
        public static final int hint_alpha_material_light = 2131099742;

        /* JADX INFO: Added by JADX */
        public static final int hint_pressed_alpha_material_dark = 2131099743;

        /* JADX INFO: Added by JADX */
        public static final int hint_pressed_alpha_material_light = 2131099744;

        /* JADX INFO: Added by JADX */
        public static final int notification_action_icon_size = 2131099745;

        /* JADX INFO: Added by JADX */
        public static final int notification_action_text_size = 2131099746;

        /* JADX INFO: Added by JADX */
        public static final int notification_big_circle_margin = 2131099747;

        /* JADX INFO: Added by JADX */
        public static final int notification_content_margin_start = 2131099748;

        /* JADX INFO: Added by JADX */
        public static final int notification_large_icon_height = 2131099749;

        /* JADX INFO: Added by JADX */
        public static final int notification_large_icon_width = 2131099750;

        /* JADX INFO: Added by JADX */
        public static final int notification_main_column_padding_top = 2131099751;

        /* JADX INFO: Added by JADX */
        public static final int notification_media_narrow_margin = 2131099752;

        /* JADX INFO: Added by JADX */
        public static final int notification_right_icon_size = 2131099753;

        /* JADX INFO: Added by JADX */
        public static final int notification_right_side_padding_top = 2131099754;

        /* JADX INFO: Added by JADX */
        public static final int notification_small_icon_background_padding = 2131099755;

        /* JADX INFO: Added by JADX */
        public static final int notification_small_icon_size_as_large = 2131099756;

        /* JADX INFO: Added by JADX */
        public static final int notification_subtext_size = 2131099757;

        /* JADX INFO: Added by JADX */
        public static final int notification_top_pad = 2131099758;

        /* JADX INFO: Added by JADX */
        public static final int notification_top_pad_large_text = 2131099759;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_corner_radius = 2131099760;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_horizontal_padding = 2131099761;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_margin = 2131099762;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_precise_anchor_extra_offset = 2131099763;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_precise_anchor_threshold = 2131099764;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_vertical_padding = 2131099765;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_y_offset_non_touch = 2131099766;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_y_offset_touch = 2131099767;
    }

    /* JADX INFO: Added by JADX */
    /* renamed from: com.hhssoftware.multideco.R$integer */
    public static final class integer {

        /* JADX INFO: Added by JADX */
        public static final int abc_config_activityDefaultDur = 2131296256;

        /* JADX INFO: Added by JADX */
        public static final int abc_config_activityShortDur = 2131296257;

        /* JADX INFO: Added by JADX */
        public static final int cancel_button_image_alpha = 2131296258;

        /* JADX INFO: Added by JADX */
        public static final int config_tooltipAnimTime = 2131296259;

        /* JADX INFO: Added by JADX */
        public static final int status_bar_notification_info_maxnum = 2131296260;
    }

    /* JADX INFO: Added by JADX */
    /* renamed from: com.hhssoftware.multideco.R$interpolator */
    public static final class interpolator {

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_checked_mtrl_animation_interpolator_0 = 2131361792;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_checked_mtrl_animation_interpolator_1 = 2131361793;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_unchecked_mtrl_animation_interpolator_0 = 2131361794;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_unchecked_mtrl_animation_interpolator_1 = 2131361795;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_off_mtrl_animation_interpolator_0 = 2131361796;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_on_mtrl_animation_interpolator_0 = 2131361797;

        /* JADX INFO: Added by JADX */
        public static final int fast_out_slow_in = 2131361798;
    }

    private C0347R() {
    }
}
