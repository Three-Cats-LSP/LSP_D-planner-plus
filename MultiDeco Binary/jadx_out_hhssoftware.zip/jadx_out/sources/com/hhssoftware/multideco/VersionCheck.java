package com.hhssoftware.multideco;

import android.content.Context;
import android.content.pm.PackageManager;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Date;

/* loaded from: classes.dex */
public class VersionCheck {
    public static String CurVer = "0.00";
    private static final String VERSTATE_FILE = "verstate.file";
    public static int VerState;
    private long LastCheckDate = 0;
    private final Context context;

    /* renamed from: r */
    private int f89r;

    public VersionCheck(Context context, Boolean bool) {
        this.f89r = 0;
        this.context = context;
        if (bool.booleanValue()) {
            this.f89r = 1;
        }
    }

    private void getVerState() {
        String str = "";
        try {
            FileInputStream openFileInput = this.context.openFileInput(VERSTATE_FILE);
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(openFileInput));
            str = bufferedReader.readLine();
            bufferedReader.close();
            openFileInput.close();
        } catch (FileNotFoundException | IOException unused) {
        }
        String trim = str.trim();
        if (trim.length() > 0) {
            VerState = trim.charAt(0) - '0';
            this.LastCheckDate = Long.parseLong(trim.substring(1));
        }
    }

    private Boolean saveVerState() {
        String str = String.valueOf(VerState) + String.valueOf(this.LastCheckDate);
        this.context.deleteFile(VERSTATE_FILE);
        try {
            FileOutputStream openFileOutput = this.context.openFileOutput(VERSTATE_FILE, 0);
            PrintStream printStream = new PrintStream(openFileOutput);
            printStream.print(str);
            printStream.close();
            openFileOutput.close();
            return true;
        } catch (FileNotFoundException unused) {
            return false;
        } catch (IOException unused2) {
            return false;
        }
    }

    public Boolean newVersionCheck() {
        long time = new Date().getTime();
        getVerState();
        long j = this.LastCheckDate;
        if (259200000 + j < time && (j == 0 || checkVersion() > 0)) {
            this.LastCheckDate = time;
            saveVerState();
            return Boolean.valueOf(VerState == 2);
        }
        return false;
    }

    private int checkVersion() {
        byte b;
        int read;
        Identity identity = new Identity(this.context);
        byte[] bArr = new byte[32];
        bArr[0] = 0;
        try {
            CurVer = this.context.getPackageManager().getPackageInfo(this.context.getPackageName(), 128).versionName;
        } catch (PackageManager.NameNotFoundException unused) {
        }
        try {
            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL("http://www.multideco.com/script/updates_multiand/ic=" + identity.getInstallcode() + "&ver=" + CurVer + "&r=" + this.f89r).openConnection();
            httpURLConnection.setInstanceFollowRedirects(true);
            httpURLConnection.setUseCaches(false);
            httpURLConnection.setRequestProperty("User-Agent", "Android, MultiDeco by HHS Software");
            httpURLConnection.setRequestProperty("Connection", "close");
            httpURLConnection.setConnectTimeout(5000);
            httpURLConnection.setReadTimeout(5000);
            httpURLConnection.connect();
            int responseCode = httpURLConnection.getResponseCode();
            if (responseCode == 200 && (read = httpURLConnection.getInputStream().read(bArr, 0, 30)) > -1) {
                bArr[read] = 0;
            }
            httpURLConnection.disconnect();
            if (responseCode == 200 && (b = bArr[0]) >= 48 && b <= 57) {
                String trim = new String(bArr).trim();
                if (bArr[0] == 50) {
                    CurVer = trim.substring(1);
                }
                int i = bArr[0] - 48;
                VerState = i;
                return i;
            }
        } catch (MalformedURLException | IOException unused2) {
        }
        return 0;
    }
}
