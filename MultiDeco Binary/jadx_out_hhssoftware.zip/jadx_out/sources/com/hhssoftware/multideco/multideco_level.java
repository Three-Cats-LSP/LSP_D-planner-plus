package com.hhssoftware.multideco;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TableLayout;
import android.widget.TextView;

/* loaded from: classes.dex */
public class multideco_level extends Activity implements View.OnClickListener {
    private boolean isCCR = false;
    private boolean isMetric = false;
    private int editRow = -1;
    private final String PREFS_SELECTS = "levelselects";

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        String str;
        setTheme(new Theme_setting(this).theme_id);
        super.onCreate(bundle);
        setContentView(C0347R.layout.multideco_level);
        if (Build.VERSION.SDK_INT < 35) {
            findViewById(C0347R.id.multideco_level_xml).setPadding(0, 0, 0, 0);
        }
        Bundle extras = getIntent().getExtras();
        SharedPreferences sharedPreferences = getSharedPreferences("levelselects", 0);
        if (extras.getInt("Circuit") == 1) {
            this.isCCR = true;
            TableLayout tableLayout = (TableLayout) findViewById(C0347R.id.TableLayoutSPOCSCR);
            if (tableLayout != null) {
                tableLayout.setVisibility(0);
            } else {
                findViewById(C0347R.id.TableRowSP).setVisibility(0);
                findViewById(C0347R.id.TableRowOCSCR).setVisibility(0);
            }
        }
        Spinner spinner = (Spinner) findViewById(C0347R.id.SpinnerDepth);
        int i = android.R.layout.simple_spinner_item;
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_level.1
            @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
            public View getDropDownView(int i2, View view, ViewGroup viewGroup) {
                View dropDownView = super.getDropDownView(i2, view, viewGroup);
                ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                return dropDownView;
            }
        };
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        boolean z = extras.getBoolean("Metric");
        this.isMetric = z;
        if (!z) {
            str = " ft";
        } else {
            str = " m";
        }
        if (z) {
            for (int i2 = 1; i2 <= 300; i2++) {
                arrayAdapter.add("" + i2 + str);
            }
        } else {
            for (int i3 = 5; i3 <= 1000; i3 += 5) {
                arrayAdapter.add("" + i3 + str);
            }
        }
        spinner.setAdapter((SpinnerAdapter) arrayAdapter);
        int i4 = sharedPreferences.getInt("DepthSelect", 0);
        if (i4 > 0 && i4 < spinner.getCount()) {
            spinner.setSelection(i4);
        } else if (this.isMetric) {
            spinner.setSelection(49);
        } else {
            spinner.setSelection(29);
        }
        Spinner spinner2 = (Spinner) findViewById(C0347R.id.SpinnerTime);
        ArrayAdapter<String> arrayAdapter2 = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_level.2
            @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
            public View getDropDownView(int i5, View view, ViewGroup viewGroup) {
                View dropDownView = super.getDropDownView(i5, view, viewGroup);
                ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                return dropDownView;
            }
        };
        arrayAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        for (int i5 = 0; i5 <= 300; i5++) {
            arrayAdapter2.add("" + i5 + " min");
        }
        spinner2.setAdapter((SpinnerAdapter) arrayAdapter2);
        if (sharedPreferences.getInt("TimeSelect", 0) > 0) {
            spinner2.setSelection(sharedPreferences.getInt("TimeSelect", 0));
        } else {
            spinner2.setSelection(30);
        }
        Spinner spinner3 = (Spinner) findViewById(C0347R.id.SpinnerO2);
        ArrayAdapter<String> arrayAdapter3 = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_level.3
            @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
            public View getDropDownView(int i6, View view, ViewGroup viewGroup) {
                View dropDownView = super.getDropDownView(i6, view, viewGroup);
                ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                return dropDownView;
            }
        };
        arrayAdapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        for (int i6 = 1; i6 <= 100; i6++) {
            arrayAdapter3.add("" + i6 + " %");
        }
        spinner3.setAdapter((SpinnerAdapter) arrayAdapter3);
        if (sharedPreferences.getInt("O2Select", 0) > 0) {
            spinner3.setSelection(sharedPreferences.getInt("O2Select", 21));
        } else if (this.isCCR) {
            spinner3.setSelection(9);
        } else {
            spinner3.setSelection(20);
        }
        Spinner spinner4 = (Spinner) findViewById(C0347R.id.SpinnerHe);
        ArrayAdapter<String> arrayAdapter4 = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_level.4
            @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
            public View getDropDownView(int i7, View view, ViewGroup viewGroup) {
                View dropDownView = super.getDropDownView(i7, view, viewGroup);
                ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                return dropDownView;
            }
        };
        arrayAdapter4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        for (int i7 = 0; i7 <= 99; i7++) {
            arrayAdapter4.add("" + i7 + " %");
        }
        spinner4.setAdapter((SpinnerAdapter) arrayAdapter4);
        if (sharedPreferences.getInt("HeSelect", 0) > 0) {
            spinner4.setSelection(sharedPreferences.getInt("HeSelect", 0));
        } else if (this.isCCR) {
            spinner4.setSelection(50);
        } else {
            spinner4.setSelection(0);
        }
        if (this.isCCR) {
            Spinner spinner5 = (Spinner) findViewById(C0347R.id.SpinnerSP);
            ArrayAdapter<String> arrayAdapter5 = new ArrayAdapter<String>(this, i) { // from class: com.hhssoftware.multideco.multideco_level.5
                @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
                public View getDropDownView(int i8, View view, ViewGroup viewGroup) {
                    View dropDownView = super.getDropDownView(i8, view, viewGroup);
                    ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                    return dropDownView;
                }
            };
            arrayAdapter5.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            for (int i8 = 25; i8 <= 200; i8 += 5) {
                arrayAdapter5.add(String.format("%.2f", Double.valueOf(i8 * 0.01d)));
            }
            spinner5.setAdapter((SpinnerAdapter) arrayAdapter5);
            if (sharedPreferences.getInt("SPSelect", 0) > 0) {
                spinner5.setSelection(sharedPreferences.getInt("SPSelect", 20));
            } else {
                spinner5.setSelection(20);
            }
        }
        if (extras.get("Row") != null) {
            this.editRow = extras.getInt("Row");
        }
        if (this.editRow > -1 && extras.get("Edit") != null) {
            String string = extras.getString("Edit");
            ((Spinner) findViewById(C0347R.id.SpinnerO2)).setSelection(Settings.LegIntSeg(string, 4) - 1);
            ((Spinner) findViewById(C0347R.id.SpinnerHe)).setSelection(Settings.LegIntSeg(string, 5));
            int LegIntSeg = Settings.LegIntSeg(string, 1) - 1;
            if (!this.isMetric) {
                LegIntSeg /= 5;
            }
            ((Spinner) findViewById(C0347R.id.SpinnerDepth)).setSelection(LegIntSeg);
            ((Spinner) findViewById(C0347R.id.SpinnerTime)).setSelection(Settings.LegIntSeg(string, 2));
            if (this.isCCR) {
                double LegFloatSeg = Settings.LegFloatSeg(string, 8);
                if (LegFloatSeg > 0.0d) {
                    ((Spinner) findViewById(C0347R.id.SpinnerSP)).setSelection((int) ((LegFloatSeg - 0.25d) * 20.0d));
                }
                if (Settings.LegStrSeg(string, 6).length() == 2) {
                    ((CompoundButton) findViewById(C0347R.id.CheckBoxOC)).setChecked(true);
                }
                if (Settings.LegStrSeg(string, 7).length() == 3) {
                    ((CompoundButton) findViewById(C0347R.id.CheckBoxSCR)).setChecked(true);
                }
            }
        }
        findViewById(C0347R.id.ButtonSave).setOnClickListener(this);
        findViewById(C0347R.id.ButtonCancel).setOnClickListener(this);
        findViewById(C0347R.id.CheckBoxOC).setOnClickListener(this);
        findViewById(C0347R.id.CheckBoxSCR).setOnClickListener(this);
    }

    @Override // android.app.Activity
    protected void onStop() {
        super.onStop();
        SharedPreferences.Editor edit = getSharedPreferences("levelselects", 0).edit();
        edit.putInt("DepthSelect", ((Spinner) findViewById(C0347R.id.SpinnerDepth)).getSelectedItemPosition());
        edit.putInt("TimeSelect", ((Spinner) findViewById(C0347R.id.SpinnerTime)).getSelectedItemPosition());
        edit.putInt("O2Select", ((Spinner) findViewById(C0347R.id.SpinnerO2)).getSelectedItemPosition());
        edit.putInt("HeSelect", ((Spinner) findViewById(C0347R.id.SpinnerHe)).getSelectedItemPosition());
        if (this.isCCR) {
            edit.putInt("SPSelect", ((Spinner) findViewById(C0347R.id.SpinnerSP)).getSelectedItemPosition());
        }
        edit.commit();
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        int id = view.getId();
        if (id == C0347R.id.ButtonSave) {
            Intent intent = getIntent();
            String Buildlevel = Buildlevel();
            if (Buildlevel == null) {
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle(getString(C0347R.string.Error));
                builder.setIcon(android.R.drawable.ic_dialog_alert);
                builder.setMessage(getString(C0347R.string.ErrLegSelection));
                builder.setNeutralButton(android.R.string.ok, new DialogInterface.OnClickListener() { // from class: com.hhssoftware.multideco.multideco_level.6
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                });
                builder.create().show();
                return;
            }
            intent.putExtra("level", Buildlevel);
            int i = this.editRow;
            if (i > -1) {
                intent.putExtra("row", i);
            }
            setResult(-1, intent);
            finish();
            return;
        }
        if (id == C0347R.id.ButtonCancel) {
            setResult(0);
            finish();
        } else if (id == C0347R.id.CheckBoxOC) {
            ((CheckBox) findViewById(C0347R.id.CheckBoxSCR)).setChecked(false);
        } else if (id == C0347R.id.CheckBoxSCR) {
            ((CheckBox) findViewById(C0347R.id.CheckBoxOC)).setChecked(false);
        }
    }

    private String Buildlevel() {
        String str;
        int selectedItemPosition = ((Spinner) findViewById(C0347R.id.SpinnerDepth)).getSelectedItemPosition() + 1;
        if (!this.isMetric) {
            selectedItemPosition *= 5;
        }
        int selectedItemPosition2 = ((Spinner) findViewById(C0347R.id.SpinnerTime)).getSelectedItemPosition();
        int selectedItemPosition3 = ((Spinner) findViewById(C0347R.id.SpinnerO2)).getSelectedItemPosition() + 1;
        int selectedItemPosition4 = ((Spinner) findViewById(C0347R.id.SpinnerHe)).getSelectedItemPosition();
        if (selectedItemPosition3 + selectedItemPosition4 > 100) {
            return null;
        }
        String str2 = "" + selectedItemPosition;
        if (selectedItemPosition2 != 0) {
            str = str2 + ", " + selectedItemPosition2;
        } else {
            str = str2 + ", -";
        }
        String str3 = str + ", " + selectedItemPosition3;
        if (selectedItemPosition4 > 0) {
            str3 = str3 + "/" + selectedItemPosition4;
        }
        if (!this.isCCR) {
            return str3;
        }
        int selectedItemPosition5 = (((Spinner) findViewById(C0347R.id.SpinnerSP)).getSelectedItemPosition() * 5) + 25;
        CheckBox checkBox = (CheckBox) findViewById(C0347R.id.CheckBoxOC);
        CheckBox checkBox2 = (CheckBox) findViewById(C0347R.id.CheckBoxSCR);
        if (checkBox.isChecked()) {
            return str3 + ", OC";
        }
        if (checkBox2.isChecked()) {
            return str3 + ", SCR";
        }
        return str3 + String.format(", %.2f", Double.valueOf(selectedItemPosition5 * 0.01d));
    }
}
