package com.hhssoftware.multideco;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Looper;
import android.os.MessageQueue;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import androidx.core.view.ViewCompat;

/* loaded from: classes.dex */
public class mixer_capacity extends Activity implements MessageQueue.IdleHandler, View.OnClickListener {
    private Boolean isIniting;
    private Settings settings;
    private final String PREFS_MIXER = "mixer_capacity";
    private TextWatcher textWatcher = new TextWatcher() { // from class: com.hhssoftware.multideco.mixer_capacity.1
        @Override // android.text.TextWatcher
        public void afterTextChanged(Editable editable) {
        }

        @Override // android.text.TextWatcher
        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        @Override // android.text.TextWatcher
        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            if (mixer_capacity.this.isIniting.booleanValue()) {
                return;
            }
            mixer_capacity.this.performCalc();
        }
    };

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        setTheme(new Theme_setting(this).theme_id);
        super.onCreate(bundle);
        setContentView(C0347R.layout.mixer_capacity);
        this.settings = new Settings(this);
        this.isIniting = false;
        ((EditText) findViewById(C0347R.id.capacitysupplystartpress)).addTextChangedListener(this.textWatcher);
        ((EditText) findViewById(C0347R.id.capacitysupplysize)).addTextChangedListener(this.textWatcher);
        ((EditText) findViewById(C0347R.id.capacityreceivesize)).addTextChangedListener(this.textWatcher);
        ((EditText) findViewById(C0347R.id.capacityreceivestartpress)).addTextChangedListener(this.textWatcher);
        ((EditText) findViewById(C0347R.id.capacityreceiveaddpress)).addTextChangedListener(this.textWatcher);
        findViewById(C0347R.id.Capacityrepeat).setOnClickListener(this);
        findViewById(C0347R.id.Capacityequalize).setOnClickListener(this);
        SharedPreferences sharedPreferences = getSharedPreferences("mixer_capacity", 0);
        loadPrefs(sharedPreferences);
        try {
            performCalc();
        } catch (Exception unused) {
            SharedPreferences.Editor edit = sharedPreferences.edit();
            edit.clear();
            edit.commit();
            loadPrefs(sharedPreferences);
        }
        Looper.myQueue().addIdleHandler(this);
    }

    private void loadPrefs(SharedPreferences sharedPreferences) {
        ((EditText) findViewById(C0347R.id.capacitysupplystartpress)).setText(sharedPreferences.getString("capacitysupplystartpress", ""));
        ((EditText) findViewById(C0347R.id.capacitysupplysize)).setText(sharedPreferences.getString("capacitysupplysize", ""));
        ((EditText) findViewById(C0347R.id.capacityreceivesize)).setText(sharedPreferences.getString("capacityreceivesize", ""));
        ((EditText) findViewById(C0347R.id.capacityreceivestartpress)).setText(sharedPreferences.getString("capacityreceivestartpress", ""));
        ((EditText) findViewById(C0347R.id.capacityreceiveaddpress)).setText(sharedPreferences.getString("capacityreceiveaddpress", ""));
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        SharedPreferences.Editor edit = getSharedPreferences("mixer_capacity", 0).edit();
        edit.putString("capacitysupplystartpress", ((EditText) findViewById(C0347R.id.capacitysupplystartpress)).getText().toString());
        edit.putString("capacitysupplysize", ((EditText) findViewById(C0347R.id.capacitysupplysize)).getText().toString());
        edit.putString("capacityreceivesize", ((EditText) findViewById(C0347R.id.capacityreceivesize)).getText().toString());
        edit.putString("capacityreceivestartpress", ((EditText) findViewById(C0347R.id.capacityreceivestartpress)).getText().toString());
        edit.putString("capacityreceiveaddpress", ((EditText) findViewById(C0347R.id.capacityreceiveaddpress)).getText().toString());
        edit.commit();
        super.onDestroy();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void performCalc() {
        String[] strArr = new String[9];
        ((EditText) findViewById(C0347R.id.capacityreceiveresult)).setText("");
        ((EditText) findViewById(C0347R.id.capacitysupplyresult)).setText("");
        findViewById(C0347R.id.TextcapacityResult).setBackgroundColor(0);
        if (((EditText) findViewById(C0347R.id.capacitysupplystartpress)).getText().length() == 0 || ((EditText) findViewById(C0347R.id.capacitysupplysize)).getText().length() == 0 || ((EditText) findViewById(C0347R.id.capacityreceivesize)).getText().length() == 0 || ((EditText) findViewById(C0347R.id.capacityreceivestartpress)).getText().length() == 0 || ((EditText) findViewById(C0347R.id.capacityreceiveaddpress)).getText().length() == 0 || ((EditText) findViewById(C0347R.id.capacitysupplystartpress)).getText().charAt(0) == '-') {
            return;
        }
        strArr[0] = "9999";
        strArr[1] = ((EditText) findViewById(C0347R.id.capacitysupplystartpress)).getText().toString();
        strArr[2] = "";
        strArr[3] = ((EditText) findViewById(C0347R.id.capacityreceiveaddpress)).getText().toString();
        strArr[4] = ((EditText) findViewById(C0347R.id.capacityreceivestartpress)).getText().toString();
        strArr[5] = "";
        strArr[6] = ((EditText) findViewById(C0347R.id.capacityreceivesize)).getText().toString();
        strArr[7] = ((EditText) findViewById(C0347R.id.capacitysupplysize)).getText().toString();
        strArr[8] = Boolean.toString(false);
        String[] performCalc = new tools_calc().performCalc(strArr);
        ((EditText) findViewById(C0347R.id.capacityreceiveresult)).setText(performCalc[5]);
        ((EditText) findViewById(C0347R.id.capacitysupplyresult)).setText(performCalc[2]);
        if (Boolean.parseBoolean(performCalc[8])) {
            findViewById(C0347R.id.TextcapacityResult).setBackgroundColor(this.settings.warn_colors[6] | ViewCompat.MEASURED_STATE_MASK);
        } else {
            findViewById(C0347R.id.TextcapacityResult).setBackgroundColor(0);
        }
        Looper.myQueue().addIdleHandler(this);
    }

    @Override // android.os.MessageQueue.IdleHandler
    public boolean queueIdle() {
        this.isIniting = false;
        return false;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        int id = view.getId();
        if (id == C0347R.id.Capacityrepeat) {
            String obj = ((EditText) findViewById(C0347R.id.capacitysupplyresult)).getText().toString();
            if (obj.length() == 0 || obj.charAt(0) == '-') {
                return;
            }
            ((EditText) findViewById(C0347R.id.capacitysupplystartpress)).setText(obj);
            performCalc();
        }
        if (id == C0347R.id.Capacityequalize) {
            ((EditText) findViewById(C0347R.id.capacityreceiveaddpress)).setText("");
            findViewById(C0347R.id.TextcapacityResult).setBackgroundColor(0);
            if (((EditText) findViewById(C0347R.id.capacitysupplystartpress)).getText().length() == 0 || ((EditText) findViewById(C0347R.id.capacitysupplysize)).getText().length() == 0 || ((EditText) findViewById(C0347R.id.capacityreceivesize)).getText().length() == 0 || ((EditText) findViewById(C0347R.id.capacityreceivestartpress)).getText().length() == 0 || ((EditText) findViewById(C0347R.id.capacitysupplystartpress)).getText().charAt(0) == '-') {
                return;
            }
            double parseDouble = Double.parseDouble(((EditText) findViewById(C0347R.id.capacitysupplysize)).getText().toString());
            double parseDouble2 = Double.parseDouble(((EditText) findViewById(C0347R.id.capacityreceivesize)).getText().toString());
            double parseDouble3 = ((Double.parseDouble(((EditText) findViewById(C0347R.id.capacitysupplystartpress)).getText().toString()) * parseDouble) + (Double.parseDouble(((EditText) findViewById(C0347R.id.capacityreceivestartpress)).getText().toString()) * parseDouble2)) / (parseDouble + parseDouble2);
            if (this.settings.mix_units == 0) {
                ((EditText) findViewById(C0347R.id.capacitysupplyresult)).setText(String.format("%.1f", Double.valueOf(parseDouble3)));
                ((EditText) findViewById(C0347R.id.capacityreceiveresult)).setText(String.format("%.1f", Double.valueOf(parseDouble3)));
            } else {
                ((EditText) findViewById(C0347R.id.capacitysupplyresult)).setText(String.format("%.0f", Double.valueOf(parseDouble3)));
                ((EditText) findViewById(C0347R.id.capacityreceiveresult)).setText(String.format("%.0f", Double.valueOf(parseDouble3)));
            }
        }
    }
}
