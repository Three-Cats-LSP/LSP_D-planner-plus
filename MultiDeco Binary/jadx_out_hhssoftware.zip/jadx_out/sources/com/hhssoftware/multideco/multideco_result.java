package com.hhssoftware.multideco;

import android.app.Activity;
import android.app.Dialog;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import java.text.DecimalFormatSymbols;
import java.util.Locale;
import java.util.Random;

/* loaded from: classes.dex */
public class multideco_result extends Activity implements View.OnClickListener {
    private Bundle extras;
    private Menu mOptionsMenu;
    private String[] plan_item;

    /* renamed from: w */
    private int f90w;
    private final int ROW_BASE = 2340000;
    private final int TXT_BASE = 2341000;
    private final int WARN_BASE = 2342000;
    private final float[] header_w_all = {0.07f, 0.2f, 0.15f, 0.14f, 0.15f, 0.15f, 0.14f};
    private final float[] header_w_pl = {0.05f, 0.18f, 0.15f, 0.18f, 0.15f, 0.15f, 0.14f};
    private final float[] item_w = {0.12f, 0.15f, 0.15f, 0.14f, 0.17f, 0.15f, 0.12f};
    private final int DLG_REPORT = 235612;
    private final int DLG_SURFINT = 454542;
    private final int MENU_DIVE_NEXT = 452392;
    private final int MENU_DIVE_EMAIL = 446217;
    private final int MENU_DIVE_CP = 436849;
    private final int MENU_WEB_FAQ = 446221;
    private final String PREFS_SI = "surf_int";
    private Dialog dialog = null;

    public int contrastColor(int i) {
        int i2 = i & 255;
        int i3 = (i >> 8) & 255;
        int i4 = (i >> 16) & 255;
        return ((i3 <= 228 || i2 + i4 != 0) && (i2 + i3) + i4 < 384) ? 15921391 : 3881787;
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        setTheme(new Theme_setting(this).theme_id);
        super.onCreate(bundle);
        setContentView(C0347R.layout.multideco_result);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        this.f90w = displayMetrics.widthPixels;
        this.extras = getIntent().getExtras();
        buildRows();
        insertBanners();
        insertWarnings();
        addButtons();
        findViewById(C0347R.id.buttonResultReport).setOnClickListener(this);
        findViewById(C0347R.id.buttonResultNext).setOnClickListener(this);
        findViewById(C0347R.id.imageBtnResultCopy).setOnClickListener(this);
        findViewById(C0347R.id.imageBtnResultEmail).setOnClickListener(this);
        findViewById(C0347R.id.imageBtnResultWebFAQ).setOnClickListener(this);
        setResult(0);
    }

    private void insertBanners() {
        float[] fArr = new float[7];
        String language = Locale.getDefault().getLanguage();
        if (language.length() == 2 && language.compareToIgnoreCase("pl") == 0) {
            for (int i = 0; i < 7; i++) {
                fArr[i] = this.header_w_pl[i];
            }
        } else {
            for (int i2 = 0; i2 < 7; i2++) {
                fArr[i2] = this.header_w_all[i2];
            }
        }
        LinearLayout linearLayout = (LinearLayout) findViewById(C0347R.id.LinearLayoutBannerTop);
        int i3 = 0;
        while (true) {
            TextView textView = new TextView(this);
            textView.setLayoutParams(new ViewGroup.LayoutParams(Math.round(fArr[0] * this.f90w), -2));
            textView.setTextSize(2, 18.0f);
            textView.setTypeface(null, 1);
            linearLayout.addView(textView);
            TextView textView2 = new TextView(this);
            textView2.setLayoutParams(new ViewGroup.LayoutParams(Math.round(fArr[1] * this.f90w), -2));
            textView2.setText(getString(C0347R.string.Depth_result));
            textView2.setTextSize(2, 18.0f);
            textView2.setTypeface(null, 1);
            textView2.setGravity(17);
            textView2.setTextColor(getResources().getColor(android.R.color.secondary_text_dark));
            linearLayout.addView(textView2);
            TextView textView3 = new TextView(this);
            textView3.setLayoutParams(new ViewGroup.LayoutParams(Math.round(fArr[2] * this.f90w), -2));
            textView3.setText(getString(C0347R.string.Stop_result));
            textView3.setTextSize(2, 18.0f);
            textView3.setTypeface(null, 1);
            textView3.setGravity(17);
            textView3.setTextColor(getResources().getColor(android.R.color.secondary_text_dark));
            linearLayout.addView(textView3);
            TextView textView4 = new TextView(this);
            textView4.setLayoutParams(new ViewGroup.LayoutParams(Math.round(fArr[3] * this.f90w), -2));
            textView4.setText(getString(C0347R.string.Run_result));
            textView4.setTextSize(2, 18.0f);
            textView4.setTypeface(null, 1);
            textView4.setGravity(17);
            textView4.setTextColor(getResources().getColor(android.R.color.secondary_text_dark));
            linearLayout.addView(textView4);
            TextView textView5 = new TextView(this);
            textView5.setLayoutParams(new ViewGroup.LayoutParams(Math.round(fArr[4] * this.f90w), -2));
            textView5.setText(getString(C0347R.string.Mix_result));
            textView5.setTextSize(2, 18.0f);
            textView5.setTypeface(null, 1);
            textView5.setGravity(17);
            textView5.setTextColor(getResources().getColor(android.R.color.secondary_text_dark));
            linearLayout.addView(textView5);
            TextView textView6 = new TextView(this);
            textView6.setLayoutParams(new ViewGroup.LayoutParams(Math.round(fArr[5] * this.f90w), -2));
            textView6.setText(getString(C0347R.string.pO2));
            textView6.setTextSize(2, 18.0f);
            textView6.setTypeface(null, 1);
            textView6.setGravity(17);
            textView6.setTextColor(getResources().getColor(android.R.color.secondary_text_dark));
            linearLayout.addView(textView6);
            TextView textView7 = new TextView(this);
            textView7.setLayoutParams(new ViewGroup.LayoutParams(Math.round(fArr[6] * this.f90w), -2));
            textView7.setText(getString(C0347R.string.EAD));
            textView7.setTextSize(2, 18.0f);
            textView7.setTypeface(null, 1);
            textView7.setGravity(17);
            textView7.setTextColor(getResources().getColor(android.R.color.secondary_text_dark));
            linearLayout.addView(textView7);
            i3++;
            if (i3 == 2) {
                return;
            }
            linearLayout = new LinearLayout(this);
            linearLayout.setOrientation(0);
            linearLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
            linearLayout.setBackgroundColor(getResources().getColor(C0347R.color.lightgray));
            ((LinearLayout) findViewById(C0347R.id.ResultLayout)).addView(linearLayout);
        }
    }

    private void buildRows() {
        LinearLayout linearLayout = (LinearLayout) findViewById(C0347R.id.ResultLayout);
        int i = this.extras.getInt("result_rows", 0);
        boolean containsKey = this.extras.containsKey("alert_rows_color");
        int[] iArr = new int[0];
        if (containsKey) {
            iArr = this.extras.getIntArray("alert_rows_color");
        }
        int i2 = 0;
        for (int i3 = 0; i3 < i; i3++) {
            this.plan_item = this.extras.getStringArray("result_row_" + i3);
            if (containsKey) {
                i2 = iArr[i3];
            }
            linearLayout.addView(buildrow(i3, i2));
            linearLayout.addView(buildDivider());
        }
    }

    private void insertWarnings() {
        if (this.extras.containsKey("alert_rows_warn")) {
            LinearLayout linearLayout = (LinearLayout) findViewById(C0347R.id.ResultLayout);
            int i = this.extras.getInt("result_rows", 0);
            int[] intArray = this.extras.getIntArray("alert_rows_warn");
            int[] intArray2 = this.extras.getIntArray("alert_rows_color");
            for (int i2 = 0; i2 < i; i2++) {
                if (intArray[i2] > 0) {
                    int i3 = 0;
                    while (true) {
                        if (i3 < i2) {
                            if (intArray[i3] == intArray[i2]) {
                                break;
                            } else {
                                i3++;
                            }
                        } else {
                            linearLayout.addView(buildwarn(intArray[i2], intArray2[i2]));
                            linearLayout.addView(buildDivider());
                            break;
                        }
                    }
                }
            }
        }
    }

    private void addButtons() {
        LinearLayout linearLayout = (LinearLayout) findViewById(C0347R.id.ResultLayout);
        LinearLayout linearLayout2 = (LinearLayout) findViewById(C0347R.id.ResultButtons);
        linearLayout.removeView(linearLayout2);
        linearLayout.addView(linearLayout2);
    }

    @Override // android.app.Activity
    public boolean onCreateOptionsMenu(Menu menu) {
        this.mOptionsMenu = menu;
        menu.add(0, 452392, 0, C0347R.string.NextDive).setIcon(android.R.drawable.ic_menu_add);
        menu.add(0, 446217, 0, C0347R.string.Emailplan).setIcon(android.R.drawable.ic_menu_send);
        menu.add(0, C0347R.id.multideco_report_xml, 0, C0347R.string.Report).setIcon(android.R.drawable.ic_menu_info_details);
        menu.add(0, 436849, 0, C0347R.string.CopyClip).setIcon(android.R.drawable.ic_menu_upload);
        menu.add(0, 446221, 0, "Web FAQ").setIcon(android.R.drawable.ic_menu_help);
        return true;
    }

    @Override // android.app.Activity
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == C0347R.id.multideco_report_xml) {
            showDialog(235612);
            return true;
        }
        if (itemId == 452392) {
            showDialog(454542);
            return true;
        }
        if (itemId == 446217) {
            Intent intent = new Intent("android.intent.action.SEND");
            intent.putExtra("android.intent.extra.TEXT", getPlanString() + "\n\n" + getReportString());
            intent.putExtra("android.intent.extra.SUBJECT", getString(C0347R.string.VPlannerdiveplan));
            intent.setType("message/rfc822");
            startActivity(Intent.createChooser(intent, getString(C0347R.string.SelectEmail)));
            return true;
        }
        if (itemId == 436849) {
            ((ClipboardManager) getSystemService("clipboard")).setText(getPlanString() + "\n\n" + getReportString());
            return true;
        }
        if (itemId != 446221) {
            return false;
        }
        Intent intent2 = new Intent();
        intent2.setAction("android.intent.action.VIEW");
        intent2.addCategory("android.intent.category.BROWSABLE");
        intent2.setData(Uri.parse(getString(C0347R.string.mobile_faq)));
        startActivity(intent2);
        return true;
    }

    @Override // android.app.Activity
    protected Dialog onCreateDialog(int i) {
        if (i == 235612) {
            Dialog dialog = new Dialog(this);
            this.dialog = dialog;
            dialog.setContentView(C0347R.layout.multideco_report);
            this.dialog.setTitle(getString(C0347R.string.Report));
            fillReportDialog(this.dialog);
        } else if (i == 454542) {
            Dialog dialog2 = new Dialog(this);
            this.dialog = dialog2;
            dialog2.setContentView(C0347R.layout.multideco_surfint);
            this.dialog.setTitle(getString(C0347R.string.SurfaceInterval));
            initSurfInt(this.dialog);
        }
        return this.dialog;
    }

    private void initSurfInt(Dialog dialog) {
        SharedPreferences sharedPreferences = getSharedPreferences("surf_int", 0);
        int i = 2;
        int max = Math.max(Math.min(sharedPreferences.getInt("days", 2), 14), 0);
        int max2 = Math.max(Math.min(sharedPreferences.getInt("hours", 0), 23), 0);
        int max3 = Math.max(Math.min(sharedPreferences.getInt("mins", 0), 59), 0);
        if (max + max2 + max3 <= 0) {
            max3 = 0;
            max2 = 0;
        } else {
            i = max;
        }
        Spinner spinner = (Spinner) dialog.findViewById(C0347R.id.SurfIntDay);
        int i2 = android.R.layout.simple_spinner_item;
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, i2) { // from class: com.hhssoftware.multideco.multideco_result.1
            @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
            public View getDropDownView(int i3, View view, ViewGroup viewGroup) {
                View dropDownView = super.getDropDownView(i3, view, viewGroup);
                ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                return dropDownView;
            }
        };
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        for (int i3 = 0; i3 <= 14; i3++) {
            arrayAdapter.add("" + i3);
        }
        spinner.setAdapter((SpinnerAdapter) arrayAdapter);
        spinner.setSelection(i);
        Spinner spinner2 = (Spinner) dialog.findViewById(C0347R.id.SurfIntHour);
        ArrayAdapter<String> arrayAdapter2 = new ArrayAdapter<String>(this, i2) { // from class: com.hhssoftware.multideco.multideco_result.2
            @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
            public View getDropDownView(int i4, View view, ViewGroup viewGroup) {
                View dropDownView = super.getDropDownView(i4, view, viewGroup);
                ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                return dropDownView;
            }
        };
        arrayAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        for (int i4 = 0; i4 <= 23; i4++) {
            arrayAdapter2.add("" + i4);
        }
        spinner2.setAdapter((SpinnerAdapter) arrayAdapter2);
        spinner2.setSelection(max2);
        Spinner spinner3 = (Spinner) dialog.findViewById(C0347R.id.SurfIntMin);
        ArrayAdapter<String> arrayAdapter3 = new ArrayAdapter<String>(this, i2) { // from class: com.hhssoftware.multideco.multideco_result.3
            @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
            public View getDropDownView(int i5, View view, ViewGroup viewGroup) {
                View dropDownView = super.getDropDownView(i5, view, viewGroup);
                ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                return dropDownView;
            }
        };
        arrayAdapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        for (int i5 = 0; i5 <= 59; i5++) {
            arrayAdapter3.add("" + i5);
        }
        spinner3.setAdapter((SpinnerAdapter) arrayAdapter3);
        spinner3.setSelection(max3);
        dialog.findViewById(C0347R.id.SurfIntButtonCancel).setOnClickListener(this);
        dialog.findViewById(C0347R.id.SurfIntButtonSave).setOnClickListener(this);
    }

    private void fillReportDialog(Dialog dialog) {
        TextView textView = (TextView) dialog.findViewById(C0347R.id.TextViewReport);
        textView.setTextSize(2, 20.0f);
        textView.setText(getReportString());
    }

    private View buildDivider() {
        View view = new View(this);
        view.setLayoutParams(new LinearLayout.LayoutParams(-1, 1));
        view.setBackgroundColor(getResources().getColor(C0347R.color.darkgray));
        return view;
    }

    private LinearLayout buildrow(int i, int i2) {
        int i3;
        Random random = new Random();
        DecimalFormatSymbols decimalFormatSymbols = new DecimalFormatSymbols();
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        linearLayout.setOrientation(0);
        linearLayout.setId(2340000 + i);
        linearLayout.setPadding(0, 4, 0, 4);
        if (i2 != 0) {
            linearLayout.setBackgroundColor((-1358954496) | i2);
            i3 = (-16777216) | contrastColor(i2);
        } else {
            i3 = 0;
        }
        ImageView imageView = new ImageView(this);
        imageView.setLayoutParams(new ViewGroup.LayoutParams(Math.round(this.item_w[0] * this.f90w), -2));
        char charAt = this.plan_item[0].charAt(1);
        if (charAt == 'e') {
            imageView.setImageResource(C0347R.drawable.descend);
        } else if (charAt == 'f') {
            imageView.setImageResource(C0347R.drawable.surface);
        } else if (charAt == 's') {
            imageView.setImageResource(C0347R.drawable.ascend);
        } else if (charAt == 't') {
            imageView.setImageResource(C0347R.drawable.stop);
        } else if (charAt == 'v') {
            imageView.setImageResource(C0347R.drawable.level);
        }
        imageView.setPadding(0, 2, 0, 0);
        linearLayout.addView(imageView);
        TextView textView = new TextView(this);
        textView.setLayoutParams(new ViewGroup.LayoutParams(Math.round(this.item_w[1] * this.f90w), -2));
        textView.setText(this.plan_item[1]);
        textView.setTextSize(2, 20.0f);
        textView.setId(2341001 + i);
        textView.setGravity(17);
        if (i2 > 0) {
            textView.setTextColor(i3);
        }
        linearLayout.addView(textView);
        TextView textView2 = new TextView(this);
        textView2.setLayoutParams(new ViewGroup.LayoutParams(Math.round(this.item_w[2] * this.f90w), -2));
        if (VersionCheck.VerState == 9 && i > 2) {
            textView2.setText((Math.abs(random.nextInt() % 16) + 1) + "");
        } else {
            textView2.setText(this.plan_item[2]);
        }
        textView2.setTextSize(2, 20.0f);
        textView2.setId(2341002 + i);
        textView2.setGravity(17);
        if (i2 > 0) {
            textView2.setTextColor(i3);
        }
        linearLayout.addView(textView2);
        TextView textView3 = new TextView(this);
        textView3.setLayoutParams(new ViewGroup.LayoutParams(Math.round(this.item_w[3] * this.f90w), -2));
        if (VersionCheck.VerState == 9 && i > 2) {
            textView3.setText(Math.abs(random.nextInt() % 56) + "");
        } else {
            textView3.setText(this.plan_item[3]);
        }
        textView3.setTextSize(2, 20.0f);
        textView3.setId(2341003 + i);
        textView3.setGravity(17);
        if (i2 > 0) {
            textView3.setTextColor(i3);
        }
        linearLayout.addView(textView3);
        TextView textView4 = new TextView(this);
        textView4.setLayoutParams(new ViewGroup.LayoutParams(Math.round(this.item_w[4] * this.f90w), -2));
        textView4.setText(this.plan_item[4]);
        if (this.plan_item[4].length() > 3) {
            textView4.setTextSize(2, 16.0f);
        } else {
            textView4.setTextSize(2, 18.0f);
        }
        textView4.setId(2341004 + i);
        textView4.setGravity(17);
        if (i2 > 0) {
            textView4.setTextColor(i3);
        }
        linearLayout.addView(textView4);
        TextView textView5 = new TextView(this);
        textView5.setLayoutParams(new ViewGroup.LayoutParams(Math.round(this.item_w[5] * this.f90w), -2));
        String str = this.plan_item[5];
        if (decimalFormatSymbols.getDecimalSeparator() == ',') {
            str = str.replace('.', ',');
        }
        textView5.setText(str);
        textView5.setTextSize(2, 18.0f);
        textView5.setId(2341005 + i);
        textView5.setGravity(17);
        if (i2 > 0) {
            textView5.setTextColor(i3);
        }
        linearLayout.addView(textView5);
        TextView textView6 = new TextView(this);
        textView6.setLayoutParams(new ViewGroup.LayoutParams(Math.round(this.item_w[6] * this.f90w), -2));
        textView6.setText(this.plan_item[6]);
        textView6.setTextSize(2, 18.0f);
        textView6.setId(2341006 + i);
        textView6.setGravity(17);
        if (i2 > 0) {
            textView6.setTextColor(i3);
        }
        linearLayout.addView(textView6);
        return linearLayout;
    }

    private View buildwarn(int i, int i2) {
        Settings settings = new Settings(this);
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        linearLayout.setOrientation(0);
        linearLayout.setId(2342000 + i);
        linearLayout.setPadding(8, 4, 8, 4);
        if (i2 != 0) {
            linearLayout.setBackgroundColor((-1358954496) | i2);
        }
        TextView textView = new TextView(this);
        textView.setLayoutParams(new ViewGroup.LayoutParams(-1, -2));
        textView.setText(settings.warn_str(i));
        textView.setTextSize(2, 20.0f);
        textView.setTextColor((-16777216) | contrastColor(i2));
        linearLayout.addView(textView);
        return linearLayout;
    }

    private String getPlanString() {
        String str = "\t" + getString(C0347R.string.Depth) + "\t" + getString(C0347R.string.Stop) + "\t" + getString(C0347R.string.Run) + "\t" + getString(C0347R.string.Mix) + "\t" + getString(C0347R.string.pO2) + "\t" + getString(C0347R.string.EAD) + "\n";
        int i = this.extras.getInt("result_rows", 0);
        for (int i2 = 0; i2 < i; i2++) {
            this.plan_item = this.extras.getStringArray("result_row_" + i2);
            for (int i3 = 0; i3 < 7; i3++) {
                str = str + this.plan_item[i3] + "\t";
            }
            str = str + "\n";
        }
        return str;
    }

    private String getReportString() {
        String str = "";
        for (String str2 : this.extras.getStringArray("dive_report")) {
            if (str2.indexOf("Gas") > -1) {
                str2 = getString(C0347R.string.Gas) + str2.substring(3);
            } else if (str2.indexOf("Dive") > -1) {
                str2 = getString(C0347R.string.Dive) + str2.substring(5);
            } else if (str2.indexOf("Elevation") > -1) {
                str2 = getString(C0347R.string.Elevation) + str2.substring(9);
            } else if (str2.indexOf("Surface time") > -1) {
                str2 = getString(C0347R.string.SurfaceInterval) + str2.substring(12);
            } else if (str2.indexOf("Gas density") > -1) {
                str2 = getString(C0347R.string.toolListItems_Density) + str2.substring(11);
            } else if (str2.indexOf("Decozone start") > -1) {
                str2 = getString(C0347R.string.Decozonestart) + str2.substring(14);
            }
            str = str + str2 + "\n";
        }
        return str;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        int id = view.getId();
        if (id == C0347R.id.SurfIntButtonSave) {
            SharedPreferences.Editor edit = getSharedPreferences("surf_int", 0).edit();
            Intent intent = new Intent();
            Spinner spinner = (Spinner) this.dialog.findViewById(C0347R.id.SurfIntDay);
            intent.putExtra("SI_Day", spinner.getSelectedItemPosition());
            edit.putInt("days", spinner.getSelectedItemPosition());
            Spinner spinner2 = (Spinner) this.dialog.findViewById(C0347R.id.SurfIntHour);
            intent.putExtra("SI_Hour", spinner2.getSelectedItemPosition());
            edit.putInt("hours", spinner2.getSelectedItemPosition());
            Spinner spinner3 = (Spinner) this.dialog.findViewById(C0347R.id.SurfIntMin);
            intent.putExtra("SI_Min", spinner3.getSelectedItemPosition());
            edit.putInt("mins", spinner3.getSelectedItemPosition());
            edit.commit();
            setResult(-1, intent);
            this.dialog.dismiss();
            finish();
            return;
        }
        if (id == C0347R.id.SurfIntButtonCancel) {
            this.dialog.dismiss();
            return;
        }
        if (id == C0347R.id.buttonResultReport) {
            onOptionsItemSelected(this.mOptionsMenu.findItem(C0347R.id.multideco_report_xml));
            return;
        }
        if (id == C0347R.id.buttonResultNext) {
            onOptionsItemSelected(this.mOptionsMenu.findItem(452392));
            return;
        }
        if (id == C0347R.id.imageBtnResultCopy) {
            onOptionsItemSelected(this.mOptionsMenu.findItem(436849));
        } else if (id == C0347R.id.imageBtnResultEmail) {
            onOptionsItemSelected(this.mOptionsMenu.findItem(446217));
        } else if (id == C0347R.id.imageBtnResultWebFAQ) {
            onOptionsItemSelected(this.mOptionsMenu.findItem(446221));
        }
    }
}
