package com.hhssoftware.multideco;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

/* loaded from: classes.dex */
public class multideco_toolslist extends ListActivity {
    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        setTheme(new Theme_setting(this).theme_id);
        super.onCreate(bundle);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1) { // from class: com.hhssoftware.multideco.multideco_toolslist.1
            @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
            public View getDropDownView(int i, View view, ViewGroup viewGroup) {
                View dropDownView = super.getDropDownView(i, view, viewGroup);
                ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                return dropDownView;
            }
        };
        arrayAdapter.add(getString(C0347R.string.toolListItems_EAD));
        arrayAdapter.add(getString(C0347R.string.toolListItems_Best));
        arrayAdapter.add(getString(C0347R.string.toolListItems_MixConfig));
        arrayAdapter.add(getString(C0347R.string.toolListItems_MixNitrox));
        arrayAdapter.add(getString(C0347R.string.toolListItems_MixTrimix));
        arrayAdapter.add(getString(C0347R.string.toolListItems_MixTopup));
        arrayAdapter.add(getString(C0347R.string.toolListItems_MixFill));
        arrayAdapter.add(getString(C0347R.string.toolListItems_Density));
        setListAdapter(arrayAdapter);
        getListView().setTextFilterEnabled(true);
        getListView().setFitsSystemWindows(true);
    }

    @Override // android.app.ListActivity
    protected void onListItemClick(ListView listView, View view, int i, long j) {
        switch (i) {
            case 0:
                startActivity(new Intent(this, (Class<?>) multideco_eadmod.class));
                break;
            case 1:
                startActivity(new Intent(this, (Class<?>) multideco_bestmix.class));
                break;
            case 2:
                startActivity(new Intent(this, (Class<?>) mixer_config.class));
                break;
            case 3:
                startActivity(new Intent(this, (Class<?>) mixer_nitrox.class));
                break;
            case 4:
                startActivity(new Intent(this, (Class<?>) mixer_trimix.class));
                break;
            case 5:
                startActivity(new Intent(this, (Class<?>) mixer_topup.class));
                break;
            case 6:
                startActivity(new Intent(this, (Class<?>) mixer_capacity.class));
                break;
            case 7:
                startActivity(new Intent(this, (Class<?>) mixer_density.class));
                break;
        }
        super.onListItemClick(listView, view, i, j);
    }
}
