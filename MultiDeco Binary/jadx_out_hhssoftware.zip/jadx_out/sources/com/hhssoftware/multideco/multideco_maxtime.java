package com.hhssoftware.multideco;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Looper;
import android.os.MessageQueue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TableRow;
import android.widget.TextView;
import com.hhssoftware.multideco.Gastank_setting;
import java.util.ArrayList;

/* loaded from: classes.dex */
public class multideco_maxtime extends Activity implements AdapterView.OnItemSelectedListener, View.OnClickListener, MessageQueue.IdleHandler {
    private final int MIX_ID = 3536300;
    private final int[] textMixID = {C0347R.id.MixMaxOCmix0, C0347R.id.MixMaxOCmix1, C0347R.id.MixMaxOCmix2, C0347R.id.MixMaxOCmix3, C0347R.id.MixMaxOCmix4, C0347R.id.MixMaxOCmix5, C0347R.id.MixMaxOCmix6, C0347R.id.MixMaxOCmix7};
    private final int[] tableRowID = {C0347R.id.TableMaxOCmix0, C0347R.id.TableMaxOCmix1, C0347R.id.TableMaxOCmix2, C0347R.id.TableMaxOCmix3, C0347R.id.TableMaxOCmix4, C0347R.id.TableMaxOCmix5, C0347R.id.TableMaxOCmix6, C0347R.id.TableMaxOCmix7};
    private final int[] spinnerTank = {C0347R.id.TanksMaxOCmix0, C0347R.id.TanksMaxOCmix1, C0347R.id.TanksMaxOCmix2, C0347R.id.TanksMaxOCmix3, C0347R.id.TanksMaxOCmix4, C0347R.id.TanksMaxOCmix5, C0347R.id.TanksMaxOCmix6, C0347R.id.TanksMaxOCmix7};
    private final int[] editFromP = {C0347R.id.FromPMaxOCmix0, C0347R.id.FromPMaxOCmix1, C0347R.id.FromPMaxOCmix2, C0347R.id.FromPMaxOCmix3, C0347R.id.FromPMaxOCmix4, C0347R.id.FromPMaxOCmix5, C0347R.id.FromPMaxOCmix6, C0347R.id.FromPMaxOCmix7};
    private final int[] editToP = {C0347R.id.ToPMaxOCmix0, C0347R.id.ToPMaxOCmix1, C0347R.id.ToPMaxOCmix2, C0347R.id.ToPMaxOCmix3, C0347R.id.ToPMaxOCmix4, C0347R.id.ToPMaxOCmix5, C0347R.id.ToPMaxOCmix6, C0347R.id.ToPMaxOCmix7};
    private boolean isIniting = true;

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public void onNothingSelected(AdapterView<?> adapterView) {
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        setTheme(new Theme_setting(this).theme_id);
        super.onCreate(bundle);
        setContentView(C0347R.layout.multideco_maxtime);
        setResult(0, getIntent());
        initForm();
        getWindow().setSoftInputMode(2);
        Looper.myQueue().addIdleHandler(this);
    }

    @Override // android.os.MessageQueue.IdleHandler
    public boolean queueIdle() {
        this.isIniting = false;
        return false;
    }

    private void initForm() {
        String str;
        Intent intent = getIntent();
        for (int i = 0; i < 8; i++) {
            ((TextView) findViewById(this.textMixID[i])).setTag(3536299);
            ((Spinner) findViewById(this.spinnerTank[i])).setOnItemSelectedListener(this);
        }
        setTanks(false);
        if (intent.hasExtra("OCMixes")) {
            String[] stringArrayExtra = intent.getStringArrayExtra("OCMixes");
            for (int i2 = 0; i2 < stringArrayExtra.length && (str = stringArrayExtra[i2]) != null && str.length() != 0; i2++) {
                setGasMix(str, true, i2);
            }
        }
        findViewById(C0347R.id.OCMaxtimeplanSetup).setOnClickListener(this);
        findViewById(C0347R.id.ButtonOCMaxCalculate).setOnClickListener(this);
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
        if (this.isIniting) {
            return;
        }
        int id = adapterView.getId();
        Gastank_setting gastank_setting = new Gastank_setting(this, 1);
        for (int i2 = 0; i2 < 8; i2++) {
            if (id == this.spinnerTank[i2]) {
                ((EditText) findViewById(this.editFromP[i2])).setText(Double.toString(gastank_setting.gettank(i).FillPress).replaceFirst(".0$", ""));
                ((EditText) findViewById(this.editToP[i2])).setText("");
                return;
            }
        }
    }

    private void setGasMix(String str, boolean z, int i) {
        int i2 = 0;
        while (true) {
            if (i2 >= 8) {
                i2 = -1;
                break;
            }
            TextView textView = (TextView) findViewById(this.textMixID[i2]);
            String obj = textView.getText().toString();
            if (str.equals(obj) && !z) {
                textView.setText("");
                textView.setTag(3536299);
                ((EditText) findViewById(this.editFromP[i2])).setText("");
                ((EditText) findViewById(this.editToP[i2])).setText("");
                break;
            }
            if (obj.isEmpty() && z) {
                Gastank_setting gastank_setting = new Gastank_setting(this, 1);
                int selectedItemPosition = ((Spinner) findViewById(this.spinnerTank[i2])).getSelectedItemPosition();
                if (selectedItemPosition < 0) {
                    selectedItemPosition = 0;
                }
                Gastank_setting.TankSize tankSize = gastank_setting.gettank(selectedItemPosition);
                textView.setText(str);
                textView.setTag(Integer.valueOf(i + 3536300));
                EditText editText = (EditText) findViewById(this.editFromP[i2]);
                if (editText.getText().toString().isEmpty()) {
                    if (tankSize.FillPress > 0.0d) {
                        editText.setText(Double.toString(tankSize.FillPress).replaceFirst(".0$", ""));
                    }
                    Gastank_setting.TankPress tankPress = gastank_setting.getpress(i2);
                    if (tankPress.TankIdx == selectedItemPosition && tankPress.FromP > 0.0d) {
                        editText.setText(Double.toString(tankPress.FromP).replaceFirst(".0$", ""));
                        EditText editText2 = (EditText) findViewById(this.editToP[i2]);
                        if (editText2.getText().toString().isEmpty()) {
                            editText2.setText(Double.toString(tankPress.ToP).replaceFirst(".0$", ""));
                        }
                    }
                }
            } else {
                i2++;
            }
        }
        if (i2 > -1) {
            if (z) {
                ((TableRow) findViewById(this.tableRowID[i2])).setVisibility(0);
            } else {
                ((TableRow) findViewById(this.tableRowID[i2])).setVisibility(8);
            }
        }
    }

    private void setTanks(boolean z) {
        ArrayAdapter<String> arrayAdapter;
        Gastank_setting gastank_setting = new Gastank_setting(this, 1);
        if (!z) {
            arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item) { // from class: com.hhssoftware.multideco.multideco_maxtime.1
                @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
                public View getDropDownView(int i, View view, ViewGroup viewGroup) {
                    View dropDownView = super.getDropDownView(i, view, viewGroup);
                    ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                    return dropDownView;
                }
            };
            arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        } else {
            arrayAdapter = (ArrayAdapter) ((Spinner) findViewById(this.spinnerTank[0])).getAdapter();
            arrayAdapter.clear();
        }
        int valid_gastanks = gastank_setting.valid_gastanks();
        for (int i = 0; i < valid_gastanks; i++) {
            arrayAdapter.add(gastank_setting.gettank(i).Name);
        }
        for (int i2 = 0; i2 < 8; i2++) {
            Spinner spinner = (Spinner) findViewById(this.spinnerTank[i2]);
            if (!z) {
                spinner.setAdapter((SpinnerAdapter) arrayAdapter);
            }
            if (valid_gastanks == 0) {
                spinner.setSelection(-1);
            } else if (gastank_setting.ocMaxTimeMixChoice[i2] < valid_gastanks) {
                spinner.setSelection(gastank_setting.ocMaxTimeMixChoice[i2], true);
            }
        }
    }

    @Override // android.app.Activity
    protected void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == C0347R.id.settank_xml && i2 == -1) {
            setTanks(true);
        }
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        int selectedItemPosition;
        int id = view.getId();
        if (id == C0347R.id.ButtonOCMaxCalculate) {
            Intent intent = getIntent();
            ArrayList<String> arrayList = new ArrayList<>();
            Gastank_setting gastank_setting = new Gastank_setting(this, 1);
            for (int i = 0; i < 8; i++) {
                TextView textView = (TextView) findViewById(this.textMixID[i]);
                if (((Integer) textView.getTag()).intValue() != 3536299 && (selectedItemPosition = ((Spinner) findViewById(this.spinnerTank[i])).getSelectedItemPosition()) >= 0) {
                    gastank_setting.ocMaxTimeMixChoice[i] = (byte) selectedItemPosition;
                    String obj = ((EditText) findViewById(this.editFromP[i])).getText().toString();
                    String obj2 = ((EditText) findViewById(this.editToP[i])).getText().toString();
                    try {
                        int intValue = ((Integer) textView.getTag()).intValue() - 3536300;
                        gastank_setting.setpress(i, selectedItemPosition, Double.parseDouble(obj.replace(",", ".")), Double.parseDouble(obj2.replace(",", ".")));
                        arrayList.add(intValue + ":" + i);
                    } catch (NumberFormatException unused) {
                        gastank_setting.setpress(i, selectedItemPosition, 0.0d, 0.0d);
                    }
                }
            }
            gastank_setting.update_gastank_setting();
            if (arrayList.size() > 0) {
                intent.putStringArrayListExtra("MixTankSelected", arrayList);
            }
            setResult(-1, intent);
            finish();
            return;
        }
        if (id == C0347R.id.OCMaxtimeplanSetup) {
            Intent intent2 = new Intent(this, (Class<?>) settank.class);
            intent2.putExtra("OC", true);
            startActivityForResult(intent2, C0347R.id.settank_xml);
        }
    }
}
