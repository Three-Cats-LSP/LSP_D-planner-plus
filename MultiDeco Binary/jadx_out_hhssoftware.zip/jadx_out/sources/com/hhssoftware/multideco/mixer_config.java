package com.hhssoftware.multideco;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;

/* loaded from: classes.dex */
public class mixer_config extends Activity implements AdapterView.OnItemSelectedListener, View.OnClickListener {
    private Boolean init;
    private Settings settings;

    private int BooltoInt(boolean z) {
        return z ? 1 : 0;
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public void onNothingSelected(AdapterView<?> adapterView) {
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        setTheme(new Theme_setting(this).theme_id);
        super.onCreate(bundle);
        setContentView(C0347R.layout.mixer_config);
        this.settings = new Settings(this);
        this.init = true;
        initForm();
    }

    private void initForm() {
        ArrayAdapter<String> arrayAdapter;
        if (Build.VERSION.SDK_INT < 35) {
            findViewById(C0347R.id.mixer_config_xml).setPadding(0, 0, 0, 0);
        }
        if (this.settings.mix_temp_units == 1) {
            ((CompoundButton) findViewById(C0347R.id.mixerF)).setChecked(true);
        } else {
            ((CompoundButton) findViewById(C0347R.id.mixerC)).setChecked(true);
        }
        if (this.settings.mix_units == 1) {
            ((CompoundButton) findViewById(C0347R.id.mixerPSI)).setChecked(true);
        } else {
            ((CompoundButton) findViewById(C0347R.id.mixerBar)).setChecked(true);
        }
        Spinner spinner = (Spinner) findViewById(C0347R.id.mixerTemp);
        if (this.init.booleanValue()) {
            arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item) { // from class: com.hhssoftware.multideco.mixer_config.1
                @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
                public View getDropDownView(int i, View view, ViewGroup viewGroup) {
                    View dropDownView = super.getDropDownView(i, view, viewGroup);
                    ((TextView) dropDownView.findViewById(android.R.id.text1)).setTextSize(20.0f);
                    return dropDownView;
                }
            };
            arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        } else {
            arrayAdapter = (ArrayAdapter) spinner.getAdapter();
            arrayAdapter.clear();
        }
        if (this.settings.mix_temp_units == 1) {
            for (int i = 0; i <= 35; i += 5) {
                arrayAdapter.add((((i * 9) / 5) + 32) + " F");
            }
        } else {
            for (int i2 = 0; i2 <= 35; i2 += 5) {
                arrayAdapter.add(i2 + " C");
            }
        }
        if (this.init.booleanValue()) {
            spinner.setAdapter((SpinnerAdapter) arrayAdapter);
        }
        spinner.setSelection(this.settings.mix_temp);
        spinner.setOnItemSelectedListener(this);
        if (this.settings.mix_banked32) {
            ((CompoundButton) findViewById(C0347R.id.mixBanked32)).setChecked(true);
        } else {
            ((CompoundButton) findViewById(C0347R.id.mixBankedAir)).setChecked(true);
        }
        findViewById(C0347R.id.mixerBar).setOnClickListener(this);
        findViewById(C0347R.id.mixerPSI).setOnClickListener(this);
        findViewById(C0347R.id.mixerC).setOnClickListener(this);
        findViewById(C0347R.id.mixerF).setOnClickListener(this);
        findViewById(C0347R.id.mixBankedAir).setOnClickListener(this);
        findViewById(C0347R.id.mixBanked32).setOnClickListener(this);
        this.init = false;
    }

    private void saveFormData() {
        this.settings.mix_temp = ((Spinner) findViewById(C0347R.id.mixerTemp)).getSelectedItemPosition();
        this.settings.mix_temp_units = BooltoInt(((CompoundButton) findViewById(C0347R.id.mixerF)).isChecked());
        this.settings.mix_units = BooltoInt(((CompoundButton) findViewById(C0347R.id.mixerPSI)).isChecked());
        this.settings.mix_banked32 = ((CompoundButton) findViewById(C0347R.id.mixBanked32)).isChecked();
        this.settings.saveConfig();
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
        saveFormData();
        initForm();
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        saveFormData();
        initForm();
    }
}
