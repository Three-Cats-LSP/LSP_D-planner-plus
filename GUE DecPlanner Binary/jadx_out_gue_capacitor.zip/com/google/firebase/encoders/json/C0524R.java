package com.google.firebase.encoders.json;

/* renamed from: com.google.firebase.encoders.json.R */
/* loaded from: classes.dex */
public final class C0524R {
    private C0524R() {
    }
}
