package com.google.firebase.components;

/* renamed from: com.google.firebase.components.R */
/* loaded from: classes.dex */
public final class C0518R {
    private C0518R() {
    }
}
