package com.google.firebase.analytics.connector;

/* renamed from: com.google.firebase.analytics.connector.R */
/* loaded from: classes.dex */
public final class C0510R {
    private C0510R() {
    }
}
