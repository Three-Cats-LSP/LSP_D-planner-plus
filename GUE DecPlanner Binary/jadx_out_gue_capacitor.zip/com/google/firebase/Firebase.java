package com.google.firebase;

import kotlin.Metadata;

/* compiled from: Firebase.kt */
@Metadata(m565d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002¨\u0006\u0003"}, m566d2 = {"Lcom/google/firebase/Firebase;", "", "()V", "com.google.firebase-firebase-common"}, m567k = 1, m568mv = {1, 7, 1}, m570xi = 48)
/* loaded from: classes.dex */
public final class Firebase {
    public static final Firebase INSTANCE = new Firebase();

    private Firebase() {
    }
}
