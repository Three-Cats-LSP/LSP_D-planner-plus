package com.google.firebase.iid.internal;

/* renamed from: com.google.firebase.iid.internal.R */
/* loaded from: classes.dex */
public final class C0527R {
    private C0527R() {
    }
}
