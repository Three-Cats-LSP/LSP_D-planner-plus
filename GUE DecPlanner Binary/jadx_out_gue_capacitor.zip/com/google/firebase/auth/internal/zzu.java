package com.google.firebase.auth.internal;

import com.google.android.gms.internal.p006firebaseauthapi.zzafv;
import com.google.firebase.auth.ActionCodeInfo;
import com.google.firebase.auth.ActionCodeResult;

/* compiled from: com.google.firebase:firebase-auth@@22.3.1 */
/* loaded from: classes.dex */
public final class zzu implements ActionCodeResult {
    private final int zza;
    private final String zzb;
    private final String zzc;
    private final ActionCodeInfo zzd;

    @Override // com.google.firebase.auth.ActionCodeResult
    public final String getData(int i) {
        if (this.zza == 4) {
            return null;
        }
        if (i == 0) {
            return this.zzb;
        }
        if (i != 1) {
            return null;
        }
        return this.zzc;
    }

    @Override // com.google.firebase.auth.ActionCodeResult
    public final ActionCodeInfo getInfo() {
        return this.zzd;
    }

    @Override // com.google.firebase.auth.ActionCodeResult
    public final int getOperation() {
        return this.zza;
    }

    public zzu(zzafv zzafvVar) {
        int i;
        this.zzb = zzafvVar.zzg() ? zzafvVar.zzc() : zzafvVar.zzb();
        this.zzc = zzafvVar.zzb();
        ActionCodeInfo actionCodeInfo = null;
        if (!zzafvVar.zzh()) {
            this.zza = 3;
            this.zzd = null;
            return;
        }
        String zzd = zzafvVar.zzd();
        zzd.hashCode();
        i = 5;
        switch (zzd) {
            case "REVERT_SECOND_FACTOR_ADDITION":
                i = 6;
                break;
            case "PASSWORD_RESET":
                i = 0;
                break;
            case "VERIFY_EMAIL":
                i = 1;
                break;
            case "VERIFY_AND_CHANGE_EMAIL":
                break;
            case "EMAIL_SIGNIN":
                i = 4;
                break;
            case "RECOVER_EMAIL":
                i = 2;
                break;
            default:
                i = 3;
                break;
        }
        this.zza = i;
        if (i == 4 || i == 3) {
            this.zzd = null;
            return;
        }
        if (zzafvVar.zzf()) {
            actionCodeInfo = new zzv(zzafvVar.zzb(), zzbk.zza(zzafvVar.zza()));
        } else if (zzafvVar.zzg()) {
            actionCodeInfo = new zzt(zzafvVar.zzc(), zzafvVar.zzb());
        } else if (zzafvVar.zze()) {
            actionCodeInfo = new zzs(zzafvVar.zzb());
        }
        this.zzd = actionCodeInfo;
    }
}
