package com.google.firebase.auth.internal;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;

/* compiled from: com.google.firebase:firebase-auth@@22.3.1 */
/* loaded from: classes.dex */
final class zzak implements Continuation<AuthResult, Task<AuthResult>> {
    private final /* synthetic */ zzal zza;

    @Override // com.google.android.gms.tasks.Continuation
    public final /* synthetic */ Task<AuthResult> then(Task<AuthResult> task) throws Exception {
        com.google.firebase.auth.zzd zzdVar;
        com.google.firebase.auth.zzd zzdVar2;
        com.google.firebase.auth.zzd zzdVar3;
        zzdVar = this.zza.zzd;
        if (zzdVar == null) {
            return task;
        }
        if (task.isSuccessful()) {
            AuthResult result = task.getResult();
            zzaf zzafVar = (zzaf) result.getUser();
            zzx zzxVar = (zzx) result.getAdditionalUserInfo();
            zzdVar3 = this.zza.zzd;
            return Tasks.forResult(new zzz(zzafVar, zzxVar, zzdVar3));
        }
        Exception exception = task.getException();
        if (exception instanceof FirebaseAuthUserCollisionException) {
            zzdVar2 = this.zza.zzd;
            ((FirebaseAuthUserCollisionException) exception).zza(zzdVar2);
        }
        return Tasks.forException(exception);
    }

    zzak(zzal zzalVar) {
        this.zza = zzalVar;
    }
}
