package com.google.firebase.auth.internal;

import com.google.android.gms.internal.p006firebaseauthapi.zzafm;
import com.google.firebase.auth.FirebaseUser;

/* compiled from: com.google.firebase:firebase-auth@@22.3.1 */
/* loaded from: classes.dex */
public interface zzl {
    void zza(zzafm zzafmVar, FirebaseUser firebaseUser);
}
