package com.google.firebase.auth.internal;

/* renamed from: com.google.firebase.auth.internal.R */
/* loaded from: classes.dex */
public final class C0513R {
    private C0513R() {
    }
}
