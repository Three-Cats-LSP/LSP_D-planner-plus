package com.google.firebase.auth.internal;

/* compiled from: com.google.firebase:firebase-auth@@22.3.1 */
/* loaded from: classes.dex */
public interface zzav extends zzau {
    void zza();
}
