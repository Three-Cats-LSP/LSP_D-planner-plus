package com.google.firebase.auth.internal;

/* compiled from: com.google.firebase:firebase-auth@@22.3.1 */
/* loaded from: classes.dex */
public final class zzbu extends Exception {
    public zzbu(String str) {
        super(str);
    }
}
