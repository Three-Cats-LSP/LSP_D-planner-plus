package com.google.firebase.auth;

/* compiled from: com.google.firebase:firebase-auth@@22.3.1 */
/* loaded from: classes.dex */
public abstract class MultiFactorAssertion {
    public abstract String getFactorId();
}
