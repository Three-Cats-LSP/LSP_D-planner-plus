package com.google.firebase.auth;

/* renamed from: com.google.firebase.auth.R */
/* loaded from: classes.dex */
public final class C0512R {
    private C0512R() {
    }
}
