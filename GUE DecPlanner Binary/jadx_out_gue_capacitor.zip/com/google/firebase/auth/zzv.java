package com.google.firebase.auth;

import com.google.android.gms.common.internal.Preconditions;
import com.google.android.gms.internal.p006firebaseauthapi.zzaag;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import io.capawesome.capacitorjs.plugins.firebase.authentication.FirebaseAuthenticationHelper;

/* compiled from: com.google.firebase:firebase-auth@@22.3.1 */
/* loaded from: classes.dex */
final class zzv implements Continuation<GetTokenResult, Task<Void>> {
    private final /* synthetic */ String zza;
    private final /* synthetic */ FirebaseAuth zzb;

    @Override // com.google.android.gms.tasks.Continuation
    public final /* synthetic */ Task<Void> then(Task<GetTokenResult> task) throws Exception {
        zzaag zzaagVar;
        String str;
        if (!task.isSuccessful()) {
            return Tasks.forException((Exception) Preconditions.checkNotNull(task.getException()));
        }
        zzaagVar = this.zzb.zze;
        String str2 = this.zza;
        String str3 = (String) Preconditions.checkNotNull(task.getResult().getToken());
        str = this.zzb.zzk;
        return zzaagVar.zza(str2, str3, FirebaseAuthenticationHelper.ProviderId.APPLE, str);
    }

    zzv(FirebaseAuth firebaseAuth, String str) {
        this.zza = str;
        this.zzb = firebaseAuth;
    }
}
