package com.google.firebase.auth;

import com.google.android.gms.common.internal.Preconditions;
import com.google.android.gms.internal.p006firebaseauthapi.zzagi;
import com.google.android.gms.internal.p006firebaseauthapi.zzago;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.auth.internal.zzcd;

/* compiled from: com.google.firebase:firebase-auth@@22.3.1 */
/* loaded from: classes.dex */
final class zzw implements Continuation<zzagi, Task<TotpSecret>> {
    private final /* synthetic */ FirebaseAuth zza;

    @Override // com.google.android.gms.tasks.Continuation
    public final /* synthetic */ Task<TotpSecret> then(Task<zzagi> task) throws Exception {
        if (!task.isSuccessful()) {
            return Tasks.forException((Exception) Preconditions.checkNotNull(task.getException()));
        }
        zzagi result = task.getResult();
        if (result instanceof zzago) {
            zzago zzagoVar = (zzago) result;
            return Tasks.forResult(new zzcd(Preconditions.checkNotEmpty(zzagoVar.zzf()), Preconditions.checkNotEmpty(zzagoVar.zze()), zzagoVar.zzc(), zzagoVar.zzb(), zzagoVar.zzd(), Preconditions.checkNotEmpty(zzagoVar.zza()), this.zza));
        }
        throw new IllegalArgumentException("Response should be an instance of StartTotpMfaEnrollmentResponse but was " + result.getClass().getName() + ".");
    }

    zzw(FirebaseAuth firebaseAuth) {
        this.zza = firebaseAuth;
    }
}
