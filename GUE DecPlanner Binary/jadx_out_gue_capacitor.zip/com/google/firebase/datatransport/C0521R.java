package com.google.firebase.datatransport;

import cloud.udive.app.C0346R;

/* renamed from: com.google.firebase.datatransport.R */
/* loaded from: classes.dex */
public final class C0521R {

    /* renamed from: com.google.firebase.datatransport.R$attr */
    public static final class attr {
        public static int alpha = 2130903081;
        public static int coordinatorLayoutStyle = 2130903143;
        public static int font = 2130903173;
        public static int fontProviderAuthority = 2130903175;
        public static int fontProviderCerts = 2130903176;
        public static int fontProviderFetchStrategy = 2130903177;
        public static int fontProviderFetchTimeout = 2130903178;
        public static int fontProviderPackage = 2130903179;
        public static int fontProviderQuery = 2130903180;
        public static int fontStyle = 2130903182;
        public static int fontVariationSettings = 2130903183;
        public static int fontWeight = 2130903184;
        public static int keylines = 2130903202;
        public static int layout_anchor = 2130903206;
        public static int layout_anchorGravity = 2130903207;
        public static int layout_behavior = 2130903208;
        public static int layout_dodgeInsetEdges = 2130903209;
        public static int layout_insetEdge = 2130903210;
        public static int layout_keyline = 2130903211;
        public static int statusBarBackground = 2130903282;
        public static int ttcIndex = 2130903334;

        private attr() {
        }
    }

    /* renamed from: com.google.firebase.datatransport.R$color */
    public static final class color {
        public static int notification_action_color_filter = 2131034196;
        public static int notification_icon_bg_color = 2131034197;
        public static int ripple_material_light = 2131034207;
        public static int secondary_text_default_material_light = 2131034209;

        private color() {
        }
    }

    /* renamed from: com.google.firebase.datatransport.R$dimen */
    public static final class dimen {
        public static int compat_button_inset_horizontal_material = 2131099731;
        public static int compat_button_inset_vertical_material = 2131099732;
        public static int compat_button_padding_horizontal_material = 2131099733;
        public static int compat_button_padding_vertical_material = 2131099734;
        public static int compat_control_corner_material = 2131099735;
        public static int compat_notification_large_icon_max_height = 2131099736;
        public static int compat_notification_large_icon_max_width = 2131099737;
        public static int notification_action_icon_size = 2131099747;
        public static int notification_action_text_size = 2131099748;
        public static int notification_big_circle_margin = 2131099749;
        public static int notification_content_margin_start = 2131099750;
        public static int notification_large_icon_height = 2131099751;
        public static int notification_large_icon_width = 2131099752;
        public static int notification_main_column_padding_top = 2131099753;
        public static int notification_media_narrow_margin = 2131099754;
        public static int notification_right_icon_size = 2131099755;
        public static int notification_right_side_padding_top = 2131099756;
        public static int notification_small_icon_background_padding = 2131099757;
        public static int notification_small_icon_size_as_large = 2131099758;
        public static int notification_subtext_size = 2131099759;
        public static int notification_top_pad = 2131099760;
        public static int notification_top_pad_large_text = 2131099761;

        private dimen() {
        }
    }

    /* renamed from: com.google.firebase.datatransport.R$drawable */
    public static final class drawable {
        public static int notification_action_background = 2131165304;
        public static int notification_bg = 2131165305;
        public static int notification_bg_low = 2131165306;
        public static int notification_bg_low_normal = 2131165307;
        public static int notification_bg_low_pressed = 2131165308;
        public static int notification_bg_normal = 2131165309;
        public static int notification_bg_normal_pressed = 2131165310;
        public static int notification_icon_background = 2131165311;
        public static int notification_template_icon_bg = 2131165313;
        public static int notification_template_icon_low_bg = 2131165314;
        public static int notification_tile_bg = 2131165315;
        public static int notify_panel_notification_icon_bg = 2131165316;

        private drawable() {
        }
    }

    /* renamed from: com.google.firebase.datatransport.R$id */
    public static final class id {
        public static int accessibility_action_clickable_span = 2131230726;
        public static int accessibility_custom_action_0 = 2131230727;
        public static int accessibility_custom_action_1 = 2131230728;
        public static int accessibility_custom_action_10 = 2131230729;
        public static int accessibility_custom_action_11 = 2131230730;
        public static int accessibility_custom_action_12 = 2131230731;
        public static int accessibility_custom_action_13 = 2131230732;
        public static int accessibility_custom_action_14 = 2131230733;
        public static int accessibility_custom_action_15 = 2131230734;
        public static int accessibility_custom_action_16 = 2131230735;
        public static int accessibility_custom_action_17 = 2131230736;
        public static int accessibility_custom_action_18 = 2131230737;
        public static int accessibility_custom_action_19 = 2131230738;
        public static int accessibility_custom_action_2 = 2131230739;
        public static int accessibility_custom_action_20 = 2131230740;
        public static int accessibility_custom_action_21 = 2131230741;
        public static int accessibility_custom_action_22 = 2131230742;
        public static int accessibility_custom_action_23 = 2131230743;
        public static int accessibility_custom_action_24 = 2131230744;
        public static int accessibility_custom_action_25 = 2131230745;
        public static int accessibility_custom_action_26 = 2131230746;
        public static int accessibility_custom_action_27 = 2131230747;
        public static int accessibility_custom_action_28 = 2131230748;
        public static int accessibility_custom_action_29 = 2131230749;
        public static int accessibility_custom_action_3 = 2131230750;
        public static int accessibility_custom_action_30 = 2131230751;
        public static int accessibility_custom_action_31 = 2131230752;
        public static int accessibility_custom_action_4 = 2131230753;
        public static int accessibility_custom_action_5 = 2131230754;
        public static int accessibility_custom_action_6 = 2131230755;
        public static int accessibility_custom_action_7 = 2131230756;
        public static int accessibility_custom_action_8 = 2131230757;
        public static int accessibility_custom_action_9 = 2131230758;
        public static int action_container = 2131230766;
        public static int action_divider = 2131230768;
        public static int action_image = 2131230769;
        public static int action_text = 2131230775;
        public static int actions = 2131230776;
        public static int async = 2131230784;
        public static int blocking = 2131230787;
        public static int bottom = 2131230788;
        public static int chronometer = 2131230800;
        public static int dialog_button = 2131230811;
        public static int end = 2131230815;
        public static int forever = 2131230821;
        public static int icon = 2131230827;
        public static int icon_group = 2131230828;
        public static int info = 2131230832;
        public static int italic = 2131230833;
        public static int left = 2131230834;
        public static int line1 = 2131230836;
        public static int line3 = 2131230837;
        public static int none = 2131230844;
        public static int normal = 2131230845;
        public static int notification_background = 2131230846;
        public static int notification_main_column = 2131230847;
        public static int notification_main_column_container = 2131230848;
        public static int right = 2131230856;
        public static int right_icon = 2131230857;
        public static int right_side = 2131230858;
        public static int start = 2131230886;
        public static int tag_accessibility_actions = 2131230890;
        public static int tag_accessibility_clickable_spans = 2131230891;
        public static int tag_accessibility_heading = 2131230892;
        public static int tag_accessibility_pane_title = 2131230893;
        public static int tag_screen_reader_focusable = 2131230897;
        public static int tag_transition_group = 2131230899;
        public static int tag_unhandled_key_event_manager = 2131230900;
        public static int tag_unhandled_key_listeners = 2131230901;
        public static int text = 2131230903;
        public static int text2 = 2131230904;
        public static int time = 2131230908;
        public static int title = 2131230909;
        public static int top = 2131230912;

        private id() {
        }
    }

    /* renamed from: com.google.firebase.datatransport.R$integer */
    public static final class integer {
        public static int google_play_services_version = 2131296261;
        public static int status_bar_notification_info_maxnum = 2131296262;

        private integer() {
        }
    }

    /* renamed from: com.google.firebase.datatransport.R$layout */
    public static final class layout {
        public static int custom_dialog = 2131427360;
        public static int notification_action = 2131427365;
        public static int notification_action_tombstone = 2131427366;
        public static int notification_template_custom_big = 2131427367;
        public static int notification_template_icon_group = 2131427368;
        public static int notification_template_part_chronometer = 2131427369;
        public static int notification_template_part_time = 2131427370;

        private layout() {
        }
    }

    /* renamed from: com.google.firebase.datatransport.R$raw */
    public static final class raw {
        public static int firebase_common_keep = 2131558400;

        private raw() {
        }
    }

    /* renamed from: com.google.firebase.datatransport.R$string */
    public static final class string {
        public static int common_google_play_services_unknown_issue = 2131623980;
        public static int status_bar_notification_info_overflow = 2131624007;

        private string() {
        }
    }

    /* renamed from: com.google.firebase.datatransport.R$style */
    public static final class style {
        public static int TextAppearance_Compat_Notification = 2131689718;
        public static int TextAppearance_Compat_Notification_Info = 2131689719;
        public static int TextAppearance_Compat_Notification_Line2 = 2131689720;
        public static int TextAppearance_Compat_Notification_Time = 2131689721;
        public static int TextAppearance_Compat_Notification_Title = 2131689722;
        public static int Widget_Compat_NotificationActionContainer = 2131689833;
        public static int Widget_Compat_NotificationActionText = 2131689834;
        public static int Widget_Support_CoordinatorLayout = 2131689835;

        private style() {
        }
    }

    /* renamed from: com.google.firebase.datatransport.R$styleable */
    public static final class styleable {
        public static int ColorStateListItem_alpha = 3;
        public static int ColorStateListItem_android_alpha = 1;
        public static int ColorStateListItem_android_color = 0;
        public static int ColorStateListItem_android_lStar = 2;
        public static int ColorStateListItem_lStar = 4;
        public static int CoordinatorLayout_Layout_android_layout_gravity = 0;
        public static int CoordinatorLayout_Layout_layout_anchor = 1;
        public static int CoordinatorLayout_Layout_layout_anchorGravity = 2;
        public static int CoordinatorLayout_Layout_layout_behavior = 3;
        public static int CoordinatorLayout_Layout_layout_dodgeInsetEdges = 4;
        public static int CoordinatorLayout_Layout_layout_insetEdge = 5;
        public static int CoordinatorLayout_Layout_layout_keyline = 6;
        public static int CoordinatorLayout_keylines = 0;
        public static int CoordinatorLayout_statusBarBackground = 1;
        public static int FontFamilyFont_android_font = 0;
        public static int FontFamilyFont_android_fontStyle = 2;
        public static int FontFamilyFont_android_fontVariationSettings = 4;
        public static int FontFamilyFont_android_fontWeight = 1;
        public static int FontFamilyFont_android_ttcIndex = 3;
        public static int FontFamilyFont_font = 5;
        public static int FontFamilyFont_fontStyle = 6;
        public static int FontFamilyFont_fontVariationSettings = 7;
        public static int FontFamilyFont_fontWeight = 8;
        public static int FontFamilyFont_ttcIndex = 9;
        public static int FontFamily_fontProviderAuthority = 0;
        public static int FontFamily_fontProviderCerts = 1;
        public static int FontFamily_fontProviderFetchStrategy = 2;
        public static int FontFamily_fontProviderFetchTimeout = 3;
        public static int FontFamily_fontProviderPackage = 4;
        public static int FontFamily_fontProviderQuery = 5;
        public static int FontFamily_fontProviderSystemFontFamily = 6;
        public static int GradientColorItem_android_color = 0;
        public static int GradientColorItem_android_offset = 1;
        public static int GradientColor_android_centerColor = 7;
        public static int GradientColor_android_centerX = 3;
        public static int GradientColor_android_centerY = 4;
        public static int GradientColor_android_endColor = 1;
        public static int GradientColor_android_endX = 10;
        public static int GradientColor_android_endY = 11;
        public static int GradientColor_android_gradientRadius = 5;
        public static int GradientColor_android_startColor = 0;
        public static int GradientColor_android_startX = 8;
        public static int GradientColor_android_startY = 9;
        public static int GradientColor_android_tileMode = 6;
        public static int GradientColor_android_type = 2;
        public static int[] ColorStateListItem = {android.R.attr.color, android.R.attr.alpha, android.R.attr.lStar, C0346R.attr.alpha, C0346R.attr.lStar};
        public static int[] CoordinatorLayout = {C0346R.attr.keylines, C0346R.attr.statusBarBackground};
        public static int[] CoordinatorLayout_Layout = {android.R.attr.layout_gravity, C0346R.attr.layout_anchor, C0346R.attr.layout_anchorGravity, C0346R.attr.layout_behavior, C0346R.attr.layout_dodgeInsetEdges, C0346R.attr.layout_insetEdge, C0346R.attr.layout_keyline};
        public static int[] FontFamily = {C0346R.attr.fontProviderAuthority, C0346R.attr.fontProviderCerts, C0346R.attr.fontProviderFetchStrategy, C0346R.attr.fontProviderFetchTimeout, C0346R.attr.fontProviderPackage, C0346R.attr.fontProviderQuery, C0346R.attr.fontProviderSystemFontFamily};
        public static int[] FontFamilyFont = {android.R.attr.font, android.R.attr.fontWeight, android.R.attr.fontStyle, android.R.attr.ttcIndex, android.R.attr.fontVariationSettings, C0346R.attr.font, C0346R.attr.fontStyle, C0346R.attr.fontVariationSettings, C0346R.attr.fontWeight, C0346R.attr.ttcIndex};
        public static int[] GradientColor = {android.R.attr.startColor, android.R.attr.endColor, android.R.attr.type, android.R.attr.centerX, android.R.attr.centerY, android.R.attr.gradientRadius, android.R.attr.tileMode, android.R.attr.centerColor, android.R.attr.startX, android.R.attr.startY, android.R.attr.endX, android.R.attr.endY};
        public static int[] GradientColorItem = {android.R.attr.color, android.R.attr.offset};

        private styleable() {
        }
    }

    private C0521R() {
    }
}
