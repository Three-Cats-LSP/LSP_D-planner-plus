package cloud.udive.app;

import com.getcapacitor.BridgeActivity;

/* loaded from: classes.dex */
public class MainActivity extends BridgeActivity {
}
