package cloud.udive.app;

/* renamed from: cloud.udive.app.R */
/* loaded from: classes.dex */
public final class C0346R {

    /* renamed from: cloud.udive.app.R$color */
    public static final class color {
        public static int ic_launcher_background = 2131034183;

        /* JADX INFO: Added by JADX */
        public static final int abc_background_cache_hint_selector_material_dark = 2131034112;

        /* JADX INFO: Added by JADX */
        public static final int abc_background_cache_hint_selector_material_light = 2131034113;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_colored_borderless_text_material = 2131034114;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_colored_text_material = 2131034115;

        /* JADX INFO: Added by JADX */
        public static final int abc_color_highlight_material = 2131034116;

        /* JADX INFO: Added by JADX */
        public static final int abc_decor_view_status_guard = 2131034117;

        /* JADX INFO: Added by JADX */
        public static final int abc_decor_view_status_guard_light = 2131034118;

        /* JADX INFO: Added by JADX */
        public static final int abc_hint_foreground_material_dark = 2131034119;

        /* JADX INFO: Added by JADX */
        public static final int abc_hint_foreground_material_light = 2131034120;

        /* JADX INFO: Added by JADX */
        public static final int abc_primary_text_disable_only_material_dark = 2131034121;

        /* JADX INFO: Added by JADX */
        public static final int abc_primary_text_disable_only_material_light = 2131034122;

        /* JADX INFO: Added by JADX */
        public static final int abc_primary_text_material_dark = 2131034123;

        /* JADX INFO: Added by JADX */
        public static final int abc_primary_text_material_light = 2131034124;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_url_text = 2131034125;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_url_text_normal = 2131034126;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_url_text_pressed = 2131034127;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_url_text_selected = 2131034128;

        /* JADX INFO: Added by JADX */
        public static final int abc_secondary_text_material_dark = 2131034129;

        /* JADX INFO: Added by JADX */
        public static final int abc_secondary_text_material_light = 2131034130;

        /* JADX INFO: Added by JADX */
        public static final int abc_tint_btn_checkable = 2131034131;

        /* JADX INFO: Added by JADX */
        public static final int abc_tint_default = 2131034132;

        /* JADX INFO: Added by JADX */
        public static final int abc_tint_edittext = 2131034133;

        /* JADX INFO: Added by JADX */
        public static final int abc_tint_seek_thumb = 2131034134;

        /* JADX INFO: Added by JADX */
        public static final int abc_tint_spinner = 2131034135;

        /* JADX INFO: Added by JADX */
        public static final int abc_tint_switch_track = 2131034136;

        /* JADX INFO: Added by JADX */
        public static final int accent_material_dark = 2131034137;

        /* JADX INFO: Added by JADX */
        public static final int accent_material_light = 2131034138;

        /* JADX INFO: Added by JADX */
        public static final int androidx_core_ripple_material_light = 2131034139;

        /* JADX INFO: Added by JADX */
        public static final int androidx_core_secondary_text_default_material_light = 2131034140;

        /* JADX INFO: Added by JADX */
        public static final int background_floating_material_dark = 2131034141;

        /* JADX INFO: Added by JADX */
        public static final int background_floating_material_light = 2131034142;

        /* JADX INFO: Added by JADX */
        public static final int background_material_dark = 2131034143;

        /* JADX INFO: Added by JADX */
        public static final int background_material_light = 2131034144;

        /* JADX INFO: Added by JADX */
        public static final int bright_foreground_disabled_material_dark = 2131034145;

        /* JADX INFO: Added by JADX */
        public static final int bright_foreground_disabled_material_light = 2131034146;

        /* JADX INFO: Added by JADX */
        public static final int bright_foreground_inverse_material_dark = 2131034147;

        /* JADX INFO: Added by JADX */
        public static final int bright_foreground_inverse_material_light = 2131034148;

        /* JADX INFO: Added by JADX */
        public static final int bright_foreground_material_dark = 2131034149;

        /* JADX INFO: Added by JADX */
        public static final int bright_foreground_material_light = 2131034150;

        /* JADX INFO: Added by JADX */
        public static final int browser_actions_bg_grey = 2131034151;

        /* JADX INFO: Added by JADX */
        public static final int browser_actions_divider_color = 2131034152;

        /* JADX INFO: Added by JADX */
        public static final int browser_actions_text_color = 2131034153;

        /* JADX INFO: Added by JADX */
        public static final int browser_actions_title_color = 2131034154;

        /* JADX INFO: Added by JADX */
        public static final int button_material_dark = 2131034155;

        /* JADX INFO: Added by JADX */
        public static final int button_material_light = 2131034156;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_answer_color = 2131034157;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_decline_color = 2131034158;

        /* JADX INFO: Added by JADX */
        public static final int colorAccent = 2131034159;

        /* JADX INFO: Added by JADX */
        public static final int colorPrimary = 2131034160;

        /* JADX INFO: Added by JADX */
        public static final int colorPrimaryDark = 2131034161;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_dark = 2131034162;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_dark_default = 2131034163;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_dark_disabled = 2131034164;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_dark_focused = 2131034165;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_dark_pressed = 2131034166;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_light = 2131034167;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_light_default = 2131034168;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_light_disabled = 2131034169;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_light_focused = 2131034170;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_light_pressed = 2131034171;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_tint = 2131034172;

        /* JADX INFO: Added by JADX */
        public static final int dim_foreground_disabled_material_dark = 2131034173;

        /* JADX INFO: Added by JADX */
        public static final int dim_foreground_disabled_material_light = 2131034174;

        /* JADX INFO: Added by JADX */
        public static final int dim_foreground_material_dark = 2131034175;

        /* JADX INFO: Added by JADX */
        public static final int dim_foreground_material_light = 2131034176;

        /* JADX INFO: Added by JADX */
        public static final int error_color_material_dark = 2131034177;

        /* JADX INFO: Added by JADX */
        public static final int error_color_material_light = 2131034178;

        /* JADX INFO: Added by JADX */
        public static final int foreground_material_dark = 2131034179;

        /* JADX INFO: Added by JADX */
        public static final int foreground_material_light = 2131034180;

        /* JADX INFO: Added by JADX */
        public static final int highlighted_text_material_dark = 2131034181;

        /* JADX INFO: Added by JADX */
        public static final int highlighted_text_material_light = 2131034182;

        /* JADX INFO: Added by JADX */
        public static final int material_blue_grey_800 = 2131034184;

        /* JADX INFO: Added by JADX */
        public static final int material_blue_grey_900 = 2131034185;

        /* JADX INFO: Added by JADX */
        public static final int material_blue_grey_950 = 2131034186;

        /* JADX INFO: Added by JADX */
        public static final int material_deep_teal_200 = 2131034187;

        /* JADX INFO: Added by JADX */
        public static final int material_deep_teal_500 = 2131034188;

        /* JADX INFO: Added by JADX */
        public static final int material_grey_100 = 2131034189;

        /* JADX INFO: Added by JADX */
        public static final int material_grey_300 = 2131034190;

        /* JADX INFO: Added by JADX */
        public static final int material_grey_50 = 2131034191;

        /* JADX INFO: Added by JADX */
        public static final int material_grey_600 = 2131034192;

        /* JADX INFO: Added by JADX */
        public static final int material_grey_800 = 2131034193;

        /* JADX INFO: Added by JADX */
        public static final int material_grey_850 = 2131034194;

        /* JADX INFO: Added by JADX */
        public static final int material_grey_900 = 2131034195;

        /* JADX INFO: Added by JADX */
        public static final int notification_action_color_filter = 2131034196;

        /* JADX INFO: Added by JADX */
        public static final int notification_icon_bg_color = 2131034197;

        /* JADX INFO: Added by JADX */
        public static final int primary_dark_material_dark = 2131034198;

        /* JADX INFO: Added by JADX */
        public static final int primary_dark_material_light = 2131034199;

        /* JADX INFO: Added by JADX */
        public static final int primary_material_dark = 2131034200;

        /* JADX INFO: Added by JADX */
        public static final int primary_material_light = 2131034201;

        /* JADX INFO: Added by JADX */
        public static final int primary_text_default_material_dark = 2131034202;

        /* JADX INFO: Added by JADX */
        public static final int primary_text_default_material_light = 2131034203;

        /* JADX INFO: Added by JADX */
        public static final int primary_text_disabled_material_dark = 2131034204;

        /* JADX INFO: Added by JADX */
        public static final int primary_text_disabled_material_light = 2131034205;

        /* JADX INFO: Added by JADX */
        public static final int ripple_material_dark = 2131034206;

        /* JADX INFO: Added by JADX */
        public static final int ripple_material_light = 2131034207;

        /* JADX INFO: Added by JADX */
        public static final int secondary_text_default_material_dark = 2131034208;

        /* JADX INFO: Added by JADX */
        public static final int secondary_text_default_material_light = 2131034209;

        /* JADX INFO: Added by JADX */
        public static final int secondary_text_disabled_material_dark = 2131034210;

        /* JADX INFO: Added by JADX */
        public static final int secondary_text_disabled_material_light = 2131034211;

        /* JADX INFO: Added by JADX */
        public static final int switch_thumb_disabled_material_dark = 2131034212;

        /* JADX INFO: Added by JADX */
        public static final int switch_thumb_disabled_material_light = 2131034213;

        /* JADX INFO: Added by JADX */
        public static final int switch_thumb_material_dark = 2131034214;

        /* JADX INFO: Added by JADX */
        public static final int switch_thumb_material_light = 2131034215;

        /* JADX INFO: Added by JADX */
        public static final int switch_thumb_normal_material_dark = 2131034216;

        /* JADX INFO: Added by JADX */
        public static final int switch_thumb_normal_material_light = 2131034217;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_background_dark = 2131034218;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_background_light = 2131034219;

        private color() {
        }
    }

    /* renamed from: cloud.udive.app.R$drawable */
    public static final class drawable {
        public static int ic_launcher_background = 2131165301;
        public static int ic_launcher_foreground = 2131165302;
        public static int splash = 2131165317;

        /* JADX INFO: Added by JADX */
        public static final int _ic_launcher_foreground__0_res_0x7f070000 = 2131165184;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_item_background_material = 2131165186;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_borderless_material = 2131165187;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_check_material = 2131165188;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_check_material_anim = 2131165189;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_colored_material = 2131165192;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_default_mtrl_shape = 2131165193;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_radio_material = 2131165194;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_radio_material_anim = 2131165195;

        /* JADX INFO: Added by JADX */
        public static final int abc_cab_background_internal_bg = 2131165200;

        /* JADX INFO: Added by JADX */
        public static final int abc_cab_background_top_material = 2131165201;

        /* JADX INFO: Added by JADX */
        public static final int abc_control_background_material = 2131165203;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_material_background = 2131165204;

        /* JADX INFO: Added by JADX */
        public static final int abc_edit_text_material = 2131165205;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_ab_back_material = 2131165206;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_arrow_drop_right_black_24dp = 2131165207;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_clear_material = 2131165208;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_go_search_api_material = 2131165210;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_menu_copy_mtrl_am_alpha = 2131165211;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_menu_cut_mtrl_alpha = 2131165212;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_menu_overflow_material = 2131165213;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_menu_paste_mtrl_am_alpha = 2131165214;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_menu_selectall_mtrl_alpha = 2131165215;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_menu_share_mtrl_alpha = 2131165216;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_search_api_material = 2131165217;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_voice_search_api_material = 2131165218;

        /* JADX INFO: Added by JADX */
        public static final int abc_item_background_holo_dark = 2131165219;

        /* JADX INFO: Added by JADX */
        public static final int abc_item_background_holo_light = 2131165220;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_divider_material = 2131165221;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_selector_background_transition_holo_dark = 2131165227;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_selector_background_transition_holo_light = 2131165228;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_selector_holo_dark = 2131165231;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_selector_holo_light = 2131165232;

        /* JADX INFO: Added by JADX */
        public static final int abc_ratingbar_indicator_material = 2131165235;

        /* JADX INFO: Added by JADX */
        public static final int abc_ratingbar_material = 2131165236;

        /* JADX INFO: Added by JADX */
        public static final int abc_ratingbar_small_material = 2131165237;

        /* JADX INFO: Added by JADX */
        public static final int abc_seekbar_thumb_material = 2131165243;

        /* JADX INFO: Added by JADX */
        public static final int abc_seekbar_tick_mark_material = 2131165244;

        /* JADX INFO: Added by JADX */
        public static final int abc_seekbar_track_material = 2131165245;

        /* JADX INFO: Added by JADX */
        public static final int abc_spinner_textfield_background_material = 2131165247;

        /* JADX INFO: Added by JADX */
        public static final int abc_star_black_48dp = 2131165248;

        /* JADX INFO: Added by JADX */
        public static final int abc_star_half_black_48dp = 2131165249;

        /* JADX INFO: Added by JADX */
        public static final int abc_switch_thumb_material = 2131165250;

        /* JADX INFO: Added by JADX */
        public static final int abc_tab_indicator_material = 2131165252;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_cursor_material = 2131165254;

        /* JADX INFO: Added by JADX */
        public static final int abc_textfield_search_material = 2131165262;

        /* JADX INFO: Added by JADX */
        public static final int abc_vector_test = 2131165263;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_checked_mtrl = 2131165264;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_checked_to_unchecked_mtrl_animation = 2131165265;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_unchecked_mtrl = 2131165266;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_unchecked_to_checked_mtrl_animation = 2131165267;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_off_mtrl = 2131165268;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_off_to_on_mtrl_animation = 2131165269;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_on_mtrl = 2131165270;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_on_to_off_mtrl_animation = 2131165271;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_icon_dark = 2131165273;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_icon_dark_focused = 2131165274;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_icon_dark_normal = 2131165275;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_icon_disabled = 2131165277;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_icon_light = 2131165278;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_icon_light_focused = 2131165279;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_icon_light_normal = 2131165280;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_dark = 2131165282;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_dark_focused = 2131165283;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_dark_normal = 2131165284;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_disabled = 2131165286;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_light = 2131165287;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_light_focused = 2131165288;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_light_normal = 2131165289;

        /* JADX INFO: Added by JADX */
        public static final int compat_splash_screen = 2131165291;

        /* JADX INFO: Added by JADX */
        public static final int compat_splash_screen_no_icon_background = 2131165292;

        /* JADX INFO: Added by JADX */
        public static final int icon_background = 2131165303;

        /* JADX INFO: Added by JADX */
        public static final int notification_action_background = 2131165304;

        /* JADX INFO: Added by JADX */
        public static final int notification_bg = 2131165305;

        /* JADX INFO: Added by JADX */
        public static final int notification_bg_low = 2131165306;

        /* JADX INFO: Added by JADX */
        public static final int notification_icon_background = 2131165311;

        /* JADX INFO: Added by JADX */
        public static final int notification_oversize_large_icon_bg = 2131165312;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_icon_bg = 2131165313;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_icon_low_bg = 2131165314;

        /* JADX INFO: Added by JADX */
        public static final int notification_tile_bg = 2131165315;

        /* JADX INFO: Added by JADX */
        public static final int test_level_drawable = 2131165318;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_frame_dark = 2131165319;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_frame_light = 2131165320;

        private drawable() {
        }
    }

    /* renamed from: cloud.udive.app.R$layout */
    public static final class layout {
        public static int activity_main = 2131427356;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_title_item = 2131427328;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_up_container = 2131427329;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_menu_item_layout = 2131427330;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_menu_layout = 2131427331;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_mode_bar = 2131427332;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_mode_close_item_material = 2131427333;

        /* JADX INFO: Added by JADX */
        public static final int abc_activity_chooser_view = 2131427334;

        /* JADX INFO: Added by JADX */
        public static final int abc_activity_chooser_view_list_item = 2131427335;

        /* JADX INFO: Added by JADX */
        public static final int abc_alert_dialog_button_bar_material = 2131427336;

        /* JADX INFO: Added by JADX */
        public static final int abc_alert_dialog_material = 2131427337;

        /* JADX INFO: Added by JADX */
        public static final int abc_alert_dialog_title_material = 2131427338;

        /* JADX INFO: Added by JADX */
        public static final int abc_cascading_menu_item_layout = 2131427339;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_title_material = 2131427340;

        /* JADX INFO: Added by JADX */
        public static final int abc_expanded_menu_layout = 2131427341;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_menu_item_checkbox = 2131427342;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_menu_item_icon = 2131427343;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_menu_item_layout = 2131427344;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_menu_item_radio = 2131427345;

        /* JADX INFO: Added by JADX */
        public static final int abc_popup_menu_header_item_layout = 2131427346;

        /* JADX INFO: Added by JADX */
        public static final int abc_popup_menu_item_layout = 2131427347;

        /* JADX INFO: Added by JADX */
        public static final int abc_screen_content_include = 2131427348;

        /* JADX INFO: Added by JADX */
        public static final int abc_screen_simple = 2131427349;

        /* JADX INFO: Added by JADX */
        public static final int abc_screen_simple_overlay_action_mode = 2131427350;

        /* JADX INFO: Added by JADX */
        public static final int abc_screen_toolbar = 2131427351;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_dropdown_item_icons_2line = 2131427352;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_view = 2131427353;

        /* JADX INFO: Added by JADX */
        public static final int abc_select_dialog_material = 2131427354;

        /* JADX INFO: Added by JADX */
        public static final int abc_tooltip = 2131427355;

        /* JADX INFO: Added by JADX */
        public static final int bridge_layout_main = 2131427357;

        /* JADX INFO: Added by JADX */
        public static final int browser_actions_context_menu_page = 2131427358;

        /* JADX INFO: Added by JADX */
        public static final int browser_actions_context_menu_row = 2131427359;

        /* JADX INFO: Added by JADX */
        public static final int custom_dialog = 2131427360;

        /* JADX INFO: Added by JADX */
        public static final int fragment_bridge = 2131427361;

        /* JADX INFO: Added by JADX */
        public static final int ime_base_split_test_activity = 2131427362;

        /* JADX INFO: Added by JADX */
        public static final int ime_secondary_split_test_activity = 2131427363;

        /* JADX INFO: Added by JADX */
        public static final int no_webview = 2131427364;

        /* JADX INFO: Added by JADX */
        public static final int notification_action = 2131427365;

        /* JADX INFO: Added by JADX */
        public static final int notification_action_tombstone = 2131427366;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_custom_big = 2131427367;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_icon_group = 2131427368;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_part_chronometer = 2131427369;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_part_time = 2131427370;

        /* JADX INFO: Added by JADX */
        public static final int select_dialog_item_material = 2131427371;

        /* JADX INFO: Added by JADX */
        public static final int select_dialog_multichoice_material = 2131427372;

        /* JADX INFO: Added by JADX */
        public static final int select_dialog_singlechoice_material = 2131427373;

        /* JADX INFO: Added by JADX */
        public static final int splash_screen_view = 2131427374;

        /* JADX INFO: Added by JADX */
        public static final int support_simple_spinner_dropdown_item = 2131427375;

        private layout() {
        }
    }

    /* renamed from: cloud.udive.app.R$mipmap */
    public static final class mipmap {
        public static int ic_launcher = 2131492864;
        public static int ic_launcher_background = 2131492865;
        public static int ic_launcher_foreground = 2131492866;
        public static int ic_launcher_round = 2131492867;

        private mipmap() {
        }
    }

    /* renamed from: cloud.udive.app.R$string */
    public static final class string {
        public static int app_name = 2131623964;
        public static int custom_url_scheme = 2131623991;
        public static int default_web_client_id = 2131623992;
        public static int firebase_database_url = 2131623997;
        public static int gcm_defaultSenderId = 2131623998;
        public static int google_api_key = 2131623999;
        public static int google_app_id = 2131624000;
        public static int google_crash_reporting_api_key = 2131624001;
        public static int google_storage_bucket = 2131624002;
        public static int package_name = 2131624004;
        public static int project_id = 2131624005;
        public static int title_activity_main = 2131624008;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_home_description = 2131623936;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_up_description = 2131623937;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_menu_overflow_description = 2131623938;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_mode_done = 2131623939;

        /* JADX INFO: Added by JADX */
        public static final int abc_activity_chooser_view_see_all = 2131623940;

        /* JADX INFO: Added by JADX */
        public static final int abc_activitychooserview_choose_application = 2131623941;

        /* JADX INFO: Added by JADX */
        public static final int abc_capital_off = 2131623942;

        /* JADX INFO: Added by JADX */
        public static final int abc_capital_on = 2131623943;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_alt_shortcut_label = 2131623944;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_ctrl_shortcut_label = 2131623945;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_delete_shortcut_label = 2131623946;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_enter_shortcut_label = 2131623947;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_function_shortcut_label = 2131623948;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_meta_shortcut_label = 2131623949;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_shift_shortcut_label = 2131623950;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_space_shortcut_label = 2131623951;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_sym_shortcut_label = 2131623952;

        /* JADX INFO: Added by JADX */
        public static final int abc_prepend_shortcut_label = 2131623953;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_hint = 2131623954;

        /* JADX INFO: Added by JADX */
        public static final int abc_searchview_description_clear = 2131623955;

        /* JADX INFO: Added by JADX */
        public static final int abc_searchview_description_query = 2131623956;

        /* JADX INFO: Added by JADX */
        public static final int abc_searchview_description_search = 2131623957;

        /* JADX INFO: Added by JADX */
        public static final int abc_searchview_description_submit = 2131623958;

        /* JADX INFO: Added by JADX */
        public static final int abc_searchview_description_voice = 2131623959;

        /* JADX INFO: Added by JADX */
        public static final int abc_shareactionprovider_share_with = 2131623960;

        /* JADX INFO: Added by JADX */
        public static final int abc_shareactionprovider_share_with_application = 2131623961;

        /* JADX INFO: Added by JADX */
        public static final int abc_toolbar_collapse_description = 2131623962;

        /* JADX INFO: Added by JADX */
        public static final int androidx_startup = 2131623963;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_answer_action = 2131623965;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_answer_video_action = 2131623966;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_decline_action = 2131623967;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_hang_up_action = 2131623968;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_incoming_text = 2131623969;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_ongoing_text = 2131623970;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_screening_text = 2131623971;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_enable_button = 2131623972;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_enable_text = 2131623973;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_enable_title = 2131623974;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_install_button = 2131623975;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_install_text = 2131623976;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_install_title = 2131623977;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_notification_channel_name = 2131623978;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_notification_ticker = 2131623979;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_unknown_issue = 2131623980;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_unsupported_text = 2131623981;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_update_button = 2131623982;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_update_text = 2131623983;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_update_title = 2131623984;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_updating_text = 2131623985;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_wear_update_text = 2131623986;

        /* JADX INFO: Added by JADX */
        public static final int common_open_on_phone = 2131623987;

        /* JADX INFO: Added by JADX */
        public static final int common_signin_button_text = 2131623988;

        /* JADX INFO: Added by JADX */
        public static final int common_signin_button_text_long = 2131623989;

        /* JADX INFO: Added by JADX */
        public static final int copy_toast_msg = 2131623990;

        /* JADX INFO: Added by JADX */
        public static final int fallback_menu_item_copy_link = 2131623993;

        /* JADX INFO: Added by JADX */
        public static final int fallback_menu_item_open_in_browser = 2131623994;

        /* JADX INFO: Added by JADX */
        public static final int fallback_menu_item_share_link = 2131623995;

        /* JADX INFO: Added by JADX */
        public static final int fcm_fallback_notification_channel_label = 2131623996;

        /* JADX INFO: Added by JADX */
        public static final int no_webview_text = 2131624003;

        /* JADX INFO: Added by JADX */
        public static final int search_menu_title = 2131624006;

        /* JADX INFO: Added by JADX */
        public static final int status_bar_notification_info_overflow = 2131624007;

        private string() {
        }
    }

    /* renamed from: cloud.udive.app.R$style */
    public static final class style {
        public static int AppTheme = 2131689477;
        public static int AppTheme_NoActionBar = 2131689478;
        public static int AppTheme_NoActionBarLaunch = 2131689479;

        /* JADX INFO: Added by JADX */
        public static final int AlertDialog_AppCompat = 2131689472;

        /* JADX INFO: Added by JADX */
        public static final int AlertDialog_AppCompat_Light = 2131689473;

        /* JADX INFO: Added by JADX */
        public static final int Animation_AppCompat_Dialog = 2131689474;

        /* JADX INFO: Added by JADX */
        public static final int Animation_AppCompat_DropDownUp = 2131689475;

        /* JADX INFO: Added by JADX */
        public static final int Animation_AppCompat_Tooltip = 2131689476;

        /* JADX INFO: Added by JADX */
        public static final int Base_AlertDialog_AppCompat = 2131689480;

        /* JADX INFO: Added by JADX */
        public static final int Base_AlertDialog_AppCompat_Light = 2131689481;

        /* JADX INFO: Added by JADX */
        public static final int Base_Animation_AppCompat_Dialog = 2131689482;

        /* JADX INFO: Added by JADX */
        public static final int Base_Animation_AppCompat_DropDownUp = 2131689483;

        /* JADX INFO: Added by JADX */
        public static final int Base_Animation_AppCompat_Tooltip = 2131689484;

        /* JADX INFO: Added by JADX */
        public static final int Base_DialogWindowTitle_AppCompat = 2131689485;

        /* JADX INFO: Added by JADX */
        public static final int Base_DialogWindowTitleBackground_AppCompat = 2131689486;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat = 2131689487;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Body1 = 2131689488;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Body2 = 2131689489;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Button = 2131689490;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Caption = 2131689491;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Display1 = 2131689492;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Display2 = 2131689493;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Display3 = 2131689494;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Display4 = 2131689495;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Headline = 2131689496;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Inverse = 2131689497;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Large = 2131689498;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Large_Inverse = 2131689499;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 2131689500;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 2131689501;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Medium = 2131689502;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Medium_Inverse = 2131689503;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Menu = 2131689504;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_SearchResult = 2131689505;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_SearchResult_Subtitle = 2131689506;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_SearchResult_Title = 2131689507;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Small = 2131689508;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Small_Inverse = 2131689509;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Subhead = 2131689510;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Subhead_Inverse = 2131689511;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Title = 2131689512;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Title_Inverse = 2131689513;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Tooltip = 2131689514;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Menu = 2131689515;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 2131689516;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 2131689517;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title = 2131689518;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 2131689519;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 2131689520;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Title = 2131689521;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_Button = 2131689522;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 2131689523;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_Button_Colored = 2131689524;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_Button_Inverse = 2131689525;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_DropDownItem = 2131689526;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Header = 2131689527;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Large = 2131689528;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Small = 2131689529;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_Switch = 2131689530;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 2131689531;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 2131689532;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 2131689533;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Title = 2131689534;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat = 2131689535;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_CompactMenu = 2131689536;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Dialog = 2131689537;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Dialog_Alert = 2131689538;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Dialog_FixedSize = 2131689539;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Dialog_MinWidth = 2131689540;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_DialogWhenLarge = 2131689541;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Light = 2131689542;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Light_DarkActionBar = 2131689543;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Light_Dialog = 2131689544;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Light_Dialog_Alert = 2131689545;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Light_Dialog_FixedSize = 2131689546;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Light_Dialog_MinWidth = 2131689547;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Light_DialogWhenLarge = 2131689548;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_SplashScreen = 2131689549;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_SplashScreen_DayNight = 2131689550;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_SplashScreen_Light = 2131689551;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_AppCompat = 2131689552;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_ActionBar = 2131689553;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_Dark = 2131689554;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_Dark_ActionBar = 2131689555;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_Dialog = 2131689556;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_Dialog_Alert = 2131689557;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_Light = 2131689558;

        /* JADX INFO: Added by JADX */
        public static final int Base_V21_Theme_AppCompat = 2131689559;

        /* JADX INFO: Added by JADX */
        public static final int Base_V21_Theme_AppCompat_Dialog = 2131689560;

        /* JADX INFO: Added by JADX */
        public static final int Base_V21_Theme_AppCompat_Light = 2131689561;

        /* JADX INFO: Added by JADX */
        public static final int Base_V21_Theme_AppCompat_Light_Dialog = 2131689562;

        /* JADX INFO: Added by JADX */
        public static final int Base_V21_ThemeOverlay_AppCompat_Dialog = 2131689563;

        /* JADX INFO: Added by JADX */
        public static final int Base_V22_Theme_AppCompat = 2131689564;

        /* JADX INFO: Added by JADX */
        public static final int Base_V22_Theme_AppCompat_Light = 2131689565;

        /* JADX INFO: Added by JADX */
        public static final int Base_V23_Theme_AppCompat = 2131689566;

        /* JADX INFO: Added by JADX */
        public static final int Base_V23_Theme_AppCompat_Light = 2131689567;

        /* JADX INFO: Added by JADX */
        public static final int Base_V26_Theme_AppCompat = 2131689568;

        /* JADX INFO: Added by JADX */
        public static final int Base_V26_Theme_AppCompat_Light = 2131689569;

        /* JADX INFO: Added by JADX */
        public static final int Base_V26_Widget_AppCompat_Toolbar = 2131689570;

        /* JADX INFO: Added by JADX */
        public static final int Base_V28_Theme_AppCompat = 2131689571;

        /* JADX INFO: Added by JADX */
        public static final int Base_V28_Theme_AppCompat_Light = 2131689572;

        /* JADX INFO: Added by JADX */
        public static final int Base_V7_Theme_AppCompat = 2131689573;

        /* JADX INFO: Added by JADX */
        public static final int Base_V7_Theme_AppCompat_Dialog = 2131689574;

        /* JADX INFO: Added by JADX */
        public static final int Base_V7_Theme_AppCompat_Light = 2131689575;

        /* JADX INFO: Added by JADX */
        public static final int Base_V7_Theme_AppCompat_Light_Dialog = 2131689576;

        /* JADX INFO: Added by JADX */
        public static final int Base_V7_ThemeOverlay_AppCompat_Dialog = 2131689577;

        /* JADX INFO: Added by JADX */
        public static final int Base_V7_Widget_AppCompat_AutoCompleteTextView = 2131689578;

        /* JADX INFO: Added by JADX */
        public static final int Base_V7_Widget_AppCompat_EditText = 2131689579;

        /* JADX INFO: Added by JADX */
        public static final int Base_V7_Widget_AppCompat_Toolbar = 2131689580;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionBar = 2131689581;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionBar_Solid = 2131689582;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionBar_TabBar = 2131689583;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionBar_TabText = 2131689584;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionBar_TabView = 2131689585;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionButton = 2131689586;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionButton_CloseMode = 2131689587;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionButton_Overflow = 2131689588;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionMode = 2131689589;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActivityChooserView = 2131689590;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_AutoCompleteTextView = 2131689591;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Button = 2131689592;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Button_Borderless = 2131689593;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Button_Borderless_Colored = 2131689594;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Button_ButtonBar_AlertDialog = 2131689595;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Button_Colored = 2131689596;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Button_Small = 2131689597;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ButtonBar = 2131689598;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ButtonBar_AlertDialog = 2131689599;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_CompoundButton_CheckBox = 2131689600;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_CompoundButton_RadioButton = 2131689601;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_CompoundButton_Switch = 2131689602;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_DrawerArrowToggle = 2131689603;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_DrawerArrowToggle_Common = 2131689604;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_DropDownItem_Spinner = 2131689605;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_EditText = 2131689606;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ImageButton = 2131689607;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar = 2131689608;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar_Solid = 2131689609;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabBar = 2131689610;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabText = 2131689611;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabText_Inverse = 2131689612;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabView = 2131689613;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Light_PopupMenu = 2131689614;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Light_PopupMenu_Overflow = 2131689615;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ListMenuView = 2131689616;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ListPopupWindow = 2131689617;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ListView = 2131689618;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ListView_DropDown = 2131689619;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ListView_Menu = 2131689620;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_PopupMenu = 2131689621;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_PopupMenu_Overflow = 2131689622;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_PopupWindow = 2131689623;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ProgressBar = 2131689624;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ProgressBar_Horizontal = 2131689625;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_RatingBar = 2131689626;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_RatingBar_Indicator = 2131689627;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_RatingBar_Small = 2131689628;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_SearchView = 2131689629;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_SearchView_ActionBar = 2131689630;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_SeekBar = 2131689631;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_SeekBar_Discrete = 2131689632;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Spinner = 2131689633;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Spinner_Underlined = 2131689634;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_TextView = 2131689635;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_TextView_SpinnerItem = 2131689636;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Toolbar = 2131689637;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Toolbar_Button_Navigation = 2131689638;

        /* JADX INFO: Added by JADX */
        public static final int Base_v21_Theme_SplashScreen = 2131689639;

        /* JADX INFO: Added by JADX */
        public static final int Base_v21_Theme_SplashScreen_Light = 2131689640;

        /* JADX INFO: Added by JADX */
        public static final int Base_v27_Theme_SplashScreen = 2131689641;

        /* JADX INFO: Added by JADX */
        public static final int Base_v27_Theme_SplashScreen_Light = 2131689642;

        /* JADX INFO: Added by JADX */
        public static final int Platform_AppCompat = 2131689643;

        /* JADX INFO: Added by JADX */
        public static final int Platform_AppCompat_Light = 2131689644;

        /* JADX INFO: Added by JADX */
        public static final int Platform_ThemeOverlay_AppCompat = 2131689645;

        /* JADX INFO: Added by JADX */
        public static final int Platform_ThemeOverlay_AppCompat_Dark = 2131689646;

        /* JADX INFO: Added by JADX */
        public static final int Platform_ThemeOverlay_AppCompat_Light = 2131689647;

        /* JADX INFO: Added by JADX */
        public static final int Platform_V21_AppCompat = 2131689648;

        /* JADX INFO: Added by JADX */
        public static final int Platform_V21_AppCompat_Light = 2131689649;

        /* JADX INFO: Added by JADX */
        public static final int Platform_V25_AppCompat = 2131689650;

        /* JADX INFO: Added by JADX */
        public static final int Platform_V25_AppCompat_Light = 2131689651;

        /* JADX INFO: Added by JADX */
        public static final int Platform_Widget_AppCompat_Spinner = 2131689652;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_DialogWindowTitle_AppCompat = 2131689653;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_ActionBar_TitleItem = 2131689654;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_DialogTitle_Icon = 2131689655;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem = 2131689656;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_InternalGroup = 2131689657;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Shortcut = 2131689658;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_SubmenuArrow = 2131689659;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Text = 2131689660;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Title = 2131689661;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown = 2131689662;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon1 = 2131689663;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon2 = 2131689664;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Query = 2131689665;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Text = 2131689666;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_SearchView_MagIcon = 2131689667;

        /* JADX INFO: Added by JADX */
        public static final int RtlUnderlay_Widget_AppCompat_ActionButton = 2131689668;

        /* JADX INFO: Added by JADX */
        public static final int RtlUnderlay_Widget_AppCompat_ActionButton_Overflow = 2131689669;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat = 2131689670;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Body1 = 2131689671;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Body2 = 2131689672;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Button = 2131689673;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Caption = 2131689674;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Display1 = 2131689675;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Display2 = 2131689676;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Display3 = 2131689677;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Display4 = 2131689678;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Headline = 2131689679;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Inverse = 2131689680;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Large = 2131689681;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Large_Inverse = 2131689682;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Light_SearchResult_Subtitle = 2131689683;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Light_SearchResult_Title = 2131689684;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 2131689685;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 2131689686;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Medium = 2131689687;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Medium_Inverse = 2131689688;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Menu = 2131689689;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_SearchResult_Subtitle = 2131689690;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_SearchResult_Title = 2131689691;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Small = 2131689692;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Small_Inverse = 2131689693;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Subhead = 2131689694;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Subhead_Inverse = 2131689695;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Title = 2131689696;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Title_Inverse = 2131689697;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Tooltip = 2131689698;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Menu = 2131689699;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 2131689700;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 2131689701;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Title = 2131689702;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 2131689703;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 2131689704;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle_Inverse = 2131689705;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Title = 2131689706;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Title_Inverse = 2131689707;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_Button = 2131689708;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 2131689709;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_Button_Colored = 2131689710;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_Button_Inverse = 2131689711;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_DropDownItem = 2131689712;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_PopupMenu_Header = 2131689713;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_PopupMenu_Large = 2131689714;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_PopupMenu_Small = 2131689715;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_Switch = 2131689716;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 2131689717;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification = 2131689718;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification_Info = 2131689719;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification_Line2 = 2131689720;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification_Time = 2131689721;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification_Title = 2131689722;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 2131689723;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 2131689724;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Widget_AppCompat_Toolbar_Title = 2131689725;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat = 2131689726;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_CompactMenu = 2131689727;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DayNight = 2131689728;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DayNight_DarkActionBar = 2131689729;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DayNight_Dialog = 2131689730;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DayNight_Dialog_Alert = 2131689731;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DayNight_Dialog_MinWidth = 2131689732;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DayNight_DialogWhenLarge = 2131689733;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DayNight_NoActionBar = 2131689734;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Dialog = 2131689735;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Dialog_Alert = 2131689736;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Dialog_MinWidth = 2131689737;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DialogWhenLarge = 2131689738;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Empty = 2131689739;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Light = 2131689740;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Light_DarkActionBar = 2131689741;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Light_Dialog = 2131689742;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Light_Dialog_Alert = 2131689743;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Light_Dialog_MinWidth = 2131689744;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Light_DialogWhenLarge = 2131689745;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Light_NoActionBar = 2131689746;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_NoActionBar = 2131689747;

        /* JADX INFO: Added by JADX */
        public static final int Theme_SplashScreen = 2131689748;

        /* JADX INFO: Added by JADX */
        public static final int Theme_SplashScreen_Common = 2131689749;

        /* JADX INFO: Added by JADX */
        public static final int Theme_SplashScreen_IconBackground = 2131689750;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat = 2131689751;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat_ActionBar = 2131689752;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat_Dark = 2131689753;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat_Dark_ActionBar = 2131689754;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat_DayNight = 2131689755;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat_DayNight_ActionBar = 2131689756;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat_Dialog = 2131689757;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat_Dialog_Alert = 2131689758;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat_Light = 2131689759;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionBar = 2131689760;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionBar_Solid = 2131689761;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionBar_TabBar = 2131689762;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionBar_TabText = 2131689763;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionBar_TabView = 2131689764;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionButton = 2131689765;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionButton_CloseMode = 2131689766;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionButton_Overflow = 2131689767;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionMode = 2131689768;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActivityChooserView = 2131689769;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_AutoCompleteTextView = 2131689770;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Button = 2131689771;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Button_Borderless = 2131689772;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Button_Borderless_Colored = 2131689773;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Button_ButtonBar_AlertDialog = 2131689774;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Button_Colored = 2131689775;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Button_Small = 2131689776;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ButtonBar = 2131689777;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ButtonBar_AlertDialog = 2131689778;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_CompoundButton_CheckBox = 2131689779;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_CompoundButton_RadioButton = 2131689780;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_CompoundButton_Switch = 2131689781;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_DrawerArrowToggle = 2131689782;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_DropDownItem_Spinner = 2131689783;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_EditText = 2131689784;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ImageButton = 2131689785;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar = 2131689786;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_Solid = 2131689787;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_Solid_Inverse = 2131689788;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_TabBar = 2131689789;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_TabBar_Inverse = 2131689790;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_TabText = 2131689791;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_TabText_Inverse = 2131689792;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_TabView = 2131689793;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_TabView_Inverse = 2131689794;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionButton = 2131689795;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionButton_CloseMode = 2131689796;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionButton_Overflow = 2131689797;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionMode_Inverse = 2131689798;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActivityChooserView = 2131689799;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_AutoCompleteTextView = 2131689800;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_DropDownItem_Spinner = 2131689801;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ListPopupWindow = 2131689802;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ListView_DropDown = 2131689803;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_PopupMenu = 2131689804;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_PopupMenu_Overflow = 2131689805;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_SearchView = 2131689806;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_Spinner_DropDown_ActionBar = 2131689807;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ListMenuView = 2131689808;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ListPopupWindow = 2131689809;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ListView = 2131689810;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ListView_DropDown = 2131689811;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ListView_Menu = 2131689812;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_PopupMenu = 2131689813;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_PopupMenu_Overflow = 2131689814;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_PopupWindow = 2131689815;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ProgressBar = 2131689816;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ProgressBar_Horizontal = 2131689817;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_RatingBar = 2131689818;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_RatingBar_Indicator = 2131689819;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_RatingBar_Small = 2131689820;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_SearchView = 2131689821;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_SearchView_ActionBar = 2131689822;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_SeekBar = 2131689823;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_SeekBar_Discrete = 2131689824;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Spinner = 2131689825;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Spinner_DropDown = 2131689826;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Spinner_DropDown_ActionBar = 2131689827;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Spinner_Underlined = 2131689828;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_TextView = 2131689829;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_TextView_SpinnerItem = 2131689830;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Toolbar = 2131689831;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Toolbar_Button_Navigation = 2131689832;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Compat_NotificationActionContainer = 2131689833;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Compat_NotificationActionText = 2131689834;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Support_CoordinatorLayout = 2131689835;

        /* JADX INFO: Added by JADX */
        public static final int capacitor_default_style = 2131689836;

        /* JADX INFO: Added by JADX */
        public static final int capacitor_full_screen_style = 2131689837;

        /* JADX INFO: Added by JADX */
        public static final int capacitor_immersive_style = 2131689838;

        private style() {
        }
    }

    /* renamed from: cloud.udive.app.R$xml */
    public static final class xml {
        public static int config = 2131820544;
        public static int file_paths = 2131820545;

        /* JADX INFO: Added by JADX */
        public static final int image_share_filepaths = 2131820546;

        /* JADX INFO: Added by JADX */
        public static final int splits0 = 2131820547;

        private xml() {
        }
    }

    /* JADX INFO: Added by JADX */
    /* renamed from: cloud.udive.app.R$anim */
    public static final class anim {

        /* JADX INFO: Added by JADX */
        public static final int abc_fade_in = 2130771968;

        /* JADX INFO: Added by JADX */
        public static final int abc_fade_out = 2130771969;

        /* JADX INFO: Added by JADX */
        public static final int abc_grow_fade_in_from_bottom = 2130771970;

        /* JADX INFO: Added by JADX */
        public static final int abc_popup_enter = 2130771971;

        /* JADX INFO: Added by JADX */
        public static final int abc_popup_exit = 2130771972;

        /* JADX INFO: Added by JADX */
        public static final int abc_shrink_fade_out_from_bottom = 2130771973;

        /* JADX INFO: Added by JADX */
        public static final int abc_slide_in_bottom = 2130771974;

        /* JADX INFO: Added by JADX */
        public static final int abc_slide_in_top = 2130771975;

        /* JADX INFO: Added by JADX */
        public static final int abc_slide_out_bottom = 2130771976;

        /* JADX INFO: Added by JADX */
        public static final int abc_slide_out_top = 2130771977;

        /* JADX INFO: Added by JADX */
        public static final int abc_tooltip_enter = 2130771978;

        /* JADX INFO: Added by JADX */
        public static final int abc_tooltip_exit = 2130771979;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_to_checked_box_inner_merged_animation = 2130771980;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_to_checked_box_outer_merged_animation = 2130771981;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_to_checked_icon_null_animation = 2130771982;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_to_unchecked_box_inner_merged_animation = 2130771983;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_to_unchecked_check_path_merged_animation = 2130771984;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_to_unchecked_icon_null_animation = 2130771985;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_off_mtrl_dot_group_animation = 2130771986;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_off_mtrl_ring_outer_animation = 2130771987;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_off_mtrl_ring_outer_path_animation = 2130771988;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_on_mtrl_dot_group_animation = 2130771989;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_on_mtrl_ring_outer_animation = 2130771990;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_on_mtrl_ring_outer_path_animation = 2130771991;

        /* JADX INFO: Added by JADX */
        public static final int fragment_fast_out_extra_slow_in = 2130771992;
    }

    /* JADX INFO: Added by JADX */
    /* renamed from: cloud.udive.app.R$animator */
    public static final class animator {

        /* JADX INFO: Added by JADX */
        public static final int fragment_close_enter = 2130837504;

        /* JADX INFO: Added by JADX */
        public static final int fragment_close_exit = 2130837505;

        /* JADX INFO: Added by JADX */
        public static final int fragment_fade_enter = 2130837506;

        /* JADX INFO: Added by JADX */
        public static final int fragment_fade_exit = 2130837507;

        /* JADX INFO: Added by JADX */
        public static final int fragment_open_enter = 2130837508;

        /* JADX INFO: Added by JADX */
        public static final int fragment_open_exit = 2130837509;
    }

    /* JADX INFO: Added by JADX */
    /* renamed from: cloud.udive.app.R$attr */
    public static final class attr {

        /* JADX INFO: Added by JADX */
        public static final int actionBarDivider = 2130903040;

        /* JADX INFO: Added by JADX */
        public static final int actionBarItemBackground = 2130903041;

        /* JADX INFO: Added by JADX */
        public static final int actionBarPopupTheme = 2130903042;

        /* JADX INFO: Added by JADX */
        public static final int actionBarSize = 2130903043;

        /* JADX INFO: Added by JADX */
        public static final int actionBarSplitStyle = 2130903044;

        /* JADX INFO: Added by JADX */
        public static final int actionBarStyle = 2130903045;

        /* JADX INFO: Added by JADX */
        public static final int actionBarTabBarStyle = 2130903046;

        /* JADX INFO: Added by JADX */
        public static final int actionBarTabStyle = 2130903047;

        /* JADX INFO: Added by JADX */
        public static final int actionBarTabTextStyle = 2130903048;

        /* JADX INFO: Added by JADX */
        public static final int actionBarTheme = 2130903049;

        /* JADX INFO: Added by JADX */
        public static final int actionBarWidgetTheme = 2130903050;

        /* JADX INFO: Added by JADX */
        public static final int actionButtonStyle = 2130903051;

        /* JADX INFO: Added by JADX */
        public static final int actionDropDownStyle = 2130903052;

        /* JADX INFO: Added by JADX */
        public static final int actionLayout = 2130903053;

        /* JADX INFO: Added by JADX */
        public static final int actionMenuTextAppearance = 2130903054;

        /* JADX INFO: Added by JADX */
        public static final int actionMenuTextColor = 2130903055;

        /* JADX INFO: Added by JADX */
        public static final int actionModeBackground = 2130903056;

        /* JADX INFO: Added by JADX */
        public static final int actionModeCloseButtonStyle = 2130903057;

        /* JADX INFO: Added by JADX */
        public static final int actionModeCloseContentDescription = 2130903058;

        /* JADX INFO: Added by JADX */
        public static final int actionModeCloseDrawable = 2130903059;

        /* JADX INFO: Added by JADX */
        public static final int actionModeCopyDrawable = 2130903060;

        /* JADX INFO: Added by JADX */
        public static final int actionModeCutDrawable = 2130903061;

        /* JADX INFO: Added by JADX */
        public static final int actionModeFindDrawable = 2130903062;

        /* JADX INFO: Added by JADX */
        public static final int actionModePasteDrawable = 2130903063;

        /* JADX INFO: Added by JADX */
        public static final int actionModePopupWindowStyle = 2130903064;

        /* JADX INFO: Added by JADX */
        public static final int actionModeSelectAllDrawable = 2130903065;

        /* JADX INFO: Added by JADX */
        public static final int actionModeShareDrawable = 2130903066;

        /* JADX INFO: Added by JADX */
        public static final int actionModeSplitBackground = 2130903067;

        /* JADX INFO: Added by JADX */
        public static final int actionModeStyle = 2130903068;

        /* JADX INFO: Added by JADX */
        public static final int actionModeTheme = 2130903069;

        /* JADX INFO: Added by JADX */
        public static final int actionModeWebSearchDrawable = 2130903070;

        /* JADX INFO: Added by JADX */
        public static final int actionOverflowButtonStyle = 2130903071;

        /* JADX INFO: Added by JADX */
        public static final int actionOverflowMenuStyle = 2130903072;

        /* JADX INFO: Added by JADX */
        public static final int actionProviderClass = 2130903073;

        /* JADX INFO: Added by JADX */
        public static final int actionViewClass = 2130903074;

        /* JADX INFO: Added by JADX */
        public static final int activityChooserViewStyle = 2130903075;

        /* JADX INFO: Added by JADX */
        public static final int alertDialogButtonGroupStyle = 2130903076;

        /* JADX INFO: Added by JADX */
        public static final int alertDialogCenterButtons = 2130903077;

        /* JADX INFO: Added by JADX */
        public static final int alertDialogStyle = 2130903078;

        /* JADX INFO: Added by JADX */
        public static final int alertDialogTheme = 2130903079;

        /* JADX INFO: Added by JADX */
        public static final int allowStacking = 2130903080;

        /* JADX INFO: Added by JADX */
        public static final int alpha = 2130903081;

        /* JADX INFO: Added by JADX */
        public static final int alphabeticModifiers = 2130903082;

        /* JADX INFO: Added by JADX */
        public static final int arrowHeadLength = 2130903083;

        /* JADX INFO: Added by JADX */
        public static final int arrowShaftLength = 2130903084;

        /* JADX INFO: Added by JADX */
        public static final int autoCompleteTextViewStyle = 2130903085;

        /* JADX INFO: Added by JADX */
        public static final int autoSizeMaxTextSize = 2130903086;

        /* JADX INFO: Added by JADX */
        public static final int autoSizeMinTextSize = 2130903087;

        /* JADX INFO: Added by JADX */
        public static final int autoSizePresetSizes = 2130903088;

        /* JADX INFO: Added by JADX */
        public static final int autoSizeStepGranularity = 2130903089;

        /* JADX INFO: Added by JADX */
        public static final int autoSizeTextType = 2130903090;

        /* JADX INFO: Added by JADX */
        public static final int background = 2130903091;

        /* JADX INFO: Added by JADX */
        public static final int backgroundSplit = 2130903092;

        /* JADX INFO: Added by JADX */
        public static final int backgroundStacked = 2130903093;

        /* JADX INFO: Added by JADX */
        public static final int backgroundTint = 2130903094;

        /* JADX INFO: Added by JADX */
        public static final int backgroundTintMode = 2130903095;

        /* JADX INFO: Added by JADX */
        public static final int barLength = 2130903096;

        /* JADX INFO: Added by JADX */
        public static final int borderlessButtonStyle = 2130903097;

        /* JADX INFO: Added by JADX */
        public static final int buttonBarButtonStyle = 2130903098;

        /* JADX INFO: Added by JADX */
        public static final int buttonBarNegativeButtonStyle = 2130903099;

        /* JADX INFO: Added by JADX */
        public static final int buttonBarNeutralButtonStyle = 2130903100;

        /* JADX INFO: Added by JADX */
        public static final int buttonBarPositiveButtonStyle = 2130903101;

        /* JADX INFO: Added by JADX */
        public static final int buttonBarStyle = 2130903102;

        /* JADX INFO: Added by JADX */
        public static final int buttonCompat = 2130903103;

        /* JADX INFO: Added by JADX */
        public static final int buttonGravity = 2130903104;

        /* JADX INFO: Added by JADX */
        public static final int buttonIconDimen = 2130903105;

        /* JADX INFO: Added by JADX */
        public static final int buttonPanelSideLayout = 2130903106;

        /* JADX INFO: Added by JADX */
        public static final int buttonSize = 2130903107;

        /* JADX INFO: Added by JADX */
        public static final int buttonStyle = 2130903108;

        /* JADX INFO: Added by JADX */
        public static final int buttonStyleSmall = 2130903109;

        /* JADX INFO: Added by JADX */
        public static final int buttonTint = 2130903110;

        /* JADX INFO: Added by JADX */
        public static final int buttonTintMode = 2130903111;

        /* JADX INFO: Added by JADX */
        public static final int checkMarkCompat = 2130903112;

        /* JADX INFO: Added by JADX */
        public static final int checkMarkTint = 2130903113;

        /* JADX INFO: Added by JADX */
        public static final int checkMarkTintMode = 2130903114;

        /* JADX INFO: Added by JADX */
        public static final int checkboxStyle = 2130903115;

        /* JADX INFO: Added by JADX */
        public static final int checkedTextViewStyle = 2130903116;

        /* JADX INFO: Added by JADX */
        public static final int circleCrop = 2130903117;

        /* JADX INFO: Added by JADX */
        public static final int closeIcon = 2130903118;

        /* JADX INFO: Added by JADX */
        public static final int closeItemLayout = 2130903119;

        /* JADX INFO: Added by JADX */
        public static final int collapseContentDescription = 2130903120;

        /* JADX INFO: Added by JADX */
        public static final int collapseIcon = 2130903121;

        /* JADX INFO: Added by JADX */
        public static final int color = 2130903122;

        /* JADX INFO: Added by JADX */
        public static final int colorAccent = 2130903123;

        /* JADX INFO: Added by JADX */
        public static final int colorBackgroundFloating = 2130903124;

        /* JADX INFO: Added by JADX */
        public static final int colorButtonNormal = 2130903125;

        /* JADX INFO: Added by JADX */
        public static final int colorControlActivated = 2130903126;

        /* JADX INFO: Added by JADX */
        public static final int colorControlHighlight = 2130903127;

        /* JADX INFO: Added by JADX */
        public static final int colorControlNormal = 2130903128;

        /* JADX INFO: Added by JADX */
        public static final int colorError = 2130903129;

        /* JADX INFO: Added by JADX */
        public static final int colorPrimary = 2130903130;

        /* JADX INFO: Added by JADX */
        public static final int colorPrimaryDark = 2130903131;

        /* JADX INFO: Added by JADX */
        public static final int colorScheme = 2130903132;

        /* JADX INFO: Added by JADX */
        public static final int colorSwitchThumbNormal = 2130903133;

        /* JADX INFO: Added by JADX */
        public static final int commitIcon = 2130903134;

        /* JADX INFO: Added by JADX */
        public static final int contentDescription = 2130903135;

        /* JADX INFO: Added by JADX */
        public static final int contentInsetEnd = 2130903136;

        /* JADX INFO: Added by JADX */
        public static final int contentInsetEndWithActions = 2130903137;

        /* JADX INFO: Added by JADX */
        public static final int contentInsetLeft = 2130903138;

        /* JADX INFO: Added by JADX */
        public static final int contentInsetRight = 2130903139;

        /* JADX INFO: Added by JADX */
        public static final int contentInsetStart = 2130903140;

        /* JADX INFO: Added by JADX */
        public static final int contentInsetStartWithNavigation = 2130903141;

        /* JADX INFO: Added by JADX */
        public static final int controlBackground = 2130903142;

        /* JADX INFO: Added by JADX */
        public static final int coordinatorLayoutStyle = 2130903143;

        /* JADX INFO: Added by JADX */
        public static final int customNavigationLayout = 2130903144;

        /* JADX INFO: Added by JADX */
        public static final int defaultQueryHint = 2130903145;

        /* JADX INFO: Added by JADX */
        public static final int dialogCornerRadius = 2130903146;

        /* JADX INFO: Added by JADX */
        public static final int dialogPreferredPadding = 2130903147;

        /* JADX INFO: Added by JADX */
        public static final int dialogTheme = 2130903148;

        /* JADX INFO: Added by JADX */
        public static final int displayOptions = 2130903149;

        /* JADX INFO: Added by JADX */
        public static final int divider = 2130903150;

        /* JADX INFO: Added by JADX */
        public static final int dividerHorizontal = 2130903151;

        /* JADX INFO: Added by JADX */
        public static final int dividerPadding = 2130903152;

        /* JADX INFO: Added by JADX */
        public static final int dividerVertical = 2130903153;

        /* JADX INFO: Added by JADX */
        public static final int drawableBottomCompat = 2130903154;

        /* JADX INFO: Added by JADX */
        public static final int drawableEndCompat = 2130903155;

        /* JADX INFO: Added by JADX */
        public static final int drawableLeftCompat = 2130903156;

        /* JADX INFO: Added by JADX */
        public static final int drawableRightCompat = 2130903157;

        /* JADX INFO: Added by JADX */
        public static final int drawableSize = 2130903158;

        /* JADX INFO: Added by JADX */
        public static final int drawableStartCompat = 2130903159;

        /* JADX INFO: Added by JADX */
        public static final int drawableTint = 2130903160;

        /* JADX INFO: Added by JADX */
        public static final int drawableTintMode = 2130903161;

        /* JADX INFO: Added by JADX */
        public static final int drawableTopCompat = 2130903162;

        /* JADX INFO: Added by JADX */
        public static final int drawerArrowStyle = 2130903163;

        /* JADX INFO: Added by JADX */
        public static final int dropDownListViewStyle = 2130903164;

        /* JADX INFO: Added by JADX */
        public static final int dropdownListPreferredItemHeight = 2130903165;

        /* JADX INFO: Added by JADX */
        public static final int editTextBackground = 2130903166;

        /* JADX INFO: Added by JADX */
        public static final int editTextColor = 2130903167;

        /* JADX INFO: Added by JADX */
        public static final int editTextStyle = 2130903168;

        /* JADX INFO: Added by JADX */
        public static final int elevation = 2130903169;

        /* JADX INFO: Added by JADX */
        public static final int emojiCompatEnabled = 2130903170;

        /* JADX INFO: Added by JADX */
        public static final int expandActivityOverflowButtonDrawable = 2130903171;

        /* JADX INFO: Added by JADX */
        public static final int firstBaselineToTopHeight = 2130903172;

        /* JADX INFO: Added by JADX */
        public static final int font = 2130903173;

        /* JADX INFO: Added by JADX */
        public static final int fontFamily = 2130903174;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderAuthority = 2130903175;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderCerts = 2130903176;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderFetchStrategy = 2130903177;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderFetchTimeout = 2130903178;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderPackage = 2130903179;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderQuery = 2130903180;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderSystemFontFamily = 2130903181;

        /* JADX INFO: Added by JADX */
        public static final int fontStyle = 2130903182;

        /* JADX INFO: Added by JADX */
        public static final int fontVariationSettings = 2130903183;

        /* JADX INFO: Added by JADX */
        public static final int fontWeight = 2130903184;

        /* JADX INFO: Added by JADX */
        public static final int gapBetweenBars = 2130903185;

        /* JADX INFO: Added by JADX */
        public static final int goIcon = 2130903186;

        /* JADX INFO: Added by JADX */
        public static final int height = 2130903187;

        /* JADX INFO: Added by JADX */
        public static final int hideOnContentScroll = 2130903188;

        /* JADX INFO: Added by JADX */
        public static final int homeAsUpIndicator = 2130903189;

        /* JADX INFO: Added by JADX */
        public static final int homeLayout = 2130903190;

        /* JADX INFO: Added by JADX */
        public static final int icon = 2130903191;

        /* JADX INFO: Added by JADX */
        public static final int iconTint = 2130903192;

        /* JADX INFO: Added by JADX */
        public static final int iconTintMode = 2130903193;

        /* JADX INFO: Added by JADX */
        public static final int iconifiedByDefault = 2130903194;

        /* JADX INFO: Added by JADX */
        public static final int imageAspectRatio = 2130903195;

        /* JADX INFO: Added by JADX */
        public static final int imageAspectRatioAdjust = 2130903196;

        /* JADX INFO: Added by JADX */
        public static final int imageButtonStyle = 2130903197;

        /* JADX INFO: Added by JADX */
        public static final int indeterminateProgressStyle = 2130903198;

        /* JADX INFO: Added by JADX */
        public static final int initialActivityCount = 2130903199;

        /* JADX INFO: Added by JADX */
        public static final int isLightTheme = 2130903200;

        /* JADX INFO: Added by JADX */
        public static final int itemPadding = 2130903201;

        /* JADX INFO: Added by JADX */
        public static final int keylines = 2130903202;

        /* JADX INFO: Added by JADX */
        public static final int lStar = 2130903203;

        /* JADX INFO: Added by JADX */
        public static final int lastBaselineToBottomHeight = 2130903204;

        /* JADX INFO: Added by JADX */
        public static final int layout = 2130903205;

        /* JADX INFO: Added by JADX */
        public static final int layout_anchor = 2130903206;

        /* JADX INFO: Added by JADX */
        public static final int layout_anchorGravity = 2130903207;

        /* JADX INFO: Added by JADX */
        public static final int layout_behavior = 2130903208;

        /* JADX INFO: Added by JADX */
        public static final int layout_dodgeInsetEdges = 2130903209;

        /* JADX INFO: Added by JADX */
        public static final int layout_insetEdge = 2130903210;

        /* JADX INFO: Added by JADX */
        public static final int layout_keyline = 2130903211;

        /* JADX INFO: Added by JADX */
        public static final int lineHeight = 2130903212;

        /* JADX INFO: Added by JADX */
        public static final int listChoiceBackgroundIndicator = 2130903213;

        /* JADX INFO: Added by JADX */
        public static final int listChoiceIndicatorMultipleAnimated = 2130903214;

        /* JADX INFO: Added by JADX */
        public static final int listChoiceIndicatorSingleAnimated = 2130903215;

        /* JADX INFO: Added by JADX */
        public static final int listDividerAlertDialog = 2130903216;

        /* JADX INFO: Added by JADX */
        public static final int listItemLayout = 2130903217;

        /* JADX INFO: Added by JADX */
        public static final int listLayout = 2130903218;

        /* JADX INFO: Added by JADX */
        public static final int listMenuViewStyle = 2130903219;

        /* JADX INFO: Added by JADX */
        public static final int listPopupWindowStyle = 2130903220;

        /* JADX INFO: Added by JADX */
        public static final int listPreferredItemHeight = 2130903221;

        /* JADX INFO: Added by JADX */
        public static final int listPreferredItemHeightLarge = 2130903222;

        /* JADX INFO: Added by JADX */
        public static final int listPreferredItemHeightSmall = 2130903223;

        /* JADX INFO: Added by JADX */
        public static final int listPreferredItemPaddingEnd = 2130903224;

        /* JADX INFO: Added by JADX */
        public static final int listPreferredItemPaddingLeft = 2130903225;

        /* JADX INFO: Added by JADX */
        public static final int listPreferredItemPaddingRight = 2130903226;

        /* JADX INFO: Added by JADX */
        public static final int listPreferredItemPaddingStart = 2130903227;

        /* JADX INFO: Added by JADX */
        public static final int logo = 2130903228;

        /* JADX INFO: Added by JADX */
        public static final int logoDescription = 2130903229;

        /* JADX INFO: Added by JADX */
        public static final int maxButtonHeight = 2130903230;

        /* JADX INFO: Added by JADX */
        public static final int measureWithLargestChild = 2130903231;

        /* JADX INFO: Added by JADX */
        public static final int menu = 2130903232;

        /* JADX INFO: Added by JADX */
        public static final int multiChoiceItemLayout = 2130903233;

        /* JADX INFO: Added by JADX */
        public static final int navigationContentDescription = 2130903234;

        /* JADX INFO: Added by JADX */
        public static final int navigationIcon = 2130903235;

        /* JADX INFO: Added by JADX */
        public static final int navigationMode = 2130903236;

        /* JADX INFO: Added by JADX */
        public static final int nestedScrollViewStyle = 2130903237;

        /* JADX INFO: Added by JADX */
        public static final int numericModifiers = 2130903238;

        /* JADX INFO: Added by JADX */
        public static final int overlapAnchor = 2130903239;

        /* JADX INFO: Added by JADX */
        public static final int paddingBottomNoButtons = 2130903240;

        /* JADX INFO: Added by JADX */
        public static final int paddingEnd = 2130903241;

        /* JADX INFO: Added by JADX */
        public static final int paddingStart = 2130903242;

        /* JADX INFO: Added by JADX */
        public static final int paddingTopNoTitle = 2130903243;

        /* JADX INFO: Added by JADX */
        public static final int panelBackground = 2130903244;

        /* JADX INFO: Added by JADX */
        public static final int panelMenuListTheme = 2130903245;

        /* JADX INFO: Added by JADX */
        public static final int panelMenuListWidth = 2130903246;

        /* JADX INFO: Added by JADX */
        public static final int popupMenuStyle = 2130903247;

        /* JADX INFO: Added by JADX */
        public static final int popupTheme = 2130903248;

        /* JADX INFO: Added by JADX */
        public static final int popupWindowStyle = 2130903249;

        /* JADX INFO: Added by JADX */
        public static final int postSplashScreenTheme = 2130903250;

        /* JADX INFO: Added by JADX */
        public static final int preserveIconSpacing = 2130903251;

        /* JADX INFO: Added by JADX */
        public static final int progressBarPadding = 2130903252;

        /* JADX INFO: Added by JADX */
        public static final int progressBarStyle = 2130903253;

        /* JADX INFO: Added by JADX */
        public static final int queryBackground = 2130903254;

        /* JADX INFO: Added by JADX */
        public static final int queryHint = 2130903255;

        /* JADX INFO: Added by JADX */
        public static final int queryPatterns = 2130903256;

        /* JADX INFO: Added by JADX */
        public static final int radioButtonStyle = 2130903257;

        /* JADX INFO: Added by JADX */
        public static final int ratingBarStyle = 2130903258;

        /* JADX INFO: Added by JADX */
        public static final int ratingBarStyleIndicator = 2130903259;

        /* JADX INFO: Added by JADX */
        public static final int ratingBarStyleSmall = 2130903260;

        /* JADX INFO: Added by JADX */
        public static final int scopeUris = 2130903261;

        /* JADX INFO: Added by JADX */
        public static final int searchHintIcon = 2130903262;

        /* JADX INFO: Added by JADX */
        public static final int searchIcon = 2130903263;

        /* JADX INFO: Added by JADX */
        public static final int searchViewStyle = 2130903264;

        /* JADX INFO: Added by JADX */
        public static final int seekBarStyle = 2130903265;

        /* JADX INFO: Added by JADX */
        public static final int selectableItemBackground = 2130903266;

        /* JADX INFO: Added by JADX */
        public static final int selectableItemBackgroundBorderless = 2130903267;

        /* JADX INFO: Added by JADX */
        public static final int shortcutMatchRequired = 2130903268;

        /* JADX INFO: Added by JADX */
        public static final int showAsAction = 2130903269;

        /* JADX INFO: Added by JADX */
        public static final int showDividers = 2130903270;

        /* JADX INFO: Added by JADX */
        public static final int showText = 2130903271;

        /* JADX INFO: Added by JADX */
        public static final int showTitle = 2130903272;

        /* JADX INFO: Added by JADX */
        public static final int singleChoiceItemLayout = 2130903273;

        /* JADX INFO: Added by JADX */
        public static final int spinBars = 2130903274;

        /* JADX INFO: Added by JADX */
        public static final int spinnerDropDownItemStyle = 2130903275;

        /* JADX INFO: Added by JADX */
        public static final int spinnerStyle = 2130903276;

        /* JADX INFO: Added by JADX */
        public static final int splashScreenIconSize = 2130903277;

        /* JADX INFO: Added by JADX */
        public static final int splitTrack = 2130903278;

        /* JADX INFO: Added by JADX */
        public static final int srcCompat = 2130903279;

        /* JADX INFO: Added by JADX */
        public static final int start_dir = 2130903280;

        /* JADX INFO: Added by JADX */
        public static final int state_above_anchor = 2130903281;

        /* JADX INFO: Added by JADX */
        public static final int statusBarBackground = 2130903282;

        /* JADX INFO: Added by JADX */
        public static final int subMenuArrow = 2130903283;

        /* JADX INFO: Added by JADX */
        public static final int submitBackground = 2130903284;

        /* JADX INFO: Added by JADX */
        public static final int subtitle = 2130903285;

        /* JADX INFO: Added by JADX */
        public static final int subtitleTextAppearance = 2130903286;

        /* JADX INFO: Added by JADX */
        public static final int subtitleTextColor = 2130903287;

        /* JADX INFO: Added by JADX */
        public static final int subtitleTextStyle = 2130903288;

        /* JADX INFO: Added by JADX */
        public static final int suggestionRowLayout = 2130903289;

        /* JADX INFO: Added by JADX */
        public static final int switchMinWidth = 2130903290;

        /* JADX INFO: Added by JADX */
        public static final int switchPadding = 2130903291;

        /* JADX INFO: Added by JADX */
        public static final int switchStyle = 2130903292;

        /* JADX INFO: Added by JADX */
        public static final int switchTextAppearance = 2130903293;

        /* JADX INFO: Added by JADX */
        public static final int textAllCaps = 2130903294;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceLargePopupMenu = 2130903295;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceListItem = 2130903296;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceListItemSecondary = 2130903297;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceListItemSmall = 2130903298;

        /* JADX INFO: Added by JADX */
        public static final int textAppearancePopupMenuHeader = 2130903299;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceSearchResultSubtitle = 2130903300;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceSearchResultTitle = 2130903301;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceSmallPopupMenu = 2130903302;

        /* JADX INFO: Added by JADX */
        public static final int textColorAlertDialogListItem = 2130903303;

        /* JADX INFO: Added by JADX */
        public static final int textColorSearchUrl = 2130903304;

        /* JADX INFO: Added by JADX */
        public static final int textLocale = 2130903305;

        /* JADX INFO: Added by JADX */
        public static final int theme = 2130903306;

        /* JADX INFO: Added by JADX */
        public static final int thickness = 2130903307;

        /* JADX INFO: Added by JADX */
        public static final int thumbTextPadding = 2130903308;

        /* JADX INFO: Added by JADX */
        public static final int thumbTint = 2130903309;

        /* JADX INFO: Added by JADX */
        public static final int thumbTintMode = 2130903310;

        /* JADX INFO: Added by JADX */
        public static final int tickMark = 2130903311;

        /* JADX INFO: Added by JADX */
        public static final int tickMarkTint = 2130903312;

        /* JADX INFO: Added by JADX */
        public static final int tickMarkTintMode = 2130903313;

        /* JADX INFO: Added by JADX */
        public static final int tint = 2130903314;

        /* JADX INFO: Added by JADX */
        public static final int tintMode = 2130903315;

        /* JADX INFO: Added by JADX */
        public static final int title = 2130903316;

        /* JADX INFO: Added by JADX */
        public static final int titleMargin = 2130903317;

        /* JADX INFO: Added by JADX */
        public static final int titleMarginBottom = 2130903318;

        /* JADX INFO: Added by JADX */
        public static final int titleMarginEnd = 2130903319;

        /* JADX INFO: Added by JADX */
        public static final int titleMarginStart = 2130903320;

        /* JADX INFO: Added by JADX */
        public static final int titleMarginTop = 2130903321;

        /* JADX INFO: Added by JADX */
        public static final int titleMargins = 2130903322;

        /* JADX INFO: Added by JADX */
        public static final int titleTextAppearance = 2130903323;

        /* JADX INFO: Added by JADX */
        public static final int titleTextColor = 2130903324;

        /* JADX INFO: Added by JADX */
        public static final int titleTextStyle = 2130903325;

        /* JADX INFO: Added by JADX */
        public static final int toolbarNavigationButtonStyle = 2130903326;

        /* JADX INFO: Added by JADX */
        public static final int toolbarStyle = 2130903327;

        /* JADX INFO: Added by JADX */
        public static final int tooltipForegroundColor = 2130903328;

        /* JADX INFO: Added by JADX */
        public static final int tooltipFrameBackground = 2130903329;

        /* JADX INFO: Added by JADX */
        public static final int tooltipText = 2130903330;

        /* JADX INFO: Added by JADX */
        public static final int track = 2130903331;

        /* JADX INFO: Added by JADX */
        public static final int trackTint = 2130903332;

        /* JADX INFO: Added by JADX */
        public static final int trackTintMode = 2130903333;

        /* JADX INFO: Added by JADX */
        public static final int ttcIndex = 2130903334;

        /* JADX INFO: Added by JADX */
        public static final int viewInflaterClass = 2130903335;

        /* JADX INFO: Added by JADX */
        public static final int voiceIcon = 2130903336;

        /* JADX INFO: Added by JADX */
        public static final int windowActionBar = 2130903337;

        /* JADX INFO: Added by JADX */
        public static final int windowActionBarOverlay = 2130903338;

        /* JADX INFO: Added by JADX */
        public static final int windowActionModeOverlay = 2130903339;

        /* JADX INFO: Added by JADX */
        public static final int windowFixedHeightMajor = 2130903340;

        /* JADX INFO: Added by JADX */
        public static final int windowFixedHeightMinor = 2130903341;

        /* JADX INFO: Added by JADX */
        public static final int windowFixedWidthMajor = 2130903342;

        /* JADX INFO: Added by JADX */
        public static final int windowFixedWidthMinor = 2130903343;

        /* JADX INFO: Added by JADX */
        public static final int windowMinWidthMajor = 2130903344;

        /* JADX INFO: Added by JADX */
        public static final int windowMinWidthMinor = 2130903345;

        /* JADX INFO: Added by JADX */
        public static final int windowNoTitle = 2130903346;

        /* JADX INFO: Added by JADX */
        public static final int windowSplashScreenAnimatedIcon = 2130903347;

        /* JADX INFO: Added by JADX */
        public static final int windowSplashScreenAnimationDuration = 2130903348;

        /* JADX INFO: Added by JADX */
        public static final int windowSplashScreenBackground = 2130903349;

        /* JADX INFO: Added by JADX */
        public static final int windowSplashScreenIconBackgroundColor = 2130903350;
    }

    /* JADX INFO: Added by JADX */
    /* renamed from: cloud.udive.app.R$bool */
    public static final class bool {

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_embed_tabs = 2130968576;

        /* JADX INFO: Added by JADX */
        public static final int abc_config_actionMenuItemAllCaps = 2130968577;
    }

    /* JADX INFO: Added by JADX */
    /* renamed from: cloud.udive.app.R$dimen */
    public static final class dimen {

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_content_inset_material = 2131099648;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_content_inset_with_nav = 2131099649;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_default_height_material = 2131099650;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_default_padding_end_material = 2131099651;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_default_padding_start_material = 2131099652;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_elevation_material = 2131099653;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_icon_vertical_padding_material = 2131099654;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_overflow_padding_end_material = 2131099655;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_overflow_padding_start_material = 2131099656;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_stacked_max_height = 2131099657;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_stacked_tab_max_width = 2131099658;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_subtitle_bottom_margin_material = 2131099659;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_subtitle_top_margin_material = 2131099660;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_button_min_height_material = 2131099661;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_button_min_width_material = 2131099662;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_button_min_width_overflow_material = 2131099663;

        /* JADX INFO: Added by JADX */
        public static final int abc_alert_dialog_button_bar_height = 2131099664;

        /* JADX INFO: Added by JADX */
        public static final int abc_alert_dialog_button_dimen = 2131099665;

        /* JADX INFO: Added by JADX */
        public static final int abc_button_inset_horizontal_material = 2131099666;

        /* JADX INFO: Added by JADX */
        public static final int abc_button_inset_vertical_material = 2131099667;

        /* JADX INFO: Added by JADX */
        public static final int abc_button_padding_horizontal_material = 2131099668;

        /* JADX INFO: Added by JADX */
        public static final int abc_button_padding_vertical_material = 2131099669;

        /* JADX INFO: Added by JADX */
        public static final int abc_cascading_menus_min_smallest_width = 2131099670;

        /* JADX INFO: Added by JADX */
        public static final int abc_config_prefDialogWidth = 2131099671;

        /* JADX INFO: Added by JADX */
        public static final int abc_control_corner_material = 2131099672;

        /* JADX INFO: Added by JADX */
        public static final int abc_control_inset_material = 2131099673;

        /* JADX INFO: Added by JADX */
        public static final int abc_control_padding_material = 2131099674;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_corner_radius_material = 2131099675;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_fixed_height_major = 2131099676;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_fixed_height_minor = 2131099677;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_fixed_width_major = 2131099678;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_fixed_width_minor = 2131099679;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_list_padding_bottom_no_buttons = 2131099680;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_list_padding_top_no_title = 2131099681;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_min_width_major = 2131099682;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_min_width_minor = 2131099683;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_padding_material = 2131099684;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_padding_top_material = 2131099685;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_title_divider_material = 2131099686;

        /* JADX INFO: Added by JADX */
        public static final int abc_disabled_alpha_material_dark = 2131099687;

        /* JADX INFO: Added by JADX */
        public static final int abc_disabled_alpha_material_light = 2131099688;

        /* JADX INFO: Added by JADX */
        public static final int abc_dropdownitem_icon_width = 2131099689;

        /* JADX INFO: Added by JADX */
        public static final int abc_dropdownitem_text_padding_left = 2131099690;

        /* JADX INFO: Added by JADX */
        public static final int abc_dropdownitem_text_padding_right = 2131099691;

        /* JADX INFO: Added by JADX */
        public static final int abc_edit_text_inset_bottom_material = 2131099692;

        /* JADX INFO: Added by JADX */
        public static final int abc_edit_text_inset_horizontal_material = 2131099693;

        /* JADX INFO: Added by JADX */
        public static final int abc_edit_text_inset_top_material = 2131099694;

        /* JADX INFO: Added by JADX */
        public static final int abc_floating_window_z = 2131099695;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_item_height_large_material = 2131099696;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_item_height_material = 2131099697;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_item_height_small_material = 2131099698;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_item_padding_horizontal_material = 2131099699;

        /* JADX INFO: Added by JADX */
        public static final int abc_panel_menu_list_width = 2131099700;

        /* JADX INFO: Added by JADX */
        public static final int abc_progress_bar_height_material = 2131099701;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_view_preferred_height = 2131099702;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_view_preferred_width = 2131099703;

        /* JADX INFO: Added by JADX */
        public static final int abc_seekbar_track_background_height_material = 2131099704;

        /* JADX INFO: Added by JADX */
        public static final int abc_seekbar_track_progress_height_material = 2131099705;

        /* JADX INFO: Added by JADX */
        public static final int abc_select_dialog_padding_start_material = 2131099706;

        /* JADX INFO: Added by JADX */
        public static final int abc_star_big = 2131099707;

        /* JADX INFO: Added by JADX */
        public static final int abc_star_medium = 2131099708;

        /* JADX INFO: Added by JADX */
        public static final int abc_star_small = 2131099709;

        /* JADX INFO: Added by JADX */
        public static final int abc_switch_padding = 2131099710;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_body_1_material = 2131099711;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_body_2_material = 2131099712;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_button_material = 2131099713;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_caption_material = 2131099714;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_display_1_material = 2131099715;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_display_2_material = 2131099716;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_display_3_material = 2131099717;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_display_4_material = 2131099718;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_headline_material = 2131099719;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_large_material = 2131099720;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_medium_material = 2131099721;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_menu_header_material = 2131099722;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_menu_material = 2131099723;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_small_material = 2131099724;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_subhead_material = 2131099725;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_subtitle_material_toolbar = 2131099726;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_title_material = 2131099727;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_title_material_toolbar = 2131099728;

        /* JADX INFO: Added by JADX */
        public static final int browser_actions_context_menu_max_width = 2131099729;

        /* JADX INFO: Added by JADX */
        public static final int browser_actions_context_menu_min_padding = 2131099730;

        /* JADX INFO: Added by JADX */
        public static final int compat_button_inset_horizontal_material = 2131099731;

        /* JADX INFO: Added by JADX */
        public static final int compat_button_inset_vertical_material = 2131099732;

        /* JADX INFO: Added by JADX */
        public static final int compat_button_padding_horizontal_material = 2131099733;

        /* JADX INFO: Added by JADX */
        public static final int compat_button_padding_vertical_material = 2131099734;

        /* JADX INFO: Added by JADX */
        public static final int compat_control_corner_material = 2131099735;

        /* JADX INFO: Added by JADX */
        public static final int compat_notification_large_icon_max_height = 2131099736;

        /* JADX INFO: Added by JADX */
        public static final int compat_notification_large_icon_max_width = 2131099737;

        /* JADX INFO: Added by JADX */
        public static final int disabled_alpha_material_dark = 2131099738;

        /* JADX INFO: Added by JADX */
        public static final int disabled_alpha_material_light = 2131099739;

        /* JADX INFO: Added by JADX */
        public static final int highlight_alpha_material_colored = 2131099740;

        /* JADX INFO: Added by JADX */
        public static final int highlight_alpha_material_dark = 2131099741;

        /* JADX INFO: Added by JADX */
        public static final int highlight_alpha_material_light = 2131099742;

        /* JADX INFO: Added by JADX */
        public static final int hint_alpha_material_dark = 2131099743;

        /* JADX INFO: Added by JADX */
        public static final int hint_alpha_material_light = 2131099744;

        /* JADX INFO: Added by JADX */
        public static final int hint_pressed_alpha_material_dark = 2131099745;

        /* JADX INFO: Added by JADX */
        public static final int hint_pressed_alpha_material_light = 2131099746;

        /* JADX INFO: Added by JADX */
        public static final int notification_action_icon_size = 2131099747;

        /* JADX INFO: Added by JADX */
        public static final int notification_action_text_size = 2131099748;

        /* JADX INFO: Added by JADX */
        public static final int notification_big_circle_margin = 2131099749;

        /* JADX INFO: Added by JADX */
        public static final int notification_content_margin_start = 2131099750;

        /* JADX INFO: Added by JADX */
        public static final int notification_large_icon_height = 2131099751;

        /* JADX INFO: Added by JADX */
        public static final int notification_large_icon_width = 2131099752;

        /* JADX INFO: Added by JADX */
        public static final int notification_main_column_padding_top = 2131099753;

        /* JADX INFO: Added by JADX */
        public static final int notification_media_narrow_margin = 2131099754;

        /* JADX INFO: Added by JADX */
        public static final int notification_right_icon_size = 2131099755;

        /* JADX INFO: Added by JADX */
        public static final int notification_right_side_padding_top = 2131099756;

        /* JADX INFO: Added by JADX */
        public static final int notification_small_icon_background_padding = 2131099757;

        /* JADX INFO: Added by JADX */
        public static final int notification_small_icon_size_as_large = 2131099758;

        /* JADX INFO: Added by JADX */
        public static final int notification_subtext_size = 2131099759;

        /* JADX INFO: Added by JADX */
        public static final int notification_top_pad = 2131099760;

        /* JADX INFO: Added by JADX */
        public static final int notification_top_pad_large_text = 2131099761;

        /* JADX INFO: Added by JADX */
        public static final int splashscreen_icon_mask_size_no_background = 2131099762;

        /* JADX INFO: Added by JADX */
        public static final int splashscreen_icon_mask_size_with_background = 2131099763;

        /* JADX INFO: Added by JADX */
        public static final int splashscreen_icon_mask_stroke_no_background = 2131099764;

        /* JADX INFO: Added by JADX */
        public static final int splashscreen_icon_mask_stroke_with_background = 2131099765;

        /* JADX INFO: Added by JADX */
        public static final int splashscreen_icon_size = 2131099766;

        /* JADX INFO: Added by JADX */
        public static final int splashscreen_icon_size_no_background = 2131099767;

        /* JADX INFO: Added by JADX */
        public static final int splashscreen_icon_size_with_background = 2131099768;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_corner_radius = 2131099769;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_horizontal_padding = 2131099770;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_margin = 2131099771;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_precise_anchor_extra_offset = 2131099772;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_precise_anchor_threshold = 2131099773;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_vertical_padding = 2131099774;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_y_offset_non_touch = 2131099775;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_y_offset_touch = 2131099776;
    }

    /* JADX INFO: Added by JADX */
    /* renamed from: cloud.udive.app.R$id */
    public static final class id {

        /* JADX INFO: Added by JADX */
        public static final int ALT = 2131230720;

        /* JADX INFO: Added by JADX */
        public static final int CTRL = 2131230721;

        /* JADX INFO: Added by JADX */
        public static final int FUNCTION = 2131230722;

        /* JADX INFO: Added by JADX */
        public static final int META = 2131230723;

        /* JADX INFO: Added by JADX */
        public static final int SHIFT = 2131230724;

        /* JADX INFO: Added by JADX */
        public static final int SYM = 2131230725;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_action_clickable_span = 2131230726;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_0 = 2131230727;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_1 = 2131230728;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_10 = 2131230729;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_11 = 2131230730;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_12 = 2131230731;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_13 = 2131230732;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_14 = 2131230733;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_15 = 2131230734;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_16 = 2131230735;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_17 = 2131230736;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_18 = 2131230737;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_19 = 2131230738;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_2 = 2131230739;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_20 = 2131230740;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_21 = 2131230741;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_22 = 2131230742;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_23 = 2131230743;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_24 = 2131230744;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_25 = 2131230745;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_26 = 2131230746;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_27 = 2131230747;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_28 = 2131230748;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_29 = 2131230749;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_3 = 2131230750;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_30 = 2131230751;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_31 = 2131230752;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_4 = 2131230753;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_5 = 2131230754;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_6 = 2131230755;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_7 = 2131230756;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_8 = 2131230757;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_9 = 2131230758;

        /* JADX INFO: Added by JADX */
        public static final int action_bar = 2131230759;

        /* JADX INFO: Added by JADX */
        public static final int action_bar_activity_content = 2131230760;

        /* JADX INFO: Added by JADX */
        public static final int action_bar_container = 2131230761;

        /* JADX INFO: Added by JADX */
        public static final int action_bar_root = 2131230762;

        /* JADX INFO: Added by JADX */
        public static final int action_bar_spinner = 2131230763;

        /* JADX INFO: Added by JADX */
        public static final int action_bar_subtitle = 2131230764;

        /* JADX INFO: Added by JADX */
        public static final int action_bar_title = 2131230765;

        /* JADX INFO: Added by JADX */
        public static final int action_container = 2131230766;

        /* JADX INFO: Added by JADX */
        public static final int action_context_bar = 2131230767;

        /* JADX INFO: Added by JADX */
        public static final int action_divider = 2131230768;

        /* JADX INFO: Added by JADX */
        public static final int action_image = 2131230769;

        /* JADX INFO: Added by JADX */
        public static final int action_menu_divider = 2131230770;

        /* JADX INFO: Added by JADX */
        public static final int action_menu_presenter = 2131230771;

        /* JADX INFO: Added by JADX */
        public static final int action_mode_bar = 2131230772;

        /* JADX INFO: Added by JADX */
        public static final int action_mode_bar_stub = 2131230773;

        /* JADX INFO: Added by JADX */
        public static final int action_mode_close_button = 2131230774;

        /* JADX INFO: Added by JADX */
        public static final int action_text = 2131230775;

        /* JADX INFO: Added by JADX */
        public static final int actions = 2131230776;

        /* JADX INFO: Added by JADX */
        public static final int activity_chooser_view_content = 2131230777;

        /* JADX INFO: Added by JADX */
        public static final int add = 2131230778;

        /* JADX INFO: Added by JADX */
        public static final int adjust_height = 2131230779;

        /* JADX INFO: Added by JADX */
        public static final int adjust_width = 2131230780;

        /* JADX INFO: Added by JADX */
        public static final int alertTitle = 2131230781;

        /* JADX INFO: Added by JADX */
        public static final int all = 2131230782;

        /* JADX INFO: Added by JADX */
        public static final int always = 2131230783;

        /* JADX INFO: Added by JADX */
        public static final int async = 2131230784;

        /* JADX INFO: Added by JADX */
        public static final int auto = 2131230785;

        /* JADX INFO: Added by JADX */
        public static final int beginning = 2131230786;

        /* JADX INFO: Added by JADX */
        public static final int blocking = 2131230787;

        /* JADX INFO: Added by JADX */
        public static final int bottom = 2131230788;

        /* JADX INFO: Added by JADX */
        public static final int browser_actions_header_text = 2131230789;

        /* JADX INFO: Added by JADX */
        public static final int browser_actions_menu_item_icon = 2131230790;

        /* JADX INFO: Added by JADX */
        public static final int browser_actions_menu_item_text = 2131230791;

        /* JADX INFO: Added by JADX */
        public static final int browser_actions_menu_items = 2131230792;

        /* JADX INFO: Added by JADX */
        public static final int browser_actions_menu_view = 2131230793;

        /* JADX INFO: Added by JADX */
        public static final int buttonPanel = 2131230794;

        /* JADX INFO: Added by JADX */
        public static final int center = 2131230795;

        /* JADX INFO: Added by JADX */
        public static final int center_horizontal = 2131230796;

        /* JADX INFO: Added by JADX */
        public static final int center_vertical = 2131230797;

        /* JADX INFO: Added by JADX */
        public static final int checkbox = 2131230798;

        /* JADX INFO: Added by JADX */
        public static final int checked = 2131230799;

        /* JADX INFO: Added by JADX */
        public static final int chronometer = 2131230800;

        /* JADX INFO: Added by JADX */
        public static final int clip_horizontal = 2131230801;

        /* JADX INFO: Added by JADX */
        public static final int clip_vertical = 2131230802;

        /* JADX INFO: Added by JADX */
        public static final int collapseActionView = 2131230803;

        /* JADX INFO: Added by JADX */
        public static final int content = 2131230804;

        /* JADX INFO: Added by JADX */
        public static final int contentPanel = 2131230805;

        /* JADX INFO: Added by JADX */
        public static final int custom = 2131230806;

        /* JADX INFO: Added by JADX */
        public static final int customPanel = 2131230807;

        /* JADX INFO: Added by JADX */
        public static final int dark = 2131230808;

        /* JADX INFO: Added by JADX */
        public static final int decor_content_parent = 2131230809;

        /* JADX INFO: Added by JADX */
        public static final int default_activity_button = 2131230810;

        /* JADX INFO: Added by JADX */
        public static final int dialog_button = 2131230811;

        /* JADX INFO: Added by JADX */
        public static final int disableHome = 2131230812;

        /* JADX INFO: Added by JADX */
        public static final int edit_query = 2131230813;

        /* JADX INFO: Added by JADX */
        public static final int edit_text_id = 2131230814;

        /* JADX INFO: Added by JADX */
        public static final int end = 2131230815;

        /* JADX INFO: Added by JADX */
        public static final int expand_activities_button = 2131230816;

        /* JADX INFO: Added by JADX */
        public static final int expanded_menu = 2131230817;

        /* JADX INFO: Added by JADX */
        public static final int fill = 2131230818;

        /* JADX INFO: Added by JADX */
        public static final int fill_horizontal = 2131230819;

        /* JADX INFO: Added by JADX */
        public static final int fill_vertical = 2131230820;

        /* JADX INFO: Added by JADX */
        public static final int forever = 2131230821;

        /* JADX INFO: Added by JADX */
        public static final int fragment_container_view_tag = 2131230822;

        /* JADX INFO: Added by JADX */
        public static final int group_divider = 2131230823;

        /* JADX INFO: Added by JADX */
        public static final int hide_ime_id = 2131230824;

        /* JADX INFO: Added by JADX */
        public static final int home = 2131230825;

        /* JADX INFO: Added by JADX */
        public static final int homeAsUp = 2131230826;

        /* JADX INFO: Added by JADX */
        public static final int icon = 2131230827;

        /* JADX INFO: Added by JADX */
        public static final int icon_group = 2131230828;

        /* JADX INFO: Added by JADX */
        public static final int icon_only = 2131230829;

        /* JADX INFO: Added by JADX */
        public static final int ifRoom = 2131230830;

        /* JADX INFO: Added by JADX */
        public static final int image = 2131230831;

        /* JADX INFO: Added by JADX */
        public static final int info = 2131230832;

        /* JADX INFO: Added by JADX */
        public static final int italic = 2131230833;

        /* JADX INFO: Added by JADX */
        public static final int left = 2131230834;

        /* JADX INFO: Added by JADX */
        public static final int light = 2131230835;

        /* JADX INFO: Added by JADX */
        public static final int line1 = 2131230836;

        /* JADX INFO: Added by JADX */
        public static final int line3 = 2131230837;

        /* JADX INFO: Added by JADX */
        public static final int listMode = 2131230838;

        /* JADX INFO: Added by JADX */
        public static final int list_item = 2131230839;

        /* JADX INFO: Added by JADX */
        public static final int message = 2131230840;

        /* JADX INFO: Added by JADX */
        public static final int middle = 2131230841;

        /* JADX INFO: Added by JADX */
        public static final int multiply = 2131230842;

        /* JADX INFO: Added by JADX */
        public static final int never = 2131230843;

        /* JADX INFO: Added by JADX */
        public static final int none = 2131230844;

        /* JADX INFO: Added by JADX */
        public static final int normal = 2131230845;

        /* JADX INFO: Added by JADX */
        public static final int notification_background = 2131230846;

        /* JADX INFO: Added by JADX */
        public static final int notification_main_column = 2131230847;

        /* JADX INFO: Added by JADX */
        public static final int notification_main_column_container = 2131230848;

        /* JADX INFO: Added by JADX */
        public static final int off = 2131230849;

        /* JADX INFO: Added by JADX */
        public static final int on = 2131230850;

        /* JADX INFO: Added by JADX */
        public static final int parentPanel = 2131230851;

        /* JADX INFO: Added by JADX */
        public static final int progress_circular = 2131230852;

        /* JADX INFO: Added by JADX */
        public static final int progress_horizontal = 2131230853;

        /* JADX INFO: Added by JADX */
        public static final int radio = 2131230854;

        /* JADX INFO: Added by JADX */
        public static final int report_drawn = 2131230855;

        /* JADX INFO: Added by JADX */
        public static final int right = 2131230856;

        /* JADX INFO: Added by JADX */
        public static final int right_icon = 2131230857;

        /* JADX INFO: Added by JADX */
        public static final int right_side = 2131230858;

        /* JADX INFO: Added by JADX */
        public static final int screen = 2131230859;

        /* JADX INFO: Added by JADX */
        public static final int scrollIndicatorDown = 2131230860;

        /* JADX INFO: Added by JADX */
        public static final int scrollIndicatorUp = 2131230861;

        /* JADX INFO: Added by JADX */
        public static final int scrollView = 2131230862;

        /* JADX INFO: Added by JADX */
        public static final int search_badge = 2131230863;

        /* JADX INFO: Added by JADX */
        public static final int search_bar = 2131230864;

        /* JADX INFO: Added by JADX */
        public static final int search_button = 2131230865;

        /* JADX INFO: Added by JADX */
        public static final int search_close_btn = 2131230866;

        /* JADX INFO: Added by JADX */
        public static final int search_edit_frame = 2131230867;

        /* JADX INFO: Added by JADX */
        public static final int search_go_btn = 2131230868;

        /* JADX INFO: Added by JADX */
        public static final int search_mag_icon = 2131230869;

        /* JADX INFO: Added by JADX */
        public static final int search_plate = 2131230870;

        /* JADX INFO: Added by JADX */
        public static final int search_src_text = 2131230871;

        /* JADX INFO: Added by JADX */
        public static final int search_voice_btn = 2131230872;

        /* JADX INFO: Added by JADX */
        public static final int select_dialog_listview = 2131230873;

        /* JADX INFO: Added by JADX */
        public static final int shortcut = 2131230874;

        /* JADX INFO: Added by JADX */
        public static final int showCustom = 2131230875;

        /* JADX INFO: Added by JADX */
        public static final int showHome = 2131230876;

        /* JADX INFO: Added by JADX */
        public static final int showTitle = 2131230877;

        /* JADX INFO: Added by JADX */
        public static final int spacer = 2131230878;

        /* JADX INFO: Added by JADX */
        public static final int special_effects_controller_view_tag = 2131230879;

        /* JADX INFO: Added by JADX */
        public static final int splashscreen_icon_view = 2131230880;

        /* JADX INFO: Added by JADX */
        public static final int split_action_bar = 2131230881;

        /* JADX INFO: Added by JADX */
        public static final int src_atop = 2131230882;

        /* JADX INFO: Added by JADX */
        public static final int src_in = 2131230883;

        /* JADX INFO: Added by JADX */
        public static final int src_over = 2131230884;

        /* JADX INFO: Added by JADX */
        public static final int standard = 2131230885;

        /* JADX INFO: Added by JADX */
        public static final int start = 2131230886;

        /* JADX INFO: Added by JADX */
        public static final int submenuarrow = 2131230887;

        /* JADX INFO: Added by JADX */
        public static final int submit_area = 2131230888;

        /* JADX INFO: Added by JADX */
        public static final int tabMode = 2131230889;

        /* JADX INFO: Added by JADX */
        public static final int tag_accessibility_actions = 2131230890;

        /* JADX INFO: Added by JADX */
        public static final int tag_accessibility_clickable_spans = 2131230891;

        /* JADX INFO: Added by JADX */
        public static final int tag_accessibility_heading = 2131230892;

        /* JADX INFO: Added by JADX */
        public static final int tag_accessibility_pane_title = 2131230893;

        /* JADX INFO: Added by JADX */
        public static final int tag_on_apply_window_listener = 2131230894;

        /* JADX INFO: Added by JADX */
        public static final int tag_on_receive_content_listener = 2131230895;

        /* JADX INFO: Added by JADX */
        public static final int tag_on_receive_content_mime_types = 2131230896;

        /* JADX INFO: Added by JADX */
        public static final int tag_screen_reader_focusable = 2131230897;

        /* JADX INFO: Added by JADX */
        public static final int tag_state_description = 2131230898;

        /* JADX INFO: Added by JADX */
        public static final int tag_transition_group = 2131230899;

        /* JADX INFO: Added by JADX */
        public static final int tag_unhandled_key_event_manager = 2131230900;

        /* JADX INFO: Added by JADX */
        public static final int tag_unhandled_key_listeners = 2131230901;

        /* JADX INFO: Added by JADX */
        public static final int tag_window_insets_animation_callback = 2131230902;

        /* JADX INFO: Added by JADX */
        public static final int text = 2131230903;

        /* JADX INFO: Added by JADX */
        public static final int text2 = 2131230904;

        /* JADX INFO: Added by JADX */
        public static final int textSpacerNoButtons = 2131230905;

        /* JADX INFO: Added by JADX */
        public static final int textSpacerNoTitle = 2131230906;

        /* JADX INFO: Added by JADX */
        public static final int textView = 2131230907;

        /* JADX INFO: Added by JADX */
        public static final int time = 2131230908;

        /* JADX INFO: Added by JADX */
        public static final int title = 2131230909;

        /* JADX INFO: Added by JADX */
        public static final int titleDividerNoCustom = 2131230910;

        /* JADX INFO: Added by JADX */
        public static final int title_template = 2131230911;

        /* JADX INFO: Added by JADX */
        public static final int top = 2131230912;

        /* JADX INFO: Added by JADX */
        public static final int topPanel = 2131230913;

        /* JADX INFO: Added by JADX */
        public static final int unchecked = 2131230914;

        /* JADX INFO: Added by JADX */
        public static final int uniform = 2131230915;

        /* JADX INFO: Added by JADX */
        public static final int up = 2131230916;

        /* JADX INFO: Added by JADX */
        public static final int useLogo = 2131230917;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_lifecycle_owner = 2131230918;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_on_back_pressed_dispatcher_owner = 2131230919;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_saved_state_registry_owner = 2131230920;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_view_model_store_owner = 2131230921;

        /* JADX INFO: Added by JADX */
        public static final int visible_removing_fragment_view_tag = 2131230922;

        /* JADX INFO: Added by JADX */
        public static final int webview = 2131230923;

        /* JADX INFO: Added by JADX */
        public static final int wide = 2131230924;

        /* JADX INFO: Added by JADX */
        public static final int withText = 2131230925;

        /* JADX INFO: Added by JADX */
        public static final int wrap_content = 2131230926;
    }

    /* JADX INFO: Added by JADX */
    /* renamed from: cloud.udive.app.R$integer */
    public static final class integer {

        /* JADX INFO: Added by JADX */
        public static final int abc_config_activityDefaultDur = 2131296256;

        /* JADX INFO: Added by JADX */
        public static final int abc_config_activityShortDur = 2131296257;

        /* JADX INFO: Added by JADX */
        public static final int cancel_button_image_alpha = 2131296258;

        /* JADX INFO: Added by JADX */
        public static final int config_tooltipAnimTime = 2131296259;

        /* JADX INFO: Added by JADX */
        public static final int default_icon_animation_duration = 2131296260;

        /* JADX INFO: Added by JADX */
        public static final int google_play_services_version = 2131296261;

        /* JADX INFO: Added by JADX */
        public static final int status_bar_notification_info_maxnum = 2131296262;
    }

    /* JADX INFO: Added by JADX */
    /* renamed from: cloud.udive.app.R$interpolator */
    public static final class interpolator {

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_checked_mtrl_animation_interpolator_0 = 2131361792;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_checked_mtrl_animation_interpolator_1 = 2131361793;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_unchecked_mtrl_animation_interpolator_0 = 2131361794;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_unchecked_mtrl_animation_interpolator_1 = 2131361795;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_off_mtrl_animation_interpolator_0 = 2131361796;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_on_mtrl_animation_interpolator_0 = 2131361797;

        /* JADX INFO: Added by JADX */
        public static final int fast_out_slow_in = 2131361798;
    }

    /* JADX INFO: Added by JADX */
    /* renamed from: cloud.udive.app.R$raw */
    public static final class raw {

        /* JADX INFO: Added by JADX */
        public static final int firebase_common_keep = 2131558400;
    }

    private C0346R() {
    }
}
