package capacitor.cordova.android.plugins;

/* renamed from: capacitor.cordova.android.plugins.R */
/* loaded from: classes.dex */
public final class C0345R {
    private C0345R() {
    }
}
